import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting seed...');

  // Create admin user
  const hashedPassword = await bcrypt.hash('admin123', 10);
  
  const admin = await prisma.user.upsert({
    where: { email: 'admin@fabricadeideas.com' },
    update: {},
    create: {
      email: 'admin@fabricadeideas.com',
      password: hashedPassword,
      name: 'Carlos García',
      role: 'ADMIN',
      points: 2450,
      level: 25,
      bio: 'Administrador principal del sistema',
      isActive: true,
    },
  });

  console.log('✅ Admin user created:', admin.email);

  // Create organizer
  const organizer = await prisma.user.upsert({
    where: { email: 'organizer@fabricadeideas.com' },
    update: {},
    create: {
      email: 'organizer@fabricadeideas.com',
      password: hashedPassword,
      name: 'María López',
      role: 'ORGANIZER',
      points: 1800,
      level: 18,
      bio: 'Organizadora de eventos',
      isActive: true,
    },
  });

  console.log('✅ Organizer user created:', organizer.email);

  // Create moderator
  const moderator = await prisma.user.upsert({
    where: { email: 'moderator@fabricadeideas.com' },
    update: {},
    create: {
      email: 'moderator@fabricadeideas.com',
      password: hashedPassword,
      name: 'Pedro Sánchez',
      role: 'MODERATOR',
      points: 1200,
      level: 12,
      bio: 'Moderador de actividades',
      isActive: true,
    },
  });

  console.log('✅ Moderator user created:', moderator.email);

  // Create test participants
  const participants = [];
  const participantNames = [
    'Ana Rodríguez', 'Luis Torres', 'Isabel Fernández', 'Juan Martínez',
    'Carmen Ruiz', 'Diego García', 'Laura Sánchez', 'Miguel Ángel López',
    'Elena Moreno', 'Pablo Jiménez'
  ];

  for (let i = 0; i < participantNames.length; i++) {
    const name = participantNames[i];
    const email = name.toLowerCase().replace(/ /g, '.').normalize('NFD').replace(/[\u0300-\u036f]/g, '') + '@test.com';
    const points = Math.floor(Math.random() * 2000) + 500;
    
    const participant = await prisma.user.upsert({
      where: { email },
      update: {},
      create: {
        email,
        password: hashedPassword,
        name,
        role: 'PARTICIPANT',
        points,
        level: Math.floor(points / 100) + 1,
        isActive: true,
      },
    });
    participants.push(participant);
  }

  console.log('✅ Participants created:', participants.length);

  // Create event
  const event = await prisma.event.upsert({
    where: { slug: 'fabrica-de-ideas-2024' },
    update: {},
    create: {
      name: 'Fábrica de Ideas 2024',
      slug: 'fabrica-de-ideas-2024',
      description: 'El evento de innovación más grande del año. Tres días de conferencias, talleres y competencias.',
      startDate: new Date('2024-03-15T09:00:00'),
      endDate: new Date('2024-03-17T18:00:00'),
      location: 'Centro de Convenciones',
      address: 'Av. Innovación 123, Ciudad Tecnológica',
      latitude: 40.4168,
      longitude: -3.7038,
      website: 'https://fabricadeideas.com',
      isActive: true,
      votingEnabled: true,
      qrEnabled: true,
      mapsEnabled: true,
      gamificationEnabled: true,
      creatorId: admin.id,
    },
  });

  console.log('✅ Event created:', event.name);

  // Create rooms
  const rooms = await Promise.all([
    prisma.room.upsert({
      where: { id: 'room-auditorio' },
      update: {},
      create: {
        id: 'room-auditorio',
        eventId: event.id,
        name: 'Auditorio Principal',
        description: 'Espacio principal para conferencias y paneles',
        capacity: 500,
        building: 'Edificio A',
        floor: 'Planta Baja',
        latitude: 40.4170,
        longitude: -3.7040,
        color: '#3B82F6',
        icon: 'building',
      },
    }),
    prisma.room.upsert({
      where: { id: 'room-innovacion' },
      update: {},
      create: {
        id: 'room-innovacion',
        eventId: event.id,
        name: 'Sala Innovación',
        description: 'Sala para workshops y sesiones interactivas',
        capacity: 150,
        building: 'Edificio B',
        floor: 'Piso 2',
        latitude: 40.4172,
        longitude: -3.7042,
        color: '#10B981',
        icon: 'lightbulb',
      },
    }),
    prisma.room.upsert({
      where: { id: 'room-workshop1' },
      update: {},
      create: {
        id: 'room-workshop1',
        eventId: event.id,
        name: 'Workshop Lab 1',
        description: 'Laboratorio de trabajo práctico',
        capacity: 50,
        building: 'Edificio C',
        floor: 'Piso 1',
        latitude: 40.4174,
        longitude: -3.7044,
        color: '#F59E0B',
        icon: 'tool',
      },
    }),
    prisma.room.upsert({
      where: { id: 'room-workshop2' },
      update: {},
      create: {
        id: 'room-workshop2',
        eventId: event.id,
        name: 'Workshop Lab 2',
        description: 'Laboratorio de trabajo práctico',
        capacity: 50,
        building: 'Edificio C',
        floor: 'Piso 1',
        latitude: 40.4175,
        longitude: -3.7045,
        color: '#8B5CF6',
        icon: 'tool',
      },
    }),
    prisma.room.upsert({
      where: { id: 'room-expo' },
      update: {},
      create: {
        id: 'room-expo',
        eventId: event.id,
        name: 'Sala de Exposiciones',
        description: 'Espacio para stands y networking',
        capacity: 200,
        building: 'Edificio A',
        floor: 'Piso 1',
        latitude: 40.4171,
        longitude: -3.7041,
        color: '#EF4444',
        icon: 'presentation',
      },
    }),
  ]);

  console.log('✅ Rooms created:', rooms.length);

  // Create speakers
  const speakers = await Promise.all([
    prisma.speaker.upsert({
      where: { id: 'speaker-1' },
      update: {},
      create: {
        id: 'speaker-1',
        eventId: event.id,
        name: 'Dra. María López',
        title: 'Directora de Innovación',
        company: 'TechCorp',
        bio: 'Experta en transformación digital con más de 15 años de experiencia.',
        email: 'maria.lopez@techcorp.com',
        twitter: '@marialopez',
        linkedin: 'marialopez',
      },
    }),
    prisma.speaker.upsert({
      where: { id: 'speaker-2' },
      update: {},
      create: {
        id: 'speaker-2',
        eventId: event.id,
        name: 'Juan Martínez',
        title: 'Design Lead',
        company: 'DesignStudio',
        bio: 'Diseñador de productos digitales y facilitador de Design Thinking.',
        email: 'juan@designstudio.com',
        twitter: '@juanmartinez',
        linkedin: 'juanmartinez',
      },
    }),
    prisma.speaker.upsert({
      where: { id: 'speaker-3' },
      update: {},
      create: {
        id: 'speaker-3',
        eventId: event.id,
        name: 'Ana García',
        title: 'CEO & Founder',
        company: 'StartupX',
        bio: 'Emprendedora serial con 3 startups exitosas.',
        email: 'ana@startupx.com',
        twitter: '@anagarcia',
        linkedin: 'anagarcia',
      },
    }),
  ]);

  console.log('✅ Speakers created:', speakers.length);

  // Create activities
  const activities = await Promise.all([
    prisma.activity.upsert({
      where: { id: 'activity-1' },
      update: {},
      create: {
        id: 'activity-1',
        eventId: event.id,
        roomId: 'room-auditorio',
        speakerId: 'speaker-1',
        title: 'Inauguración del Evento',
        description: 'Ceremonia de apertura con keynote principal sobre el futuro de la innovación.',
        type: 'KEYNOTE',
        status: 'SCHEDULED',
        theme: 'Innovación',
        tags: JSON.stringify(['inauguración', 'keynote', 'innovación']),
        startTime: new Date('2024-03-15T09:00:00'),
        endTime: new Date('2024-03-15T10:30:00'),
        color: '#8B5CF6',
      },
    }),
    prisma.activity.upsert({
      where: { id: 'activity-2' },
      update: {},
      create: {
        id: 'activity-2',
        eventId: event.id,
        roomId: 'room-workshop1',
        speakerId: 'speaker-2',
        title: 'Taller de Design Thinking',
        description: 'Aprende metodologías de diseño centrado en el usuario.',
        type: 'WORKSHOP',
        status: 'SCHEDULED',
        theme: 'Diseño',
        tags: JSON.stringify(['taller', 'design thinking', 'UX']),
        startTime: new Date('2024-03-15T11:00:00'),
        endTime: new Date('2024-03-15T13:00:00'),
        maxCapacity: 50,
        currentAttendance: 35,
        color: '#3B82F6',
      },
    }),
    prisma.activity.upsert({
      where: { id: 'activity-3' },
      update: {},
      create: {
        id: 'activity-3',
        eventId: event.id,
        roomId: 'room-auditorio',
        title: 'Panel: Startups que transforman',
        description: 'Fundadores comparten sus experiencias y lecciones aprendidas.',
        type: 'PANEL',
        status: 'IN_PROGRESS',
        theme: 'Emprendimiento',
        tags: JSON.stringify(['panel', 'startups', 'emprendimiento']),
        startTime: new Date('2024-03-15T14:00:00'),
        endTime: new Date('2024-03-15T15:30:00'),
        currentAttendance: 280,
        color: '#10B981',
      },
    }),
    prisma.activity.upsert({
      where: { id: 'activity-4' },
      update: {},
      create: {
        id: 'activity-4',
        eventId: event.id,
        roomId: 'room-expo',
        title: 'Networking Session',
        description: 'Conecta con otros participantes y crea alianzas.',
        type: 'NETWORKING',
        status: 'SCHEDULED',
        theme: 'Networking',
        tags: JSON.stringify(['networking', 'conexiones']),
        startTime: new Date('2024-03-15T16:00:00'),
        endTime: new Date('2024-03-15T17:30:00'),
        currentAttendance: 120,
        color: '#EC4899',
      },
    }),
    prisma.activity.upsert({
      where: { id: 'activity-5' },
      update: {},
      create: {
        id: 'activity-5',
        eventId: event.id,
        roomId: 'room-auditorio',
        title: 'Pitch Competition',
        description: 'Los mejores proyectos presentan sus propuestas.',
        type: 'PRESENTATION',
        status: 'SCHEDULED',
        theme: 'Competencia',
        tags: JSON.stringify(['pitch', 'competencia', 'proyectos']),
        startTime: new Date('2024-03-16T10:00:00'),
        endTime: new Date('2024-03-16T12:00:00'),
        color: '#F59E0B',
      },
    }),
  ]);

  console.log('✅ Activities created:', activities.length);

  // Create projects
  const projects = await Promise.all([
    prisma.project.upsert({
      where: { id: 'project-1' },
      update: {},
      create: {
        id: 'project-1',
        eventId: event.id,
        roomId: 'room-expo',
        name: 'EcoTrack',
        team: JSON.stringify(['Ana Rodríguez', 'Carlos Pérez', 'Lucía Martín']),
        category: 'Sostenibilidad',
        description: 'App para monitorear y reducir tu huella de carbono personal con gamificación.',
        status: 'APPROVED',
        totalVotes: 156,
        averageScore: 4.7,
      },
    }),
    prisma.project.upsert({
      where: { id: 'project-2' },
      update: {},
      create: {
        id: 'project-2',
        eventId: event.id,
        roomId: 'room-expo',
        name: 'MediConnect',
        team: JSON.stringify(['Diego García', 'Sofia Ruiz']),
        category: 'Salud',
        description: 'Plataforma de telemedicina con IA para diagnóstico preventivo.',
        status: 'APPROVED',
        totalVotes: 142,
        averageScore: 4.5,
      },
    }),
    prisma.project.upsert({
      where: { id: 'project-3' },
      update: {},
      create: {
        id: 'project-3',
        eventId: event.id,
        roomId: 'room-expo',
        name: 'LearnPath',
        team: JSON.stringify(['Miguel Ángel López', 'Elena Moreno', 'Pablo Jiménez']),
        category: 'Educación',
        description: 'Sistema de aprendizaje adaptativo basado en el estilo cognitivo del estudiante.',
        status: 'APPROVED',
        totalVotes: 128,
        averageScore: 4.4,
      },
    }),
    prisma.project.upsert({
      where: { id: 'project-4' },
      update: {},
      create: {
        id: 'project-4',
        eventId: event.id,
        roomId: 'room-expo',
        name: 'SmartCity Hub',
        team: JSON.stringify(['Luis Torres', 'Isabel Fernández']),
        category: 'Smart Cities',
        description: 'Plataforma IoT para gestión urbana inteligente.',
        status: 'APPROVED',
        totalVotes: 98,
        averageScore: 4.2,
      },
    }),
    prisma.project.upsert({
      where: { id: 'project-5' },
      update: {},
      create: {
        id: 'project-5',
        eventId: event.id,
        roomId: 'room-expo',
        name: 'FinBot',
        team: JSON.stringify(['Juan Martínez', 'Carmen Ruiz']),
        category: 'Finanzas',
        description: 'Asistente financiero personal impulsado por IA.',
        status: 'APPROVED',
        totalVotes: 87,
        averageScore: 4.0,
      },
    }),
  ]);

  console.log('✅ Projects created:', projects.length);

  // Create achievements
  const achievements = await Promise.all([
    prisma.achievement.upsert({
      where: { id: 'achievement-1' },
      update: {},
      create: {
        id: 'achievement-1',
        name: 'Primera Asistencia',
        description: 'Asiste a tu primera actividad',
        icon: 'calendar',
        points: 10,
        category: 'participation',
        requirement: 'Attend 1 activity',
      },
    }),
    prisma.achievement.upsert({
      where: { id: 'achievement-2' },
      update: {},
      create: {
        id: 'achievement-2',
        name: 'Votante Activo',
        description: 'Vota por 5 proyectos diferentes',
        icon: 'vote',
        points: 25,
        category: 'voting',
        requirement: 'Vote for 5 projects',
      },
    }),
    prisma.achievement.upsert({
      where: { id: 'achievement-3' },
      update: {},
      create: {
        id: 'achievement-3',
        name: 'Explorador',
        description: 'Visita todas las salas del evento',
        icon: 'map',
        points: 50,
        category: 'exploration',
        requirement: 'Visit all rooms',
      },
    }),
    prisma.achievement.upsert({
      where: { id: 'achievement-4' },
      update: {},
      create: {
        id: 'achievement-4',
        name: 'Scáner Pro',
        description: 'Escanea 20 códigos QR',
        icon: 'qr',
        points: 30,
        category: 'engagement',
        requirement: 'Scan 20 QR codes',
      },
    }),
    prisma.achievement.upsert({
      where: { id: 'achievement-5' },
      update: {},
      create: {
        id: 'achievement-5',
        name: 'Top 10',
        description: 'Entra al top 10 del ranking',
        icon: 'trophy',
        points: 100,
        category: 'ranking',
        requirement: 'Reach top 10',
      },
    }),
  ]);

  console.log('✅ Achievements created:', achievements.length);

  // Create voting config
  const votingConfig = await prisma.votingConfig.upsert({
    where: { id: 'voting-config-1' },
    update: {},
    create: {
      id: 'voting-config-1',
      eventId: event.id,
      name: 'Votación Principal',
      voteType: 'STARS',
      maxVotesPerUser: 3,
      startDate: new Date('2024-03-15T00:00:00'),
      endDate: new Date('2024-03-17T18:00:00'),
      isActive: true,
      showResults: true,
    },
  });

  console.log('✅ Voting config created');

  // Create QR codes for rooms
  for (const room of rooms) {
    await prisma.qRCode.upsert({
      where: { code: `ROOM-${room.id.slice(-4).toUpperCase()}` },
      update: {},
      create: {
        code: `ROOM-${room.id.slice(-4).toUpperCase()}`,
        type: 'ROOM',
        roomId: room.id,
      },
    });
  }

  // Create QR codes for activities
  for (const activity of activities) {
    await prisma.qRCode.upsert({
      where: { code: `ACT-${activity.id.slice(-4).toUpperCase()}` },
      update: {},
      create: {
        code: `ACT-${activity.id.slice(-4).toUpperCase()}`,
        type: 'ACTIVITY',
        activityId: activity.id,
      },
    });
  }

  // Create QR codes for projects
  for (const project of projects) {
    await prisma.qRCode.upsert({
      where: { code: `PRJ-${project.id.slice(-4).toUpperCase()}` },
      update: {},
      create: {
        code: `PRJ-${project.id.slice(-4).toUpperCase()}`,
        type: 'PROJECT',
        projectId: project.id,
      },
    });
  }

  console.log('✅ QR codes created');

  // Create some sample votes
  const voteRecords = [];
  for (let i = 0; i < participants.length; i++) {
    const participant = participants[i];
    // Each participant votes for 1-3 random projects
    const numVotes = Math.floor(Math.random() * 3) + 1;
    const votedProjects = projects.slice(0, numVotes);
    
    for (const project of votedProjects) {
      const score = Math.floor(Math.random() * 2) + 4; // 4-5 stars
      try {
        const vote = await prisma.vote.create({
          data: {
            userId: participant.id,
            projectId: project.id,
            score,
          },
        });
        voteRecords.push(vote);
      } catch {
        // Vote already exists
      }
    }
  }

  console.log('✅ Sample votes created:', voteRecords.length);

  // Create sample attendance records
  const attendanceRecords = [];
  for (const participant of participants.slice(0, 5)) {
    for (const activity of activities.slice(0, 3)) {
      try {
        const attendance = await prisma.attendance.create({
          data: {
            userId: participant.id,
            activityId: activity.id,
            points: 10,
          },
        });
        attendanceRecords.push(attendance);
      } catch {
        // Already exists
      }
    }
  }

  console.log('✅ Sample attendance records created:', attendanceRecords.length);

  // Create notifications
  try {
    await prisma.notification.createMany({
      data: [
        {
          title: '¡Bienvenido a Fábrica de Ideas!',
          message: 'Explora la agenda y descubre todas las actividades del evento.',
          type: 'INFO',
          isGlobal: true,
        },
        {
          title: 'Votación abierta',
          message: 'Ya puedes votar por tus proyectos favoritos.',
          type: 'INFO',
          isGlobal: true,
        },
      ],
    });
    console.log('✅ Notifications created');
  } catch {
    console.log('⚠️ Notifications already exist');
  }

  console.log('\n🎉 Seed completed successfully!');
  console.log('\n📋 Test credentials:');
  console.log('   Admin: admin@fabricadeideas.com / admin123');
  console.log('   Organizer: organizer@fabricadeideas.com / admin123');
  console.log('   Moderator: moderator@fabricadeideas.com / admin123');
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
