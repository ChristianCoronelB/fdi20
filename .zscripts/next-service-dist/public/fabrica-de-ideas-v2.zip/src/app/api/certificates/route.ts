import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { db } from '@/lib/db';

// GET /api/certificates - List user certificates
export async function GET(request: NextRequest) {
  try {
    const session = await getSession();
    
    if (!session) {
      return NextResponse.json(
        { success: false, error: 'No autenticado' },
        { status: 401 }
      );
    }
    
    const searchParams = request.nextUrl.searchParams;
    const userId = searchParams.get('userId') || session.userId;
    
    // Only admins can view other users' certificates
    if (userId !== session.userId && session.role !== 'ADMIN') {
      return NextResponse.json(
        { success: false, error: 'No autorizado' },
        { status: 403 }
      );
    }
    
    const certificates = await db.certificate.findMany({
      where: { userId },
      include: {
        event: {
          select: { name: true, startDate: true, endDate: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });
    
    return NextResponse.json({
      success: true,
      data: certificates,
    });
  } catch (error) {
    console.error('Get certificates error:', error);
    return NextResponse.json(
      { success: false, error: 'Error al obtener certificados' },
      { status: 500 }
    );
  }
}

// POST /api/certificates - Generate certificate
export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    
    if (!session) {
      return NextResponse.json(
        { success: false, error: 'No autenticado' },
        { status: 401 }
      );
    }
    
    const body = await request.json();
    const { userId, eventId, type, title, description } = body;
    
    // Only admins can generate certificates for other users
    const targetUserId = userId || session.userId;
    if (targetUserId !== session.userId && session.role !== 'ADMIN' && session.role !== 'ORGANIZER') {
      return NextResponse.json(
        { success: false, error: 'No autorizado para generar certificados' },
        { status: 403 }
      );
    }
    
    // Get user info
    const user = await db.user.findUnique({
      where: { id: targetUserId },
    });
    
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Usuario no encontrado' },
        { status: 404 }
      );
    }
    
    // Generate unique code
    const code = `CERT-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
    
    // Create certificate
    const certificate = await db.certificate.create({
      data: {
        userId: targetUserId,
        eventId,
        type,
        title: title || `Certificado de ${type}`,
        description,
        code,
        issueDate: new Date(),
      },
    });
    
    return NextResponse.json({
      success: true,
      data: certificate,
      message: 'Certificado generado exitosamente',
    });
  } catch (error) {
    console.error('Create certificate error:', error);
    return NextResponse.json(
      { success: false, error: 'Error al generar certificado' },
      { status: 500 }
    );
  }
}
