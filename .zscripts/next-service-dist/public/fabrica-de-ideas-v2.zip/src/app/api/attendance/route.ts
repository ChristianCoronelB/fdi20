import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSession } from '@/lib/auth';

// GET: List attendance records (filter by userId, activityId, eventId)
export async function GET(request: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json(
        { success: false, error: 'No autorizado' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    const activityId = searchParams.get('activityId');
    const eventId = searchParams.get('eventId');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const skip = (page - 1) * limit;

    const where: any = {};

    if (userId) {
      where.userId = userId;
    }

    if (activityId) {
      where.activityId = activityId;
    }

    if (eventId) {
      where.activity = {
        eventId,
      };
    }

    const [attendances, total] = await Promise.all([
      db.attendance.findMany({
        where,
        include: {
          user: {
            select: {
              id: true,
              name: true,
              email: true,
              avatar: true,
              role: true,
            },
          },
          activity: {
            select: {
              id: true,
              title: true,
              type: true,
              startTime: true,
              endTime: true,
              room: {
                select: {
                  id: true,
                  name: true,
                },
              },
            },
          },
        },
        orderBy: { checkInTime: 'desc' },
        skip,
        take: limit,
      }),
      db.attendance.count({ where }),
    ]);

    return NextResponse.json({
      success: true,
      data: attendances,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Get attendance error:', error);
    return NextResponse.json(
      { success: false, error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}

// POST: Create attendance record (authenticated users)
export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json(
        { success: false, error: 'No autorizado' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { userId, activityId, points = 10, notes } = body;

    if (!activityId) {
      return NextResponse.json(
        { success: false, error: 'ID de actividad requerido' },
        { status: 400 }
      );
    }

    // Use the authenticated user's ID if not provided (admin only can set userId)
    const targetUserId = userId || session.userId;

    // Check if activity exists
    const activity = await db.activity.findUnique({
      where: { id: activityId },
    });

    if (!activity) {
      return NextResponse.json(
        { success: false, error: 'Actividad no encontrada' },
        { status: 404 }
      );
    }

    // Check if already attended
    const existing = await db.attendance.findUnique({
      where: {
        userId_activityId: {
          userId: targetUserId,
          activityId,
        },
      },
    });

    if (existing) {
      return NextResponse.json(
        { success: false, error: 'Ya existe un registro de asistencia' },
        { status: 400 }
      );
    }

    // Create attendance record
    const attendance = await db.attendance.create({
      data: {
        userId: targetUserId,
        activityId,
        points,
        notes,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        activity: {
          select: {
            id: true,
            title: true,
          },
        },
      },
    });

    // Update user points
    await db.user.update({
      where: { id: targetUserId },
      data: { points: { increment: points } },
    });

    // Update activity attendance count
    await db.activity.update({
      where: { id: activityId },
      data: { currentAttendance: { increment: 1 } },
    });

    return NextResponse.json({
      success: true,
      data: attendance,
    });
  } catch (error) {
    console.error('Create attendance error:', error);
    return NextResponse.json(
      { success: false, error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
