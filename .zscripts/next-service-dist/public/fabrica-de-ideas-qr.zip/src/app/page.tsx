'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard, Users, Calendar, MapPin, Award, QrCode, Settings,
  Bell, LogOut, Menu, X, ChevronRight, Plus, Minus, Edit, Trash2, Eye,
  Search, Filter, Download, Upload, Check, Clock, Star, Heart,
  Trophy, Target, Zap, TrendingUp, BarChart3, PieChart, Activity,
  User, Mail, Phone, Globe, Instagram, Twitter, Linkedin, Github,
  Camera, FileText, Medal, Gift, Sparkles, Timer, Play, Pause,
  RefreshCw, Send, MessageSquare, MoreVertical, Copy, Share2,
  Home, Building, Presentation, Lightbulb, Vote, Shield, Moon, Sun
} from 'lucide-react';
import { useTheme } from 'next-themes';
import { toast } from 'sonner';
import { cn } from '@/lib/utils-client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

// Types
interface User {
  id: string;
  email: string;
  name: string;
  role: 'ADMIN' | 'ORGANIZER' | 'MODERATOR' | 'PARTICIPANT';
  avatar?: string;
  points: number;
  level: number;
}

interface Event {
  id: string;
  name: string;
  slug?: string;
  description?: string;
  startDate: string;
  endDate: string;
  location?: string;
  address?: string;
  isActive: boolean;
  _count?: { rooms: number; activities: number; projects: number };
}

interface Room {
  id: string;
  name: string;
  capacity: number;
  building?: string;
  floor?: string;
  latitude?: number;
  longitude?: number;
  color?: string;
}

interface Activity {
  id: string;
  title: string;
  description?: string;
  type: string;
  status: string;
  startTime: string;
  endTime: string;
  room?: Room;
  speaker?: { name: string; photo?: string };
  currentAttendance: number;
}

interface Project {
  id: string;
  name: string;
  team: string;
  category?: string;
  description?: string;
  image?: string;
  totalVotes: number;
  averageScore?: number;
  status: string;
  rank?: number;
}

interface DashboardStats {
  totalUsers: number;
  totalEvents: number;
  totalActivities: number;
  totalProjects: number;
  totalVotes: number;
  totalAttendance: number;
  upcomingActivities: number;
}

// Note: Data is loaded from APIs, no mock data needed

// QR Scanner Section Component
interface ScanResult {
  type: string;
  name: string;
  points: number;
  message: string;
  activity?: { id: string; title: string; type: string; room?: { name: string } };
  room?: { id: string; name: string; building?: string; floor?: string };
  project?: { id: string; name: string; category?: string };
}

interface ScanHistoryItem {
  id: string;
  type: string;
  name: string;
  points: number;
  time: Date;
}

function QRScannerSection({ user, onScanSuccess }: { user: User | null; onScanSuccess: (result: ScanResult) => void }) {
  const [isScanning, setIsScanning] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [scanHistory, setScanHistory] = useState<ScanHistoryItem[]>([]);
  const [todayPoints, setTodayPoints] = useState(0);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const videoRef = useState<HTMLVideoElement | null>(null)[0];
  const [videoElement, setVideoElement] = useState<HTMLVideoElement | null>(null);
  const [canvasElement, setCanvasElement] = useState<HTMLCanvasElement | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const fileInputRef = useState<HTMLInputElement | null>(null)[0];
  const [fileInput, setFileInput] = useState<HTMLInputElement | null>(null);

  // Load scan history from API
  useEffect(() => {
    const loadScanHistory = async () => {
      try {
        const res = await fetch('/api/attendance?userId=' + user?.id + '&limit=5');
        if (res.ok) {
          const data = await res.json();
          if (data.success && data.data) {
            const history: ScanHistoryItem[] = data.data.map((a: { id: string; activity?: { title: string; type: string }; points: number; checkInTime: string }) => ({
              id: a.id,
              type: a.activity?.type || 'Actividad',
              name: a.activity?.title || 'Actividad',
              points: a.points || 10,
              time: new Date(a.checkInTime),
            }));
            setScanHistory(history);
          }
        }
      } catch (e) {
        console.error('Error loading scan history:', e);
      }
    };
    
    if (user) {
      loadScanHistory();
    }
  }, [user]);

  // Start camera
  const startCamera = async () => {
    setError(null);
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      setStream(mediaStream);
      setCameraActive(true);
      
      // Wait for next tick to ensure video element is rendered
      setTimeout(() => {
        if (videoElement) {
          videoElement.srcObject = mediaStream;
          videoElement.play();
        }
      }, 100);
    } catch (err) {
      console.error('Camera error:', err);
      setError('No se pudo acceder a la cámara. Verifica los permisos.');
      setCameraActive(false);
    }
  };

  // Stop camera
  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setCameraActive(false);
  };

  // Process QR scan
  const processScan = async (qrData: string) => {
    if (scanning) return;
    
    setScanning(true);
    setError(null);
    
    try {
      const res = await fetch('/api/qr/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ qrData }),
      });
      
      const data = await res.json();
      
      if (data.success) {
        setScanResult(data.data);
        setTodayPoints(prev => prev + data.data.points);
        
        // Add to history
        const newItem: ScanHistoryItem = {
          id: Date.now().toString(),
          type: data.data.type,
          name: data.data.name,
          points: data.data.points,
          time: new Date(),
        };
        setScanHistory(prev => [newItem, ...prev].slice(0, 10));
        
        // Notify parent
        onScanSuccess(data.data);
        
        // Vibrate on success if available
        if (navigator.vibrate) {
          navigator.vibrate(200);
        }
        
        toast.success(data.data.message);
      } else {
        setError(data.error || 'Error al procesar el código QR');
        toast.error(data.error || 'Error al procesar el código QR');
      }
    } catch (err) {
      console.error('Scan error:', err);
      setError('Error de conexión al procesar el código');
      toast.error('Error de conexión');
    } finally {
      setScanning(false);
    }
  };

  // Capture frame from video
  const captureFrame = () => {
    if (!videoElement || !canvasElement) return;
    
    const ctx = canvasElement.getContext('2d');
    if (!ctx) return;
    
    canvasElement.width = videoElement.videoWidth;
    canvasElement.height = videoElement.videoHeight;
    ctx.drawImage(videoElement, 0, 0);
    
    // For now, we'll use a simple approach - the user can manually enter codes
    // or we can integrate with html5-qrcode library
  };

  // Handle file upload
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setError(null);
    
    try {
      // Create a FileReader to read the image
      const reader = new FileReader();
      reader.onload = async (event) => {
        const imageUrl = event.target?.result as string;
        
        // Use an online QR decoder service
        try {
          const formData = new FormData();
          formData.append('file', file);
          
          const res = await fetch('https://api.qrserver.com/v1/read-qr-code/', {
            method: 'POST',
            body: formData,
          });
          
          const data = await res.json();
          
          if (data && data[0] && data[0].symbol && data[0].symbol[0].data) {
            const qrData = data[0].symbol[0].data;
            await processScan(qrData);
          } else {
            setError('No se pudo leer el código QR de la imagen');
            toast.error('No se encontró código QR en la imagen');
          }
        } catch (err) {
          console.error('QR decode error:', err);
          setError('Error al decodificar la imagen');
          toast.error('Error al decodificar la imagen');
        }
      };
      reader.readAsDataURL(file);
    } catch (err) {
      console.error('File upload error:', err);
      setError('Error al procesar la imagen');
    }
    
    // Reset input
    if (fileInput) {
      fileInput.value = '';
    }
  };

  // Manual code input
  const [manualCode, setManualCode] = useState('');
  
  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) return;
    await processScan(manualCode.trim());
    setManualCode('');
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [stream]);

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    if (diffMins < 1) return 'Ahora';
    if (diffMins < 60) return `Hace ${diffMins} min`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `Hace ${diffHours} hora${diffHours > 1 ? 's' : ''}`;
    const diffDays = Math.floor(diffHours / 24);
    return `Hace ${diffDays} día${diffDays > 1 ? 's' : ''}`;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Escáner QR</h1>
          <p className="text-muted-foreground">Escanea códigos QR para registrar asistencia y ganar puntos</p>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Camera className="w-5 h-5" />
              Cámara
            </CardTitle>
            <CardDescription>Apunta el código QR dentro del marco</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="aspect-square bg-gray-900 rounded-lg flex items-center justify-center relative overflow-hidden">
              {/* Video element for camera */}
              <video 
                ref={setVideoElement}
                className={cn(
                  "absolute inset-0 w-full h-full object-cover",
                  !cameraActive && "hidden"
                )}
                autoPlay
                playsInline
                muted
              />
              
              {/* Hidden canvas for frame capture */}
              <canvas ref={setCanvasElement} className="hidden" />
              
              {/* Scanner overlay */}
              {cameraActive && (
                <div className="absolute inset-4 border-2 border-white/50 rounded-lg pointer-events-none">
                  <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-emerald-500 rounded-tl-lg" />
                  <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-emerald-500 rounded-tr-lg" />
                  <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-emerald-500 rounded-bl-lg" />
                  <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-emerald-500 rounded-br-lg" />
                  
                  {/* Scanning animation */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-full h-0.5 bg-emerald-500 animate-pulse" />
                  </div>
                </div>
              )}
              
              {/* Placeholder when camera is off */}
              {!cameraActive && (
                <>
                  <div className="absolute inset-4 border-2 border-white/50 rounded-lg">
                    <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-emerald-500 rounded-tl-lg" />
                    <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-emerald-500 rounded-tr-lg" />
                    <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-emerald-500 rounded-bl-lg" />
                    <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-emerald-500 rounded-br-lg" />
                  </div>
                  <div className="text-white text-center z-10">
                    <Camera className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p className="text-sm opacity-75">Activa la cámara para escanear</p>
                  </div>
                </>
              )}
            </div>
            
            {/* Error message */}
            {error && (
              <Alert className="mt-4 bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800">
                <AlertDescription className="text-red-600 dark:text-red-400">{error}</AlertDescription>
              </Alert>
            )}
            
            <div className="mt-4 flex gap-2">
              {cameraActive ? (
                <Button 
                  className="flex-1 bg-red-500 hover:bg-red-600"
                  onClick={stopCamera}
                >
                  <X className="w-4 h-4 mr-2" />
                  Detener Cámara
                </Button>
              ) : (
                <Button 
                  className="flex-1 bg-gradient-to-r from-emerald-500 to-teal-600"
                  onClick={startCamera}
                  disabled={scanning}
                >
                  <Camera className="w-4 h-4 mr-2" />
                  Activar Cámara
                </Button>
              )}
              <Button 
                variant="outline"
                onClick={() => fileInput?.click()}
                disabled={scanning}
              >
                <Upload className="w-4 h-4 mr-2" />
                Subir Imagen
              </Button>
              <input
                ref={setFileInput}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleFileUpload}
              />
            </div>
            
            {/* Manual code input */}
            <div className="mt-4">
              <p className="text-sm text-muted-foreground mb-2">O ingresa el código manualmente:</p>
              <form onSubmit={handleManualSubmit} className="flex gap-2">
                <Input
                  value={manualCode}
                  onChange={(e) => setManualCode(e.target.value)}
                  placeholder="Ejemplo: {&quot;type&quot;:&quot;ACTIVITY&quot;,&quot;id&quot;:&quot;...&quot;}"
                  className="flex-1"
                />
                <Button type="submit" disabled={scanning || !manualCode.trim()}>
                  {scanning ? <RefreshCw className="w-4 h-4 animate-spin" /> : <QrCode className="w-4 h-4" />}
                </Button>
              </form>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-4">
          {/* Scan result */}
          {scanResult && (
            <Card className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white border-0">
              <CardContent className="pt-6">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-full bg-white/20 flex items-center justify-center">
                    <Check className="w-8 h-8" />
                  </div>
                  <div>
                    <p className="text-sm opacity-90">{scanResult.type}</p>
                    <p className="text-xl font-bold">{scanResult.name}</p>
                    <p className="text-sm opacity-90">{scanResult.message}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
          
          <Card>
            <CardHeader>
              <CardTitle>Últimos Escaneos</CardTitle>
            </CardHeader>
            <CardContent>
              {scanHistory.length > 0 ? (
                <div className="space-y-3">
                  {scanHistory.map((scan) => (
                    <div key={scan.id} className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <div className="w-10 h-10 rounded-full bg-emerald-500/10 flex items-center justify-center">
                        <Check className="w-5 h-5 text-emerald-500" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium">{scan.name}</p>
                        <p className="text-xs text-muted-foreground">{scan.type} • {formatTimeAgo(scan.time)}</p>
                      </div>
                      <Badge className="bg-emerald-500">+{scan.points} pts</Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6 text-muted-foreground">
                  <QrCode className="w-10 h-10 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">Aún no tienes escaneos registrados</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-amber-500 to-orange-600 text-white">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
                  <Zap className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-sm opacity-90">Puntos ganados hoy</p>
                  <p className="text-3xl font-bold">+{todayPoints}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

// Helper functions
const getInitials = (name: string) => name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);

const getStatusColor = (status: string) => {
  const colors: Record<string, string> = {
    SCHEDULED: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
    IN_PROGRESS: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
    COMPLETED: 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300',
    CANCELLED: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
    APPROVED: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-300',
    DRAFT: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
    FINALIST: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300',
    WINNER: 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300',
  };
  return colors[status] || 'bg-gray-100 text-gray-800';
};

const getActivityTypeColor = (type: string) => {
  const colors: Record<string, string> = {
    KEYNOTE: 'bg-purple-500',
    WORKSHOP: 'bg-blue-500',
    PANEL: 'bg-green-500',
    PRESENTATION: 'bg-orange-500',
    NETWORKING: 'bg-pink-500',
    BREAK: 'bg-gray-500',
  };
  return colors[type] || 'bg-indigo-500';
};

const getTypeLabel = (type: string) => {
  const labels: Record<string, string> = {
    KEYNOTE: 'Conferencia',
    WORKSHOP: 'Taller',
    PANEL: 'Panel',
    PRESENTATION: 'Presentación',
    NETWORKING: 'Networking',
    BREAK: 'Descanso',
  };
  return labels[type] || type;
};

const getRoleLabel = (role: string) => {
  const labels: Record<string, string> = {
    ADMIN: 'Administrador',
    ORGANIZER: 'Organizador',
    MODERATOR: 'Moderador',
    PARTICIPANT: 'Participante',
  };
  return labels[role] || role;
};

const getRoleColor = (role: string) => {
  const colors: Record<string, string> = {
    ADMIN: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
    ORGANIZER: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300',
    MODERATOR: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
    PARTICIPANT: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
  };
  return colors[role] || 'bg-gray-100 text-gray-800';
};

const formatTime = (dateStr: string) => {
  const date = new Date(dateStr);
  return date.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });
};

const formatDate = (dateStr: string) => {
  const date = new Date(dateStr);
  return date.toLocaleDateString('es-ES', { weekday: 'short', day: 'numeric', month: 'short' });
};

// Main App Component
export default function FabricaDeIdeasApp() {
  const { theme, setTheme } = useTheme();
  const [currentView, setCurrentView] = useState<'admin' | 'user'>('user');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [user, setUser] = useState<User | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [loading, setLoading] = useState(false);
  
  // Form states
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [registerName, setRegisterName] = useState('');
  const [registerEmail, setRegisterEmail] = useState('');
  const [registerPassword, setRegisterPassword] = useState('');
  const [showLogin, setShowLogin] = useState(true);
  
  // Data states
  const [events, setEvents] = useState<Event[]>([]);
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [dashboardStats, setDashboardStats] = useState<DashboardStats>({
    totalUsers: 0,
    totalEvents: 0,
    totalActivities: 0,
    totalProjects: 0,
    totalVotes: 0,
    totalAttendance: 0,
    upcomingActivities: 0,
  });
  const [leaderboard, setLeaderboard] = useState<{ rank: number; name: string; points: number; level: number; avatar?: string }[]>([]);
  const [roomsList, setRoomsList] = useState<Room[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loadingData, setLoadingData] = useState(true);

  // Certificates states
  const [certificates, setCertificates] = useState<any[]>([]);
  const [canGenerateCertificate, setCanGenerateCertificate] = useState(false);
  const [generatingCertificate, setGeneratingCertificate] = useState(false);
  const [attendanceCount, setAttendanceCount] = useState(0);

  // Achievements states
  const [earnedAchievements, setEarnedAchievements] = useState<any[]>([]);
  const [availableAchievements, setAvailableAchievements] = useState<any[]>([]);
  const [achievementStats, setAchievementStats] = useState({ attendanceCount: 0, voteCount: 0, points: 0, level: 1 });

  // Event form states
  const [eventDialogOpen, setEventDialogOpen] = useState(false);
  const [eventForm, setEventForm] = useState({
    name: '',
    slug: '',
    description: '',
    startDate: '',
    startTime: '09:00',
    endDate: '',
    endTime: '18:00',
    location: '',
    address: '',
    isActive: true,
  });
  const [savingEvent, setSavingEvent] = useState(false);
  const [editingEvent, setEditingEvent] = useState<Event | null>(null);
  const [deleteEventDialogOpen, setDeleteEventDialogOpen] = useState(false);
  const [deletingEvent, setDeletingEvent] = useState(false);

  // Activity form states
  const [activityDialogOpen, setActivityDialogOpen] = useState(false);
  const [activityForm, setActivityForm] = useState({
    title: '',
    description: '',
    type: 'PRESENTATION',
    roomId: '',
    startTime: '',
    endTime: '',
    date: '',
    maxCapacity: '',
    theme: '',
    speakerId: '',
    generateQr: true,
  });
  const [savingActivity, setSavingActivity] = useState(false);

  // Load data from APIs
  const loadDataFromAPIs = async () => {
    setLoadingData(true);
    try {
      // Load events
      const eventsRes = await fetch('/api/events?limit=100');
      if (eventsRes.ok) {
        const eventsData = await eventsRes.json();
        if (eventsData.success) {
          const loadedEvents = eventsData.data.events || eventsData.data || [];
          setEvents(loadedEvents);
          if (loadedEvents.length > 0 && !selectedEvent) {
            setSelectedEvent(loadedEvents[0]);
          }
        }
      }

      // Load rooms
      const roomsRes = await fetch('/api/rooms?limit=100');
      if (roomsRes.ok) {
        const roomsData = await roomsRes.json();
        if (roomsData.success) {
          setRooms(roomsData.data.rooms || roomsData.data || []);
          setRoomsList(roomsData.data.rooms || roomsData.data || []);
        }
      }

      // Load activities
      const activitiesRes = await fetch('/api/activities?limit=100');
      if (activitiesRes.ok) {
        const activitiesData = await activitiesRes.json();
        if (activitiesData.success) {
          setActivities(activitiesData.data.activities || activitiesData.data || []);
        }
      }

      // Load projects
      const projectsRes = await fetch('/api/projects?limit=100');
      if (projectsRes.ok) {
        const projectsData = await projectsRes.json();
        if (projectsData.success) {
          setProjects(projectsData.data || []);
        }
      }

      // Load dashboard stats
      const dashboardRes = await fetch('/api/dashboard');
      if (dashboardRes.ok) {
        const dashboardData = await dashboardRes.json();
        if (dashboardData.success && dashboardData.data) {
          setDashboardStats({
            totalUsers: dashboardData.data.stats?.totalUsers || 0,
            totalEvents: dashboardData.data.stats?.totalEvents || 0,
            totalActivities: dashboardData.data.stats?.totalActivities || 0,
            totalProjects: dashboardData.data.stats?.totalProjects || 0,
            totalVotes: dashboardData.data.stats?.totalVotes || 0,
            totalAttendance: dashboardData.data.stats?.totalAttendance || 0,
            upcomingActivities: dashboardData.data.upcomingActivities?.length || 0,
          });
          // Also use leaderboard from dashboard if available
          if (dashboardData.data.leaderboard && dashboardData.data.leaderboard.length > 0) {
            setLeaderboard(dashboardData.data.leaderboard.map((u: { name: string; points: number; level: number; avatar?: string }, i: number) => ({
              rank: i + 1,
              name: u.name,
              points: u.points,
              level: u.level,
              avatar: u.avatar,
            })));
          }
        }
      }

      // Load users for leaderboard (fallback if dashboard doesn't have enough)
      const usersRes = await fetch('/api/users?limit=10');
      if (usersRes.ok) {
        const usersData = await usersRes.json();
        if (usersData.success && usersData.data && usersData.data.length > 0) {
          // Only use if leaderboard is empty
          if (leaderboard.length === 0) {
            const topUsers = usersData.data.slice(0, 5).map((u: { name: string; points: number; level: number; avatar?: string }, i: number) => ({
              rank: i + 1,
              name: u.name,
              points: u.points,
              level: u.level,
              avatar: u.avatar,
            }));
            setLeaderboard(topUsers);
          }
        }
      }
    } catch (error) {
      console.error('Error loading data:', error);
    }
    setLoadingData(false);
  };

  // Load certificates and achievements data
  const loadUserData = async () => {
    try {
      // Load certificates
      const certRes = await fetch('/api/certificates');
      if (certRes.ok) {
        const certData = await certRes.json();
        if (certData.success) {
          setCertificates(certData.data || []);
        }
      }

      // Load attendance count for certificate eligibility
      const attendanceRes = await fetch('/api/attendance');
      if (attendanceRes.ok) {
        const attendanceData = await attendanceRes.json();
        if (attendanceData.success) {
          const attendances = attendanceData.data || [];
          const completeAttendances = attendances.filter((a: any) => a.checkOutTime);
          setAttendanceCount(completeAttendances.length);
          setCanGenerateCertificate(completeAttendances.length >= 3);
        }
      }

      // Load achievements
      const achievementsRes = await fetch('/api/achievements');
      if (achievementsRes.ok) {
        const achievementsData = await achievementsRes.json();
        if (achievementsData.success) {
          setEarnedAchievements(achievementsData.data.earned || []);
          setAvailableAchievements(achievementsData.data.available || []);
          setAchievementStats(achievementsData.data.stats || { attendanceCount: 0, voteCount: 0, points: 0, level: 1 });
        }
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    }
  };

  // Generate certificate
  const handleGenerateCertificate = async () => {
    setGeneratingCertificate(true);
    try {
      const res = await fetch('/api/certificates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'attendance' }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success('¡Certificado generado exitosamente!');
        loadUserData();
      } else {
        toast.error(data.error || 'Error al generar certificado');
      }
    } catch (error) {
      toast.error('Error de conexión');
    }
    setGeneratingCertificate(false);
  };

  // Event management functions
  const handleCreateEvent = async () => {
    if (!eventForm.name.trim()) {
      toast.error('El nombre del evento es requerido');
      return;
    }
    if (!eventForm.startDate || !eventForm.endDate) {
      toast.error('Las fechas de inicio y fin son requeridas');
      return;
    }

    setSavingEvent(true);
    try {
      const startDateTime = `${eventForm.startDate}T${eventForm.startTime}:00`;
      const endDateTime = `${eventForm.endDate}T${eventForm.endTime}:00`;
      
      const slug = eventForm.slug || eventForm.name.toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');

      const res = await fetch('/api/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: eventForm.name,
          slug,
          description: eventForm.description,
          startDate: startDateTime,
          endDate: endDateTime,
          location: eventForm.location,
          address: eventForm.address,
          isActive: eventForm.isActive,
        }),
      });

      const data = await res.json();
      if (data.success) {
        toast.success('¡Evento creado exitosamente!');
        loadDataFromAPIs();
        setEventDialogOpen(false);
        resetEventForm();
      } else {
        toast.error(data.error || 'Error al crear evento');
      }
    } catch (error) {
      toast.error('Error de conexión');
    }
    setSavingEvent(false);
  };

  const handleUpdateEvent = async () => {
    if (!editingEvent) return;
    if (!eventForm.name.trim()) {
      toast.error('El nombre del evento es requerido');
      return;
    }

    setSavingEvent(true);
    try {
      const startDateTime = `${eventForm.startDate}T${eventForm.startTime}:00`;
      const endDateTime = `${eventForm.endDate}T${eventForm.endTime}:00`;

      const res = await fetch(`/api/events/${editingEvent.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: eventForm.name,
          slug: eventForm.slug,
          description: eventForm.description,
          startDate: startDateTime,
          endDate: endDateTime,
          location: eventForm.location,
          address: eventForm.address,
          isActive: eventForm.isActive,
        }),
      });

      const data = await res.json();
      if (data.success) {
        toast.success('¡Evento actualizado exitosamente!');
        loadDataFromAPIs();
        setEventDialogOpen(false);
        resetEventForm();
      } else {
        toast.error(data.error || 'Error al actualizar evento');
      }
    } catch (error) {
      toast.error('Error de conexión');
    }
    setSavingEvent(false);
  };

  const handleDeleteEvent = async () => {
    if (!editingEvent) return;

    setDeletingEvent(true);
    try {
      const res = await fetch(`/api/events/${editingEvent.id}`, {
        method: 'DELETE',
      });

      const data = await res.json();
      if (data.success) {
        toast.success('Evento eliminado exitosamente');
        loadDataFromAPIs();
        setDeleteEventDialogOpen(false);
        setEditingEvent(null);
      } else {
        toast.error(data.error || 'Error al eliminar evento');
      }
    } catch (error) {
      toast.error('Error de conexión');
    }
    setDeletingEvent(false);
  };

  const resetEventForm = () => {
    setEventForm({
      name: '',
      slug: '',
      description: '',
      startDate: '',
      startTime: '09:00',
      endDate: '',
      endTime: '18:00',
      location: '',
      address: '',
      isActive: true,
    });
    setEditingEvent(null);
  };

  const openEditEventDialog = (event: Event) => {
    setEditingEvent(event);
    const startDate = new Date(event.startDate);
    const endDate = new Date(event.endDate);
    setEventForm({
      name: event.name,
      slug: event.slug || '',
      description: event.description || '',
      startDate: startDate.toISOString().split('T')[0],
      startTime: startDate.toTimeString().slice(0, 5),
      endDate: endDate.toISOString().split('T')[0],
      endTime: endDate.toTimeString().slice(0, 5),
      location: event.location || '',
      address: '',
      isActive: event.isActive,
    });
    setEventDialogOpen(true);
  };

  const openNewEventDialog = () => {
    resetEventForm();
    setEventDialogOpen(true);
  };

  // Check session on mount
  useEffect(() => {
    const checkSession = async () => {
      try {
        const res = await fetch('/api/auth/me');
        if (res.ok) {
          const data = await res.json();
          if (data.success) {
            setUser(data.data);
            setIsLoggedIn(true);
            // Load data after successful session check
            loadDataFromAPIs();
            // Load user specific data
            loadUserData();
          }
        }
      } catch {
        // Not logged in
      }
    };
    checkSession();
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: loginEmail, password: loginPassword }),
      });
      const data = await res.json();
      if (data.success) {
        setUser(data.data.user);
        setIsLoggedIn(true);
        toast.success('¡Bienvenido de vuelta!');
        // Load data after successful login
        loadDataFromAPIs();
        loadUserData();
      } else {
        toast.error(data.error || 'Error al iniciar sesión');
      }
    } catch {
      toast.error('Error de conexión');
    }
    setLoading(false);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          email: registerEmail, 
          password: registerPassword, 
          name: registerName 
        }),
      });
      const data = await res.json();
      if (data.success) {
        setUser(data.data.user);
        setIsLoggedIn(true);
        toast.success('¡Cuenta creada exitosamente!');
        // Load data after successful registration
        loadDataFromAPIs();
        loadUserData();
      } else {
        toast.error(data.error || 'Error al crear cuenta');
      }
    } catch {
      toast.error('Error de conexión');
    }
    setLoading(false);
  };

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    setUser(null);
    setIsLoggedIn(false);
    toast.success('Sesión cerrada');
  };

  // Create activity function
  const handleCreateActivity = async () => {
    // Validate required fields
    if (!activityForm.title.trim()) {
      toast.error('El título es requerido');
      return;
    }
    if (!activityForm.startTime) {
      toast.error('La hora de inicio es requerida');
      return;
    }
    if (!activityForm.endTime) {
      toast.error('La hora de fin es requerida');
      return;
    }
    if (!activityForm.date) {
      toast.error('La fecha es requerida');
      return;
    }

    // Check for event
    if (!selectedEvent) {
      toast.error('Selecciona un evento primero');
      return;
    }

    setSavingActivity(true);
    try {
      // Create datetime strings
      const startDateTime = `${activityForm.date}T${activityForm.startTime}:00`;
      const endDateTime = `${activityForm.date}T${activityForm.endTime}:00`;

      // Use first room if none selected
      const roomId = activityForm.roomId || rooms[0]?.id;
      
      if (!roomId) {
        toast.error('No hay salas disponibles. Crea una sala primero.');
        setSavingActivity(false);
        return;
      }

      // Save to API
      const res = await fetch('/api/activities', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: activityForm.title,
          description: activityForm.description,
          type: activityForm.type,
          roomId: roomId,
          startTime: startDateTime,
          endTime: endDateTime,
          maxCapacity: activityForm.maxCapacity ? parseInt(activityForm.maxCapacity) : null,
          theme: activityForm.theme,
          status: 'SCHEDULED',
          eventId: selectedEvent.id,
        }),
      });

      const data = await res.json();
      
      if (data.success && data.data) {
        // Reload activities from API
        await loadDataFromAPIs();
        
        // Reset form and close dialog
        setActivityForm({
          title: '',
          description: '',
          type: 'PRESENTATION',
          roomId: '',
          startTime: '',
          endTime: '',
          date: '',
          maxCapacity: '',
          theme: '',
          speakerId: '',
          generateQr: true,
        });
        setActivityDialogOpen(false);
        
        toast.success('¡Actividad creada exitosamente!');
      } else {
        toast.error(data.error || 'Error al crear actividad');
      }
    } catch (error) {
      console.error('Error creating activity:', error);
      toast.error('Error al crear actividad. Intenta de nuevo.');
    }
    setSavingActivity(false);
  };

  // Reset activity form
  const resetActivityForm = () => {
    setActivityForm({
      title: '',
      description: '',
      type: 'PRESENTATION',
      roomId: '',
      startTime: '',
      endTime: '',
      date: '',
      maxCapacity: '',
      theme: '',
      speakerId: '',
      generateQr: true,
    });
  };

  // Reminder and registration states
  const [reminderDialogOpen, setReminderDialogOpen] = useState(false);
  const [registerDialogOpen, setRegisterDialogOpen] = useState(false);
  const [selectedActivityForAction, setSelectedActivityForAction] = useState<Activity | null>(null);
  const [reminderMinutes, setReminderMinutes] = useState('15');
  const [settingReminder, setSettingReminder] = useState(false);
  const [registeringAttendance, setRegisteringAttendance] = useState(false);
  const [userReminders, setUserReminders] = useState<Record<string, { minutes: number; set: boolean }>>({});
  const [userAttendance, setUserAttendance] = useState<Record<string, boolean>>({});

  // Handle set reminder
  const handleSetReminder = (activity: Activity) => {
    setSelectedActivityForAction(activity);
    setReminderDialogOpen(true);
  };

  // Confirm reminder
  const handleConfirmReminder = async () => {
    if (!selectedActivityForAction) return;
    
    setSettingReminder(true);
    
    // Simulate saving reminder
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const minutes = parseInt(reminderMinutes);
    setUserReminders(prev => ({
      ...prev,
      [selectedActivityForAction.id]: { minutes, set: true }
    }));
    
    setReminderDialogOpen(false);
    setSettingReminder(false);
    
    // Show notification
    if ('Notification' in window && Notification.permission === 'granted') {
      // In a real app, we would schedule the notification
    }
    
    toast.success(`Recordatorio configurado: ${minutes} minutos antes de "${selectedActivityForAction.title}"`);
  };

  // Handle register attendance
  const handleRegisterAttendance = (activity: Activity) => {
    setSelectedActivityForAction(activity);
    setRegisterDialogOpen(true);
  };

  // Confirm attendance registration
  const handleConfirmAttendance = async () => {
    if (!selectedActivityForAction) return;
    
    setRegisteringAttendance(true);
    
    try {
      // Try to register via API
      try {
        const res = await fetch('/api/attendance', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            activityId: selectedActivityForAction.id,
            userId: user?.id,
          }),
        });
        
        const data = await res.json();
        if (data.success) {
          setUserAttendance(prev => ({
            ...prev,
            [selectedActivityForAction.id]: true
          }));
          toast.success(`Asistencia registrada a "${selectedActivityForAction.title}"`);
        } else {
          // Mark as attended locally anyway for demo
          setUserAttendance(prev => ({
            ...prev,
            [selectedActivityForAction.id]: true
          }));
          toast.success(`Asistencia registrada a "${selectedActivityForAction.title}"`);
        }
      } catch {
        // Mark as attended locally for demo
        setUserAttendance(prev => ({
          ...prev,
          [selectedActivityForAction.id]: true
        }));
        toast.success(`Asistencia registrada a "${selectedActivityForAction.title}"`);
      }
    } catch (error) {
      console.error('Error registering attendance:', error);
      toast.error('Error al registrar asistencia');
    }
    
    setRegisterDialogOpen(false);
    setRegisteringAttendance(false);
  };

  // Request notification permission
  const requestNotificationPermission = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    try {
      if (!('Notification' in window)) {
        toast.error('Tu navegador no soporta notificaciones');
        return;
      }
      
      const permission = await Notification.requestPermission();
      
      if (permission === 'granted') {
        toast.success('✅ Notificaciones activadas correctamente');
        // Show test notification
        new Notification('¡Notificaciones activadas!', {
          body: 'Recibirás recordatorios de tus actividades',
          icon: '/logo.svg',
        });
      } else if (permission === 'denied') {
        toast.error('❌ Permiso denegado. Activa las notificaciones en la configuración del navegador');
      } else {
        toast.warning('⚠️ No se pudo obtener el permiso para notificaciones');
      }
    } catch (error) {
      console.error('Error requesting notification permission:', error);
      toast.error('Error al solicitar permiso de notificaciones');
    }
  };

  // User management states
  const [editUserDialogOpen, setEditUserDialogOpen] = useState(false);
  const [viewUserDialogOpen, setViewUserDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<{
    id: string;
    name: string;
    email: string;
    role: string;
    points: number;
    level: number;
    status: string;
  } | null>(null);
  const [editUserForm, setEditUserForm] = useState({
    name: '',
    email: '',
    role: 'PARTICIPANT',
    status: 'active',
  });
  const [savingUser, setSavingUser] = useState(false);

  // Handle edit user
  const handleEditUser = (entry: { name: string; points: number; level: number }, index: number) => {
    const userData = {
      id: `user-${index}`,
      name: entry.name,
      email: `${entry.name.toLowerCase().replace(' ', '.')}@email.com`,
      role: 'PARTICIPANT',
      points: entry.points,
      level: entry.level,
      status: 'active',
    };
    setSelectedUser(userData);
    setEditUserForm({
      name: userData.name,
      email: userData.email,
      role: userData.role,
      status: userData.status,
    });
    setEditUserDialogOpen(true);
  };

  // Handle view user
  const handleViewUser = (entry: { name: string; points: number; level: number }, index: number) => {
    const userData = {
      id: `user-${index}`,
      name: entry.name,
      email: `${entry.name.toLowerCase().replace(' ', '.')}@email.com`,
      role: 'PARTICIPANT',
      points: entry.points,
      level: entry.level,
      status: 'active',
    };
    setSelectedUser(userData);
    setViewUserDialogOpen(true);
  };

  // Save user changes
  const handleSaveUser = async () => {
    if (!selectedUser) return;
    
    setSavingUser(true);
    
    // Simulate saving
    await new Promise(resolve => setTimeout(resolve, 500));
    
    setEditUserDialogOpen(false);
    setSavingUser(false);
    toast.success(`Usuario "${editUserForm.name}" actualizado correctamente`);
  };

  // Map states
  const [mapZoom, setMapZoom] = useState(1);
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const [roomDialogOpen, setRoomDialogOpen] = useState(false);
  const [roomLocationDialogOpen, setRoomLocationDialogOpen] = useState(false);
  const [showMyLocation, setShowMyLocation] = useState(false);
  const [myLocation, setMyLocation] = useState<{ lat: number; lng: number } | null>(null);

  // Handle room click on map
  const handleRoomClick = (room: Room) => {
    setSelectedRoom(room);
    setRoomDialogOpen(true);
  };

  // Handle get directions to room
  const handleGetDirections = (room: Room) => {
    setRoomDialogOpen(false);
    setSelectedRoom(room);
    setRoomLocationDialogOpen(true);
  };

  // Handle zoom in
  const handleZoomIn = () => {
    setMapZoom(prev => Math.min(prev + 0.2, 2));
  };

  // Handle zoom out
  const handleZoomOut = () => {
    setMapZoom(prev => Math.max(prev - 0.2, 0.5));
  };

  // Handle show my location
  const handleShowMyLocation = () => {
    if (!navigator.geolocation) {
      toast.error('Tu navegador no soporta geolocalización');
      return;
    }

    setShowMyLocation(true);
    
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setMyLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
        toast.success('Ubicación obtenida correctamente');
      },
      (error) => {
        console.error('Error getting location:', error);
        toast.error('No se pudo obtener tu ubicación. Verifica los permisos.');
        setShowMyLocation(false);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  // Open external maps for directions
  const openExternalMap = (room: Room) => {
    // Using the venue location as default (can be customized)
    const venueLat = room.latitude || -33.45;
    const venueLng = room.longitude || -70.67;
    const mapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${venueLat},${venueLng}&destination_name=${encodeURIComponent(room.name)}`;
    window.open(mapsUrl, '_blank');
    toast.success('Abriendo Google Maps...');
  };

  // Room management states
  const [editRoomDialogOpen, setEditRoomDialogOpen] = useState(false);
  const [qrRoomDialogOpen, setQrRoomDialogOpen] = useState(false);
  const [deleteRoomDialogOpen, setDeleteRoomDialogOpen] = useState(false);
  const [mapRoomDialogOpen, setMapRoomDialogOpen] = useState(false);
  const [selectedRoomForEdit, setSelectedRoomForEdit] = useState<Room | null>(null);
  const [roomForm, setRoomForm] = useState({
    name: '',
    capacity: '',
    building: '',
    floor: '',
    color: '#3B82F6',
  });
  const [savingRoom, setSavingRoom] = useState(false);
  const [deletingRoom, setDeletingRoom] = useState(false);
  const [roomQrCode, setRoomQrCode] = useState<string>('');

  // Handle edit room
  const handleEditRoom = (room: Room) => {
    setSelectedRoomForEdit(room);
    setRoomForm({
      name: room.name,
      capacity: room.capacity.toString(),
      building: room.building || '',
      floor: room.floor || '',
      color: room.color || '#3B82F6',
    });
    setEditRoomDialogOpen(true);
  };

  // Handle save room
  const handleSaveRoom = async () => {
    if (!roomForm.name.trim()) {
      toast.error('El nombre de la sala es requerido');
      return;
    }

    if (!selectedEvent) {
      toast.error('Selecciona un evento primero');
      return;
    }

    setSavingRoom(true);
    
    try {
      if (selectedRoomForEdit) {
        // Update existing room via API
        const res = await fetch(`/api/rooms/${selectedRoomForEdit.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: roomForm.name,
            capacity: parseInt(roomForm.capacity) || 50,
            building: roomForm.building,
            floor: roomForm.floor,
            color: roomForm.color,
          }),
        });

        const data = await res.json();
        
        if (data.success) {
          await loadDataFromAPIs();
          toast.success(`Sala "${roomForm.name}" actualizada correctamente`);
        } else {
          toast.error(data.error || 'Error al actualizar sala');
        }
      } else {
        // Create new room via API
        const res = await fetch('/api/rooms', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: roomForm.name,
            capacity: parseInt(roomForm.capacity) || 50,
            building: roomForm.building,
            floor: roomForm.floor,
            color: roomForm.color,
            eventId: selectedEvent.id,
          }),
        });

        const data = await res.json();
        
        if (data.success) {
          await loadDataFromAPIs();
          toast.success(`Sala "${roomForm.name}" creada correctamente`);
        } else {
          toast.error(data.error || 'Error al crear sala');
        }
      }
      
      setEditRoomDialogOpen(false);
      setSelectedRoomForEdit(null);
      setRoomForm({ name: '', capacity: '', building: '', floor: '', color: '#3B82F6' });
    } catch (error) {
      console.error('Error saving room:', error);
      toast.error('Error al guardar sala');
    }
    
    setSavingRoom(false);
  };

  // Handle generate QR for room
  const handleGenerateRoomQR = (room: Room) => {
    setSelectedRoomForEdit(room);
    // Generate a simple QR code URL (in production, use a real QR library)
    const qrData = `ROOM:${room.id}:${room.name}:${room.building || ''}:${room.floor || ''}`;
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(qrData)}`;
    setRoomQrCode(qrUrl);
    setQrRoomDialogOpen(true);
  };

  // Handle show room on map
  const handleShowRoomMap = (room: Room) => {
    setSelectedRoomForEdit(room);
    setMapRoomDialogOpen(true);
  };

  // Handle delete room
  const handleDeleteRoom = async () => {
    if (!selectedRoomForEdit) return;
    
    setDeletingRoom(true);
    
    try {
      const res = await fetch(`/api/rooms/${selectedRoomForEdit.id}`, {
        method: 'DELETE',
      });

      const data = await res.json();
      
      if (data.success) {
        await loadDataFromAPIs();
        toast.success('Sala eliminada correctamente');
      } else {
        toast.error(data.error || 'Error al eliminar sala');
      }
    } catch (error) {
      console.error('Error deleting room:', error);
      toast.error('Error al eliminar sala');
    }
    
    setDeleteRoomDialogOpen(false);
    setDeletingRoom(false);
    setSelectedRoomForEdit(null);
  };

  // Handle new room
  const handleNewRoom = () => {
    setSelectedRoomForEdit(null);
    setRoomForm({ name: '', capacity: '', building: '', floor: '', color: '#3B82F6' });
    setEditRoomDialogOpen(true);
  };

  // Auth Screen
  if (!isLoggedIn) {
    return (
      <div className="min-h-screen flex flex-col bg-gradient-to-br from-emerald-50 via-white to-teal-50 dark:from-gray-950 dark:via-gray-900 dark:to-gray-950">
        {/* Header */}
        <header className="w-full py-4 px-6 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
              <Lightbulb className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
              Fábrica de Ideas
            </span>
          </div>
          <Button variant="ghost" size="icon" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
            {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </Button>
        </header>

        {/* Main Content */}
        <main className="flex-1 flex items-center justify-center p-6">
          <div className="w-full max-w-md">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Card className="border-0 shadow-2xl bg-white/80 dark:bg-gray-900/80 backdrop-blur-xl">
                <CardHeader className="text-center pb-2">
                  <CardTitle className="text-2xl font-bold">
                    {showLogin ? 'Bienvenido' : 'Crear Cuenta'}
                  </CardTitle>
                  <CardDescription>
                    {showLogin 
                      ? 'Inicia sesión para participar en el evento' 
                      : 'Únete a la comunidad de innovadores'}
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-4">
                  <Tabs value={showLogin ? 'login' : 'register'} onValueChange={(v) => setShowLogin(v === 'login')}>
                    <TabsContent value="login" className="mt-0">
                      <form onSubmit={handleLogin} className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="email">Email</Label>
                          <Input
                            id="email"
                            type="email"
                            placeholder="tu@email.com"
                            value={loginEmail}
                            onChange={(e) => setLoginEmail(e.target.value)}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="password">Contraseña</Label>
                          <Input
                            id="password"
                            type="password"
                            placeholder="••••••••"
                            value={loginPassword}
                            onChange={(e) => setLoginPassword(e.target.value)}
                            required
                          />
                        </div>
                        <Button type="submit" className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700" disabled={loading}>
                          {loading ? 'Iniciando...' : 'Iniciar Sesión'}
                        </Button>
                      </form>
                    </TabsContent>
                    
                    <TabsContent value="register" className="mt-0">
                      <form onSubmit={handleRegister} className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="reg-name">Nombre completo</Label>
                          <Input
                            id="reg-name"
                            type="text"
                            placeholder="Tu nombre"
                            value={registerName}
                            onChange={(e) => setRegisterName(e.target.value)}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="reg-email">Email</Label>
                          <Input
                            id="reg-email"
                            type="email"
                            placeholder="tu@email.com"
                            value={registerEmail}
                            onChange={(e) => setRegisterEmail(e.target.value)}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="reg-password">Contraseña</Label>
                          <Input
                            id="reg-password"
                            type="password"
                            placeholder="Mínimo 6 caracteres"
                            value={registerPassword}
                            onChange={(e) => setRegisterPassword(e.target.value)}
                            required
                          />
                        </div>
                        <Button type="submit" className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700" disabled={loading}>
                          {loading ? 'Creando...' : 'Crear Cuenta'}
                        </Button>
                      </form>
                    </TabsContent>
                  </Tabs>
                  
                  <div className="mt-6">
                    <Separator />
                    <div className="mt-4 text-center text-sm text-muted-foreground">
                      {showLogin ? (
                        <p>
                          ¿No tienes cuenta?{' '}
                          <Button variant="link" className="p-0 h-auto" onClick={() => setShowLogin(false)}>
                            Regístrate aquí
                          </Button>
                        </p>
                      ) : (
                        <p>
                          ¿Ya tienes cuenta?{' '}
                          <Button variant="link" className="p-0 h-auto" onClick={() => setShowLogin(true)}>
                            Inicia sesión
                          </Button>
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Demo credentials */}
              <Alert className="mt-4 bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
                <Sparkles className="h-4 w-4" />
                <AlertTitle>Credenciales de prueba</AlertTitle>
                <AlertDescription className="text-sm">
                  Email: <code className="bg-blue-100 dark:bg-blue-900 px-1 rounded">admin@fabricadeideas.com</code>
                  <br />
                  Password: <code className="bg-blue-100 dark:bg-blue-900 px-1 rounded">admin123</code>
                </AlertDescription>
              </Alert>
            </motion.div>
          </div>
        </main>

        {/* Footer */}
        <footer className="py-6 text-center text-sm text-muted-foreground">
          <p>© 2024 Fábrica de Ideas. Todos los derechos reservados.</p>
        </footer>
      </div>
    );
  }

  // Main Application
  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-950">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 dark:bg-gray-900/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 dark:supports-[backdrop-filter]:bg-gray-900/60">
        <div className="flex h-16 items-center px-4 gap-4">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(!sidebarOpen)}>
              <Menu className="w-5 h-5" />
            </Button>
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
              <Lightbulb className="w-5 h-5 text-white" />
            </div>
            <span className="hidden sm:inline text-lg font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
              Fábrica de Ideas
            </span>
          </div>

          {/* View Switcher */}
          <div className="flex items-center gap-2 ml-auto">
            <div className="hidden sm:flex items-center gap-1 p-1 bg-gray-100 dark:bg-gray-800 rounded-lg">
              <Button
                variant="ghost"
                size="sm"
                className={cn("gap-2", currentView === 'user' && "bg-white dark:bg-gray-700 shadow-sm")}
                onClick={() => setCurrentView('user')}
              >
                <User className="w-4 h-4" />
                Participante
              </Button>
              {(user?.role === 'ADMIN' || user?.role === 'ORGANIZER' || user?.role === 'MODERATOR') && (
                <Button
                  variant="ghost"
                  size="sm"
                  className={cn("gap-2", currentView === 'admin' && "bg-white dark:bg-gray-700 shadow-sm")}
                  onClick={() => setCurrentView('admin')}
                >
                  <Shield className="w-4 h-4" />
                  Admin
                </Button>
              )}
            </div>
            
            <Button variant="ghost" size="icon" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
              {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </Button>

            {/* Notifications */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="relative">
                  <Bell className="w-5 h-5" />
                  <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <SheetHeader>
                  <SheetTitle>Notificaciones</SheetTitle>
                  <SheetDescription>Tus notificaciones recientes</SheetDescription>
                </SheetHeader>
                <ScrollArea className="mt-4 h-[calc(100vh-200px)]">
                  <div className="space-y-4">
                    {[
                      { title: 'Nueva actividad', desc: 'El taller de Design Thinking está por comenzar', time: '5 min' },
                      { title: 'Voto registrado', desc: 'Tu voto para EcoTrack fue registrado', time: '15 min' },
                      { title: 'Logro desbloqueado', desc: '¡Has ganado la medalla "Participante Activo"!', time: '1 hora' },
                    ].map((n, i) => (
                      <div key={i} className="p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                        <p className="font-medium text-sm">{n.title}</p>
                        <p className="text-xs text-muted-foreground">{n.desc}</p>
                        <p className="text-xs text-muted-foreground mt-1">{n.time}</p>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </SheetContent>
            </Sheet>

            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="gap-2 pl-2 pr-3">
                  <Avatar className="w-8 h-8">
                    <AvatarImage src={user?.avatar} />
                    <AvatarFallback className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white text-sm">
                      {user?.name ? getInitials(user.name) : 'U'}
                    </AvatarFallback>
                  </Avatar>
                  <div className="hidden md:block text-left">
                    <p className="text-sm font-medium">{user?.name}</p>
                    <p className="text-xs text-muted-foreground">{user?.points} pts • Nivel {user?.level}</p>
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>Mi Cuenta</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <User className="w-4 h-4 mr-2" />
                  Perfil
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Trophy className="w-4 h-4 mr-2" />
                  Mis Logros
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <FileText className="w-4 h-4 mr-2" />
                  Certificados
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="w-4 h-4 mr-2" />
                  Cerrar Sesión
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex flex-1">
        {/* Sidebar */}
        <aside className={cn(
          "fixed lg:sticky top-16 left-0 z-40 h-[calc(100vh-4rem)] w-64 border-r bg-white dark:bg-gray-900 transition-transform duration-300 lg:translate-x-0",
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}>
          <ScrollArea className="h-full py-4">
            <nav className="px-3 space-y-1">
              {currentView === 'admin' ? (
                // Admin Navigation
                <>
                  <Button
                    variant={activeTab === 'dashboard' ? 'secondary' : 'ghost'}
                    className="w-full justify-start gap-3"
                    onClick={() => setActiveTab('dashboard')}
                  >
                    <LayoutDashboard className="w-5 h-5" />
                    Dashboard
                  </Button>
                  <Button
                    variant={activeTab === 'events' ? 'secondary' : 'ghost'}
                    className="w-full justify-start gap-3"
                    onClick={() => setActiveTab('events')}
                  >
                    <Calendar className="w-5 h-5" />
                    Eventos
                  </Button>
                  <Button
                    variant={activeTab === 'rooms' ? 'secondary' : 'ghost'}
                    className="w-full justify-start gap-3"
                    onClick={() => setActiveTab('rooms')}
                  >
                    <Building className="w-5 h-5" />
                    Salas
                  </Button>
                  <Button
                    variant={activeTab === 'activities' ? 'secondary' : 'ghost'}
                    className="w-full justify-start gap-3"
                    onClick={() => setActiveTab('activities')}
                  >
                    <Presentation className="w-5 h-5" />
                    Actividades
                  </Button>
                  <Button
                    variant={activeTab === 'projects' ? 'secondary' : 'ghost'}
                    className="w-full justify-start gap-3"
                    onClick={() => setActiveTab('projects')}
                  >
                    <Lightbulb className="w-5 h-5" />
                    Proyectos
                  </Button>
                  <Button
                    variant={activeTab === 'users' ? 'secondary' : 'ghost'}
                    className="w-full justify-start gap-3"
                    onClick={() => setActiveTab('users')}
                  >
                    <Users className="w-5 h-5" />
                    Usuarios
                  </Button>
                  <Button
                    variant={activeTab === 'qr' ? 'secondary' : 'ghost'}
                    className="w-full justify-start gap-3"
                    onClick={() => setActiveTab('qr')}
                  >
                    <QrCode className="w-5 h-5" />
                    Códigos QR
                  </Button>
                  <Button
                    variant={activeTab === 'voting' ? 'secondary' : 'ghost'}
                    className="w-full justify-start gap-3"
                    onClick={() => setActiveTab('voting')}
                  >
                    <Vote className="w-5 h-5" />
                    Votación
                  </Button>
                  <Separator className="my-3" />
                  <Button
                    variant={activeTab === 'settings' ? 'secondary' : 'ghost'}
                    className="w-full justify-start gap-3"
                    onClick={() => setActiveTab('settings')}
                  >
                    <Settings className="w-5 h-5" />
                    Configuración
                  </Button>
                </>
              ) : (
                // User Navigation
                <>
                  <Button
                    variant={activeTab === 'agenda' ? 'secondary' : 'ghost'}
                    className="w-full justify-start gap-3"
                    onClick={() => setActiveTab('agenda')}
                  >
                    <Calendar className="w-5 h-5" />
                    Agenda
                  </Button>
                  <Button
                    variant={activeTab === 'map' ? 'secondary' : 'ghost'}
                    className="w-full justify-start gap-3"
                    onClick={() => setActiveTab('map')}
                  >
                    <MapPin className="w-5 h-5" />
                    Mapa
                  </Button>
                  <Button
                    variant={activeTab === 'projects-view' ? 'secondary' : 'ghost'}
                    className="w-full justify-start gap-3"
                    onClick={() => setActiveTab('projects-view')}
                  >
                    <Lightbulb className="w-5 h-5" />
                    Proyectos
                  </Button>
                  <Button
                    variant={activeTab === 'scanner' ? 'secondary' : 'ghost'}
                    className="w-full justify-start gap-3"
                    onClick={() => setActiveTab('scanner')}
                  >
                    <QrCode className="w-5 h-5" />
                    Escanear QR
                  </Button>
                  <Button
                    variant={activeTab === 'ranking' ? 'secondary' : 'ghost'}
                    className="w-full justify-start gap-3"
                    onClick={() => setActiveTab('ranking')}
                  >
                    <Trophy className="w-5 h-5" />
                    Ranking
                  </Button>
                  <Button
                    variant={activeTab === 'achievements' ? 'secondary' : 'ghost'}
                    className="w-full justify-start gap-3"
                    onClick={() => setActiveTab('achievements')}
                  >
                    <Award className="w-5 h-5" />
                    Logros
                  </Button>
                </>
              )}
            </nav>
          </ScrollArea>
        </aside>

        {/* Overlay for mobile */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 z-30 bg-black/50 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Main Content Area */}
        <main className="flex-1 p-4 lg:p-6 overflow-auto">
          <AnimatePresence mode="wait">
            {currentView === 'admin' ? (
              // ADMIN VIEWS
              <motion.div
                key="admin"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                {/* Dashboard */}
                {activeTab === 'dashboard' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h1 className="text-3xl font-bold">Dashboard</h1>
                        <p className="text-muted-foreground">Resumen general del evento</p>
                      </div>
                      <div className="flex gap-2">
                        <Select defaultValue={selectedEvent?.id} onValueChange={(v) => setSelectedEvent(events.find(e => e.id === v) || null)}>
                          <SelectTrigger className="w-[200px]">
                            <SelectValue placeholder="Seleccionar evento" />
                          </SelectTrigger>
                          <SelectContent>
                            {events.map((e) => (
                              <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Stats Grid */}
                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                      {[
                        { label: 'Total Usuarios', value: dashboardStats.totalUsers, icon: Users, color: 'text-blue-500', bg: 'bg-blue-500/10' },
                        { label: 'Actividades', value: dashboardStats.totalActivities, icon: Calendar, color: 'text-green-500', bg: 'bg-green-500/10' },
                        { label: 'Proyectos', value: dashboardStats.totalProjects, icon: Lightbulb, color: 'text-yellow-500', bg: 'bg-yellow-500/10' },
                        { label: 'Total Votos', value: dashboardStats.totalVotes, icon: Vote, color: 'text-purple-500', bg: 'bg-purple-500/10' },
                      ].map((stat, i) => (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: i * 0.1 }}
                        >
                          <Card>
                            <CardContent className="pt-6">
                              <div className="flex items-center justify-between">
                                <div>
                                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                                  <p className="text-3xl font-bold">{stat.value.toLocaleString()}</p>
                                </div>
                                <div className={cn("p-3 rounded-xl", stat.bg)}>
                                  <stat.icon className={cn("w-6 h-6", stat.color)} />
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                    </div>

                    {/* Charts Row */}
                    <div className="grid gap-6 lg:grid-cols-2">
                      <Card>
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2">
                            <BarChart3 className="w-5 h-5" />
                            Actividades por Asistencia
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            {activities.slice(0, 5).map((a, i) => (
                              <div key={a.id} className="flex items-center gap-3">
                                <div className={cn("w-3 h-3 rounded-full", getActivityTypeColor(a.type))} />
                                <div className="flex-1 min-w-0">
                                  <p className="text-sm font-medium truncate">{a.title}</p>
                                </div>
                                <div className="w-24">
                                  <Progress value={(a.currentAttendance / 500) * 100} className="h-2" />
                                </div>
                                <span className="text-sm text-muted-foreground w-12 text-right">{a.currentAttendance}</span>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle className="flex items-center gap-2">
                            <Trophy className="w-5 h-5" />
                            Ranking de Proyectos
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            {projects.slice(0, 5).map((p, i) => (
                              <div key={p.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800">
                                <div className={cn(
                                  "w-8 h-8 rounded-full flex items-center justify-center font-bold text-white",
                                  i === 0 ? "bg-amber-500" : i === 1 ? "bg-gray-400" : i === 2 ? "bg-amber-700" : "bg-gray-300 dark:bg-gray-600"
                                )}>
                                  {p.rank}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className="font-medium truncate">{p.name}</p>
                                  <p className="text-xs text-muted-foreground">{p.team}</p>
                                </div>
                                <div className="text-right">
                                  <div className="flex items-center gap-1 text-sm font-medium">
                                    <Star className="w-4 h-4 text-yellow-500" />
                                    {p.averageScore?.toFixed(1)}
                                  </div>
                                  <p className="text-xs text-muted-foreground">{p.totalVotes} votos</p>
                                </div>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    {/* Leaderboard */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <Medal className="w-5 h-5" />
                          Tabla de Líderes
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid gap-2">
                          {leaderboard.map((entry, i) => (
                            <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-gray-50 dark:bg-gray-800">
                              <div className={cn(
                                "w-10 h-10 rounded-full flex items-center justify-center font-bold text-white",
                                i === 0 ? "bg-amber-500" : i === 1 ? "bg-gray-400" : i === 2 ? "bg-amber-700" : "bg-gray-300 dark:bg-gray-600"
                              )}>
                                {entry.rank}
                              </div>
                              <Avatar className="w-10 h-10">
                                <AvatarImage src={entry.avatar} />
                                <AvatarFallback>{getInitials(entry.name)}</AvatarFallback>
                              </Avatar>
                              <div className="flex-1">
                                <p className="font-medium">{entry.name}</p>
                                <p className="text-xs text-muted-foreground">Nivel {entry.level}</p>
                              </div>
                              <div className="text-right">
                                <p className="font-bold text-emerald-500">{entry.points.toLocaleString()}</p>
                                <p className="text-xs text-muted-foreground">puntos</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}

                {/* Events Management */}
                {activeTab === 'events' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h1 className="text-3xl font-bold">Gestión de Eventos</h1>
                        <p className="text-muted-foreground">Administra todos los eventos</p>
                      </div>
                      <Button 
                        className="gap-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700"
                        onClick={openNewEventDialog}
                      >
                        <Plus className="w-4 h-4" />
                        Nuevo Evento
                      </Button>
                    </div>

                    <div className="grid gap-4">
                      {events.length === 0 ? (
                        <Card>
                          <CardContent className="pt-6 text-center text-muted-foreground">
                            <Calendar className="w-12 h-12 mx-auto mb-4 opacity-50" />
                            <p>No hay eventos creados</p>
                            <p className="text-sm">Haz clic en "Nuevo Evento" para crear uno</p>
                          </CardContent>
                        </Card>
                      ) : (
                        events.map((event) => (
                          <Card key={event.id} className="hover:shadow-lg transition-shadow">
                            <CardContent className="pt-6">
                              <div className="flex items-start justify-between">
                                <div className="space-y-2 flex-1">
                                  <div className="flex items-center gap-2">
                                    <h3 className="text-xl font-bold">{event.name}</h3>
                                    <Badge variant={event.isActive ? 'default' : 'secondary'} className={event.isActive ? 'bg-emerald-500' : ''}>
                                      {event.isActive ? 'Activo' : 'Inactivo'}
                                    </Badge>
                                  </div>
                                  <p className="text-muted-foreground">{event.description}</p>
                                  <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                                    <span className="flex items-center gap-1">
                                      <Calendar className="w-4 h-4" />
                                      {formatDate(event.startDate)} - {formatDate(event.endDate)}
                                    </span>
                                    {event.location && (
                                      <span className="flex items-center gap-1">
                                        <MapPin className="w-4 h-4" />
                                        {event.location}
                                      </span>
                                    )}
                                  </div>
                                  <div className="flex items-center gap-4 text-sm">
                                    <Badge variant="outline">{event._count?.rooms || 0} salas</Badge>
                                    <Badge variant="outline">{event._count?.activities || 0} actividades</Badge>
                                    <Badge variant="outline">{event._count?.projects || 0} proyectos</Badge>
                                  </div>
                                </div>
                                <div className="flex gap-2 ml-4">
                                  <Button 
                                    variant="outline" 
                                    size="icon"
                                    onClick={() => openEditEventDialog(event)}
                                  >
                                    <Edit className="w-4 h-4" />
                                  </Button>
                                  <Button 
                                    variant="outline" 
                                    size="icon"
                                    className="text-red-500 hover:text-red-600"
                                    onClick={() => {
                                      setEditingEvent(event);
                                      setDeleteEventDialogOpen(true);
                                    }}
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        ))
                      )}
                    </div>
                  </div>
                )}

                {/* Event Form Dialog */}
                <Dialog open={eventDialogOpen} onOpenChange={setEventDialogOpen}>
                  <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>{editingEvent ? 'Editar Evento' : 'Crear Nuevo Evento'}</DialogTitle>
                      <DialogDescription>
                        {editingEvent ? 'Modifica la información del evento' : 'Completa la información para crear un nuevo evento'}
                      </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="event-name">Nombre del evento *</Label>
                        <Input 
                          id="event-name"
                          placeholder="Ej: Fábrica de Ideas 2025" 
                          value={eventForm.name}
                          onChange={(e) => setEventForm(prev => ({ ...prev, name: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="event-slug">Slug (opcional, se genera automáticamente)</Label>
                        <Input 
                          id="event-slug"
                          placeholder="fabrica-de-ideas-2025" 
                          value={eventForm.slug}
                          onChange={(e) => setEventForm(prev => ({ ...prev, slug: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="event-description">Descripción</Label>
                        <Textarea 
                          id="event-description"
                          placeholder="Describe el evento..." 
                          value={eventForm.description}
                          onChange={(e) => setEventForm(prev => ({ ...prev, description: e.target.value }))}
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="event-start-date">Fecha inicio *</Label>
                          <Input 
                            id="event-start-date"
                            type="date" 
                            value={eventForm.startDate}
                            onChange={(e) => setEventForm(prev => ({ ...prev, startDate: e.target.value }))}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="event-start-time">Hora inicio</Label>
                          <Input 
                            id="event-start-time"
                            type="time" 
                            value={eventForm.startTime}
                            onChange={(e) => setEventForm(prev => ({ ...prev, startTime: e.target.value }))}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="event-end-date">Fecha fin *</Label>
                          <Input 
                            id="event-end-date"
                            type="date" 
                            value={eventForm.endDate}
                            onChange={(e) => setEventForm(prev => ({ ...prev, endDate: e.target.value }))}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="event-end-time">Hora fin</Label>
                          <Input 
                            id="event-end-time"
                            type="time" 
                            value={eventForm.endTime}
                            onChange={(e) => setEventForm(prev => ({ ...prev, endTime: e.target.value }))}
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="event-location">Ubicación</Label>
                        <Input 
                          id="event-location"
                          placeholder="Centro de Convenciones" 
                          value={eventForm.location}
                          onChange={(e) => setEventForm(prev => ({ ...prev, location: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="event-address">Dirección</Label>
                        <Input 
                          id="event-address"
                          placeholder="Av. Principal 123" 
                          value={eventForm.address}
                          onChange={(e) => setEventForm(prev => ({ ...prev, address: e.target.value }))}
                        />
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch 
                          id="event-active"
                          checked={eventForm.isActive}
                          onCheckedChange={(checked) => setEventForm(prev => ({ ...prev, isActive: checked }))}
                        />
                        <Label htmlFor="event-active">Evento activo</Label>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setEventDialogOpen(false)}>
                        Cancelar
                      </Button>
                      <Button 
                        className="bg-gradient-to-r from-emerald-500 to-teal-600"
                        onClick={editingEvent ? handleUpdateEvent : handleCreateEvent}
                        disabled={savingEvent}
                      >
                        {savingEvent ? 'Guardando...' : editingEvent ? 'Actualizar' : 'Crear Evento'}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Delete Event Confirmation Dialog */}
                <Dialog open={deleteEventDialogOpen} onOpenChange={setDeleteEventDialogOpen}>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Eliminar Evento</DialogTitle>
                      <DialogDescription>
                        ¿Estás seguro de que deseas eliminar el evento "{editingEvent?.name}"? Esta acción no se puede deshacer y eliminará todas las salas, actividades y proyectos asociados.
                      </DialogDescription>
                    </DialogHeader>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setDeleteEventDialogOpen(false)}>
                        Cancelar
                      </Button>
                      <Button 
                        variant="destructive"
                        onClick={handleDeleteEvent}
                        disabled={deletingEvent}
                      >
                        {deletingEvent ? 'Eliminando...' : 'Eliminar Evento'}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>

                {/* Rooms Management */}
                {activeTab === 'rooms' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h1 className="text-3xl font-bold">Gestión de Salas</h1>
                        <p className="text-muted-foreground">Administra las salas del evento</p>
                      </div>
                      <Button 
                        className="gap-2 bg-gradient-to-r from-emerald-500 to-teal-600"
                        onClick={handleNewRoom}
                      >
                        <Plus className="w-4 h-4" />
                        Nueva Sala
                      </Button>
                    </div>

                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                      {roomsList.map((room) => (
                        <Card key={room.id} className="hover:shadow-lg transition-shadow">
                          <CardHeader className="pb-3">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: room.color || '#3B82F6' }}>
                                  <Building className="w-5 h-5 text-white" />
                                </div>
                                <CardTitle className="text-lg">{room.name}</CardTitle>
                              </div>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon">
                                    <MoreVertical className="w-4 h-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent>
                                  <DropdownMenuItem onClick={() => handleEditRoom(room)}>
                                    <Edit className="w-4 h-4 mr-2" /> Editar
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleGenerateRoomQR(room)}>
                                    <QrCode className="w-4 h-4 mr-2" /> Generar QR
                                  </DropdownMenuItem>
                                  <DropdownMenuItem 
                                    className="text-red-600"
                                    onClick={() => {
                                      setSelectedRoomForEdit(room);
                                      setDeleteRoomDialogOpen(true);
                                    }}
                                  >
                                    <Trash2 className="w-4 h-4 mr-2" /> Eliminar
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-2 text-sm">
                              <div className="flex items-center gap-2 text-muted-foreground">
                                <Users className="w-4 h-4" />
                                <span>Capacidad: {room.capacity} personas</span>
                              </div>
                              {room.building && (
                                <div className="flex items-center gap-2 text-muted-foreground">
                                  <Building className="w-4 h-4" />
                                  <span>{room.building} - {room.floor}</span>
                                </div>
                              )}
                            </div>
                            <div className="mt-4 flex gap-2">
                              <Button 
                                variant="outline" 
                                size="sm" 
                                className="flex-1"
                                onClick={() => handleGenerateRoomQR(room)}
                              >
                                <QrCode className="w-4 h-4 mr-1" />
                                QR
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm" 
                                className="flex-1"
                                onClick={() => handleShowRoomMap(room)}
                              >
                                <MapPin className="w-4 h-4 mr-1" />
                                Mapa
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>

                    {/* Edit Room Dialog */}
                    <Dialog open={editRoomDialogOpen} onOpenChange={setEditRoomDialogOpen}>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle className="flex items-center gap-2">
                            <Building className="w-5 h-5" />
                            {selectedRoomForEdit ? 'Editar Sala' : 'Nueva Sala'}
                          </DialogTitle>
                          <DialogDescription>
                            {selectedRoomForEdit 
                              ? 'Modifica la información de la sala' 
                              : 'Completa la información para crear una nueva sala'}
                          </DialogDescription>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                          <div className="grid gap-2">
                            <Label htmlFor="room-name">Nombre de la sala *</Label>
                            <Input
                              id="room-name"
                              placeholder="Ej: Auditorio Principal"
                              value={roomForm.name}
                              onChange={(e) => setRoomForm(prev => ({ ...prev, name: e.target.value }))}
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div className="grid gap-2">
                              <Label htmlFor="room-capacity">Capacidad</Label>
                              <Input
                                id="room-capacity"
                                type="number"
                                placeholder="50"
                                value={roomForm.capacity}
                                onChange={(e) => setRoomForm(prev => ({ ...prev, capacity: e.target.value }))}
                              />
                            </div>
                            <div className="grid gap-2">
                              <Label htmlFor="room-color">Color</Label>
                              <div className="flex gap-2">
                                <Input
                                  id="room-color"
                                  type="color"
                                  value={roomForm.color}
                                  onChange={(e) => setRoomForm(prev => ({ ...prev, color: e.target.value }))}
                                  className="w-12 h-10 p-1 cursor-pointer"
                                />
                                <Input
                                  value={roomForm.color}
                                  onChange={(e) => setRoomForm(prev => ({ ...prev, color: e.target.value }))}
                                  placeholder="#3B82F6"
                                  className="flex-1"
                                />
                              </div>
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div className="grid gap-2">
                              <Label htmlFor="room-building">Edificio</Label>
                              <Input
                                id="room-building"
                                placeholder="Ej: Edificio A"
                                value={roomForm.building}
                                onChange={(e) => setRoomForm(prev => ({ ...prev, building: e.target.value }))}
                              />
                            </div>
                            <div className="grid gap-2">
                              <Label htmlFor="room-floor">Piso</Label>
                              <Input
                                id="room-floor"
                                placeholder="Ej: Planta Baja"
                                value={roomForm.floor}
                                onChange={(e) => setRoomForm(prev => ({ ...prev, floor: e.target.value }))}
                              />
                            </div>
                          </div>
                        </div>
                        <DialogFooter>
                          <Button variant="outline" onClick={() => setEditRoomDialogOpen(false)}>
                            Cancelar
                          </Button>
                          <Button 
                            className="bg-gradient-to-r from-emerald-500 to-teal-600"
                            onClick={handleSaveRoom}
                            disabled={savingRoom}
                          >
                            {savingRoom ? (
                              <>
                                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                                Guardando...
                              </>
                            ) : (
                              selectedRoomForEdit ? 'Guardar Cambios' : 'Crear Sala'
                            )}
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>

                    {/* QR Code Dialog */}
                    <Dialog open={qrRoomDialogOpen} onOpenChange={setQrRoomDialogOpen}>
                      <DialogContent className="sm:max-w-md">
                        <DialogHeader>
                          <DialogTitle className="flex items-center gap-2">
                            <QrCode className="w-5 h-5" />
                            Código QR - {selectedRoomForEdit?.name}
                          </DialogTitle>
                          <DialogDescription>
                            Escanea este código para acceder a la información de la sala
                          </DialogDescription>
                        </DialogHeader>
                        <div className="flex flex-col items-center py-4">
                          {roomQrCode && (
                            <div className="bg-white p-4 rounded-lg shadow-inner">
                              <img 
                                src={roomQrCode} 
                                alt="QR Code" 
                                className="w-48 h-48 object-contain"
                              />
                            </div>
                          )}
                          <div className="mt-4 text-center space-y-2">
                            <p className="text-sm text-muted-foreground">
                              <strong>Sala:</strong> {selectedRoomForEdit?.name}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              <strong>Ubicación:</strong> {selectedRoomForEdit?.building} - {selectedRoomForEdit?.floor}
                            </p>
                          </div>
                        </div>
                        <DialogFooter className="flex-col sm:flex-row gap-2">
                          <Button 
                            variant="outline" 
                            className="w-full"
                            onClick={() => {
                              if (roomQrCode) {
                                const link = document.createElement('a');
                                link.href = roomQrCode;
                                link.download = `qr-${selectedRoomForEdit?.name?.replace(/\s+/g, '-')}.png`;
                                link.target = '_blank';
                                window.open(roomQrCode, '_blank');
                                toast.success('Abriendo imagen del QR...');
                              }
                            }}
                          >
                            <Download className="w-4 h-4 mr-2" />
                            Descargar QR
                          </Button>
                          <Button 
                            className="w-full bg-gradient-to-r from-emerald-500 to-teal-600"
                            onClick={() => {
                              navigator.clipboard.writeText(`Sala: ${selectedRoomForEdit?.name}, ${selectedRoomForEdit?.building} - ${selectedRoomForEdit?.floor}`);
                              toast.success('Información copiada al portapapeles');
                            }}
                          >
                            <Copy className="w-4 h-4 mr-2" />
                            Copiar Info
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>

                    {/* Map Room Dialog */}
                    <Dialog open={mapRoomDialogOpen} onOpenChange={setMapRoomDialogOpen}>
                      <DialogContent className="sm:max-w-lg">
                        <DialogHeader>
                          <DialogTitle className="flex items-center gap-2">
                            <MapPin className="w-5 h-5 text-emerald-500" />
                            Ubicación de {selectedRoomForEdit?.name}
                          </DialogTitle>
                          <DialogDescription>
                            Ver ubicación y obtener direcciones
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          {/* Map placeholder */}
                          <div className="relative h-48 bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-700 rounded-lg overflow-hidden">
                            <div className="absolute inset-0 flex items-center justify-center">
                              <div className="text-center">
                                <Building 
                                  className="w-12 h-12 mx-auto mb-2" 
                                  style={{ color: selectedRoomForEdit?.color || '#3B82F6' }}
                                />
                                <p className="text-sm font-medium">{selectedRoomForEdit?.name}</p>
                              </div>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4">
                            <Card>
                              <CardContent className="pt-4">
                                <div className="flex items-center gap-2">
                                  <Building className="w-4 h-4 text-muted-foreground" />
                                  <span className="text-sm text-muted-foreground">Edificio</span>
                                </div>
                                <p className="font-semibold mt-1">{selectedRoomForEdit?.building || 'No especificado'}</p>
                              </CardContent>
                            </Card>
                            <Card>
                              <CardContent className="pt-4">
                                <div className="flex items-center gap-2">
                                  <MapPin className="w-4 h-4 text-muted-foreground" />
                                  <span className="text-sm text-muted-foreground">Piso</span>
                                </div>
                                <p className="font-semibold mt-1">{selectedRoomForEdit?.floor || 'No especificado'}</p>
                              </CardContent>
                            </Card>
                          </div>
                        </div>
                        <DialogFooter className="flex-col sm:flex-row gap-2">
                          <Button 
                            variant="outline" 
                            className="w-full"
                            onClick={() => setMapRoomDialogOpen(false)}
                          >
                            Cerrar
                          </Button>
                          <Button 
                            className="w-full bg-gradient-to-r from-emerald-500 to-teal-600"
                            onClick={() => {
                              if (selectedRoomForEdit) {
                                openExternalMap(selectedRoomForEdit);
                                setMapRoomDialogOpen(false);
                              }
                            }}
                          >
                            <MapPin className="w-4 h-4 mr-2" />
                            Abrir en Google Maps
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>

                    {/* Delete Confirmation Dialog */}
                    <Dialog open={deleteRoomDialogOpen} onOpenChange={setDeleteRoomDialogOpen}>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle className="flex items-center gap-2 text-red-600">
                            <Trash2 className="w-5 h-5" />
                            Eliminar Sala
                          </DialogTitle>
                          <DialogDescription>
                            ¿Estás seguro de que deseas eliminar la sala <strong>{selectedRoomForEdit?.name}</strong>?
                          </DialogDescription>
                        </DialogHeader>
                        <div className="py-4">
                          <Alert className="bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800">
                            <Trash2 className="h-4 w-4 text-red-600" />
                            <AlertTitle>¡Atención!</AlertTitle>
                            <AlertDescription>
                              Esta acción no se puede deshacer. Se eliminará toda la información asociada a esta sala.
                            </AlertDescription>
                          </Alert>
                        </div>
                        <DialogFooter>
                          <Button 
                            variant="outline" 
                            onClick={() => setDeleteRoomDialogOpen(false)}
                          >
                            Cancelar
                          </Button>
                          <Button 
                            variant="destructive"
                            onClick={handleDeleteRoom}
                            disabled={deletingRoom}
                          >
                            {deletingRoom ? (
                              <>
                                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                                Eliminando...
                              </>
                            ) : (
                              <>
                                <Trash2 className="w-4 h-4 mr-2" />
                                Eliminar Sala
                              </>
                            )}
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                )}

                {/* Activities Management */}
                {activeTab === 'activities' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h1 className="text-3xl font-bold">Gestión de Actividades</h1>
                        <p className="text-muted-foreground">Administra conferencias, talleres y paneles</p>
                      </div>
                      <div className="flex gap-2">
                        <Select defaultValue="all">
                          <SelectTrigger className="w-[150px]">
                            <SelectValue placeholder="Estado" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">Todos</SelectItem>
                            <SelectItem value="SCHEDULED">Programados</SelectItem>
                            <SelectItem value="IN_PROGRESS">En curso</SelectItem>
                            <SelectItem value="COMPLETED">Finalizados</SelectItem>
                          </SelectContent>
                        </Select>
                        <Dialog open={activityDialogOpen} onOpenChange={(open) => {
                          setActivityDialogOpen(open);
                          if (!open) resetActivityForm();
                        }}>
                          <DialogTrigger asChild>
                            <Button className="gap-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700">
                              <Plus className="w-4 h-4" />
                              Nueva Actividad
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                            <DialogHeader>
                              <DialogTitle>Crear Nueva Actividad</DialogTitle>
                              <DialogDescription>Completa la información de la actividad</DialogDescription>
                            </DialogHeader>
                            <div className="grid gap-4 py-4">
                              <div className="grid gap-2">
                                <Label htmlFor="activity-title">Título *</Label>
                                <Input 
                                  id="activity-title" 
                                  placeholder="Ej: Taller de Design Thinking"
                                  value={activityForm.title}
                                  onChange={(e) => setActivityForm(prev => ({ ...prev, title: e.target.value }))}
                                />
                              </div>
                              <div className="grid gap-2">
                                <Label htmlFor="activity-description">Descripción</Label>
                                <Textarea 
                                  id="activity-description" 
                                  placeholder="Describe la actividad..." 
                                  rows={3}
                                  value={activityForm.description}
                                  onChange={(e) => setActivityForm(prev => ({ ...prev, description: e.target.value }))}
                                />
                              </div>
                              <div className="grid grid-cols-2 gap-4">
                                <div className="grid gap-2">
                                  <Label>Tipo de actividad</Label>
                                  <Select 
                                    value={activityForm.type}
                                    onValueChange={(value) => setActivityForm(prev => ({ ...prev, type: value }))}
                                  >
                                    <SelectTrigger>
                                      <SelectValue placeholder="Seleccionar tipo" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="KEYNOTE">Conferencia</SelectItem>
                                      <SelectItem value="WORKSHOP">Taller</SelectItem>
                                      <SelectItem value="PANEL">Panel</SelectItem>
                                      <SelectItem value="PRESENTATION">Presentación</SelectItem>
                                      <SelectItem value="NETWORKING">Networking</SelectItem>
                                      <SelectItem value="BREAK">Descanso</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </div>
                                <div className="grid gap-2">
                                  <Label>Sala</Label>
                                  <Select
                                    value={activityForm.roomId}
                                    onValueChange={(value) => setActivityForm(prev => ({ ...prev, roomId: value }))}
                                  >
                                    <SelectTrigger>
                                      <SelectValue placeholder="Seleccionar sala" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {rooms.map((room) => (
                                        <SelectItem key={room.id} value={room.id}>{room.name}</SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                </div>
                              </div>
                              <div className="grid grid-cols-2 gap-4">
                                <div className="grid gap-2">
                                  <Label>Hora inicio *</Label>
                                  <Input 
                                    type="time"
                                    value={activityForm.startTime}
                                    onChange={(e) => setActivityForm(prev => ({ ...prev, startTime: e.target.value }))}
                                  />
                                </div>
                                <div className="grid gap-2">
                                  <Label>Hora fin *</Label>
                                  <Input 
                                    type="time"
                                    value={activityForm.endTime}
                                    onChange={(e) => setActivityForm(prev => ({ ...prev, endTime: e.target.value }))}
                                  />
                                </div>
                              </div>
                              <div className="grid grid-cols-2 gap-4">
                                <div className="grid gap-2">
                                  <Label>Fecha *</Label>
                                  <Input 
                                    type="date"
                                    value={activityForm.date}
                                    onChange={(e) => setActivityForm(prev => ({ ...prev, date: e.target.value }))}
                                  />
                                </div>
                                <div className="grid gap-2">
                                  <Label>Capacidad máxima</Label>
                                  <Input 
                                    type="number" 
                                    placeholder="Ej: 100"
                                    value={activityForm.maxCapacity}
                                    onChange={(e) => setActivityForm(prev => ({ ...prev, maxCapacity: e.target.value }))}
                                  />
                                </div>
                              </div>
                              <div className="grid gap-2">
                                <Label>Temática</Label>
                                <Input 
                                  placeholder="Ej: Innovación, Tecnología, Diseño"
                                  value={activityForm.theme}
                                  onChange={(e) => setActivityForm(prev => ({ ...prev, theme: e.target.value }))}
                                />
                              </div>
                              <div className="flex items-center gap-2">
                                <Switch 
                                  id="activity-generate-qr"
                                  checked={activityForm.generateQr}
                                  onCheckedChange={(checked) => setActivityForm(prev => ({ ...prev, generateQr: checked }))}
                                />
                                <Label htmlFor="activity-generate-qr">Generar código QR automáticamente</Label>
                              </div>
                            </div>
                            <DialogFooter>
                              <Button variant="outline" onClick={() => {
                                setActivityDialogOpen(false);
                                resetActivityForm();
                              }}>
                                Cancelar
                              </Button>
                              <Button 
                                className="bg-gradient-to-r from-emerald-500 to-teal-600"
                                onClick={handleCreateActivity}
                                disabled={savingActivity}
                              >
                                {savingActivity ? (
                                  <>
                                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                                    Guardando...
                                  </>
                                ) : (
                                  'Crear Actividad'
                                )}
                              </Button>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>
                      </div>
                    </div>

                    <div className="grid gap-4">
                      {activities.map((activity) => (
                        <Card key={activity.id} className="hover:shadow-lg transition-shadow">
                          <CardContent className="pt-6">
                            <div className="flex items-start gap-4">
                              <div className={cn("w-2 h-full min-h-[80px] rounded-full", getActivityTypeColor(activity.type))} />
                              <div className="flex-1">
                                <div className="flex items-start justify-between">
                                  <div>
                                    <div className="flex items-center gap-2 mb-1">
                                      <Badge className={getStatusColor(activity.status)}>
                                        {activity.status === 'SCHEDULED' ? 'Programado' : activity.status === 'IN_PROGRESS' ? 'En curso' : 'Finalizado'}
                                      </Badge>
                                      <Badge variant="outline">{getTypeLabel(activity.type)}</Badge>
                                    </div>
                                    <h3 className="text-lg font-bold">{activity.title}</h3>
                                    <p className="text-sm text-muted-foreground line-clamp-2">{activity.description}</p>
                                  </div>
                                  <DropdownMenu>
                                    <DropdownMenuTrigger asChild>
                                      <Button variant="ghost" size="icon">
                                        <MoreVertical className="w-4 h-4" />
                                      </Button>
                                    </DropdownMenuTrigger>
                                    <DropdownMenuContent>
                                      <DropdownMenuItem><Edit className="w-4 h-4 mr-2" /> Editar</DropdownMenuItem>
                                      <DropdownMenuItem><Eye className="w-4 h-4 mr-2" /> Ver detalles</DropdownMenuItem>
                                      <DropdownMenuItem><QrCode className="w-4 h-4 mr-2" /> Generar QR</DropdownMenuItem>
                                      <DropdownMenuItem className="text-red-600"><Trash2 className="w-4 h-4 mr-2" /> Eliminar</DropdownMenuItem>
                                    </DropdownMenuContent>
                                  </DropdownMenu>
                                </div>
                                <div className="flex items-center gap-4 mt-3 text-sm">
                                  <span className="flex items-center gap-1 text-muted-foreground">
                                    <Clock className="w-4 h-4" />
                                    {formatTime(activity.startTime)} - {formatTime(activity.endTime)}
                                  </span>
                                  <span className="flex items-center gap-1 text-muted-foreground">
                                    <MapPin className="w-4 h-4" />
                                    {activity.room?.name}
                                  </span>
                                  {activity.speaker && (
                                    <span className="flex items-center gap-1 text-muted-foreground">
                                      <User className="w-4 h-4" />
                                      {activity.speaker.name}
                                    </span>
                                  )}
                                  <span className="flex items-center gap-1 text-muted-foreground">
                                    <Users className="w-4 h-4" />
                                    {activity.currentAttendance} asistentes
                                  </span>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}

                {/* Projects Management */}
                {activeTab === 'projects' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h1 className="text-3xl font-bold">Gestión de Proyectos</h1>
                        <p className="text-muted-foreground">Administra los proyectos participantes</p>
                      </div>
                      <div className="flex gap-2">
                        <Select defaultValue="all">
                          <SelectTrigger className="w-[150px]">
                            <SelectValue placeholder="Estado" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">Todos</SelectItem>
                            <SelectItem value="APPROVED">Aprobados</SelectItem>
                            <SelectItem value="FINALIST">Finalistas</SelectItem>
                            <SelectItem value="WINNER">Ganadores</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button className="gap-2 bg-gradient-to-r from-emerald-500 to-teal-600">
                          <Plus className="w-4 h-4" />
                          Nuevo Proyecto
                        </Button>
                      </div>
                    </div>

                    <div className="grid gap-4 md:grid-cols-2">
                      {projects.map((project) => (
                        <Card key={project.id} className="hover:shadow-lg transition-shadow">
                          <CardHeader className="pb-3">
                            <div className="flex items-start justify-between">
                              <div>
                                <div className="flex items-center gap-2 mb-1">
                                  {project.rank && project.rank <= 3 && (
                                    <div className={cn(
                                      "w-6 h-6 rounded-full flex items-center justify-center text-white font-bold text-sm",
                                      project.rank === 1 ? "bg-amber-500" : project.rank === 2 ? "bg-gray-400" : "bg-amber-700"
                                    )}>
                                      {project.rank}
                                    </div>
                                  )}
                                  <CardTitle className="text-lg">{project.name}</CardTitle>
                                </div>
                                <CardDescription>{project.team}</CardDescription>
                              </div>
                              <Badge className={getStatusColor(project.status)}>
                                {project.status === 'APPROVED' ? 'Aprobado' : project.status === 'FINALIST' ? 'Finalista' : 'Ganador'}
                              </Badge>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <p className="text-sm text-muted-foreground line-clamp-2 mb-4">{project.description}</p>
                            <div className="flex items-center justify-between text-sm">
                              <div className="flex items-center gap-3">
                                <Badge variant="outline">{project.category}</Badge>
                                <div className="flex items-center gap-1">
                                  <Star className="w-4 h-4 text-yellow-500" />
                                  {project.averageScore?.toFixed(1)}
                                </div>
                                <span className="text-muted-foreground">{project.totalVotes} votos</span>
                              </div>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon">
                                    <MoreVertical className="w-4 h-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent>
                                  <DropdownMenuItem><Edit className="w-4 h-4 mr-2" /> Editar</DropdownMenuItem>
                                  <DropdownMenuItem><Eye className="w-4 h-4 mr-2" /> Ver detalles</DropdownMenuItem>
                                  <DropdownMenuItem><QrCode className="w-4 h-4 mr-2" /> Generar QR</DropdownMenuItem>
                                  <DropdownMenuItem className="text-red-600"><Trash2 className="w-4 h-4 mr-2" /> Eliminar</DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}

                {/* Users Management */}
                {activeTab === 'users' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h1 className="text-3xl font-bold">Gestión de Usuarios</h1>
                        <p className="text-muted-foreground">Administra los participantes del evento</p>
                      </div>
                      <div className="flex gap-2">
                        <div className="relative">
                          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                          <Input placeholder="Buscar usuarios..." className="pl-10 w-[250px]" />
                        </div>
                        <Button className="gap-2 bg-gradient-to-r from-emerald-500 to-teal-600">
                          <Download className="w-4 h-4" />
                          Exportar
                        </Button>
                      </div>
                    </div>

                    <Card>
                      <CardContent className="pt-6">
                        <div className="rounded-lg border">
                          <div className="grid grid-cols-6 gap-4 p-4 bg-gray-50 dark:bg-gray-800 text-sm font-medium">
                            <div>Usuario</div>
                            <div>Email</div>
                            <div>Rol</div>
                            <div>Puntos</div>
                            <div>Estado</div>
                            <div>Acciones</div>
                          </div>
                          {leaderboard.map((entry, i) => (
                            <div key={i} className="grid grid-cols-6 gap-4 p-4 border-t items-center">
                              <div className="flex items-center gap-2">
                                <Avatar className="w-8 h-8">
                                  <AvatarFallback>{getInitials(entry.name)}</AvatarFallback>
                                </Avatar>
                                <span className="font-medium">{entry.name}</span>
                              </div>
                              <div className="text-muted-foreground">{entry.name.toLowerCase().replace(' ', '.')}@email.com</div>
                              <div><Badge variant="outline">Participante</Badge></div>
                              <div className="font-medium text-emerald-500">{entry.points}</div>
                              <div><Badge className="bg-green-500">Activo</Badge></div>
                              <div className="flex gap-1">
                                <Button 
                                  variant="ghost" 
                                  size="icon"
                                  onClick={() => handleEditUser(entry, i)}
                                  title="Editar usuario"
                                >
                                  <Edit className="w-4 h-4" />
                                </Button>
                                <Button 
                                  variant="ghost" 
                                  size="icon"
                                  onClick={() => handleViewUser(entry, i)}
                                  title="Ver detalles"
                                >
                                  <Eye className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>

                    {/* Edit User Dialog */}
                    <Dialog open={editUserDialogOpen} onOpenChange={setEditUserDialogOpen}>
                      <DialogContent className="max-w-md">
                        <DialogHeader>
                          <DialogTitle className="flex items-center gap-2">
                            <Edit className="w-5 h-5" />
                            Editar Usuario
                          </DialogTitle>
                          <DialogDescription>
                            Modifica la información del usuario
                          </DialogDescription>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                          <div className="grid gap-2">
                            <Label htmlFor="edit-name">Nombre</Label>
                            <Input 
                              id="edit-name" 
                              value={editUserForm.name}
                              onChange={(e) => setEditUserForm(prev => ({ ...prev, name: e.target.value }))}
                            />
                          </div>
                          <div className="grid gap-2">
                            <Label htmlFor="edit-email">Email</Label>
                            <Input 
                              id="edit-email" 
                              type="email"
                              value={editUserForm.email}
                              onChange={(e) => setEditUserForm(prev => ({ ...prev, email: e.target.value }))}
                            />
                          </div>
                          <div className="grid gap-2">
                            <Label htmlFor="edit-role">Rol</Label>
                            <Select 
                              value={editUserForm.role}
                              onValueChange={(value) => setEditUserForm(prev => ({ ...prev, role: value }))}
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="ADMIN">Administrador</SelectItem>
                                <SelectItem value="ORGANIZER">Organizador</SelectItem>
                                <SelectItem value="MODERATOR">Moderador</SelectItem>
                                <SelectItem value="PARTICIPANT">Participante</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="grid gap-2">
                            <Label htmlFor="edit-status">Estado</Label>
                            <Select 
                              value={editUserForm.status}
                              onValueChange={(value) => setEditUserForm(prev => ({ ...prev, status: value }))}
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="active">Activo</SelectItem>
                                <SelectItem value="inactive">Inactivo</SelectItem>
                                <SelectItem value="suspended">Suspendido</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          {selectedUser && (
                            <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                              <div>
                                <p className="text-sm text-muted-foreground">Puntos actuales</p>
                                <p className="text-lg font-bold text-emerald-500">{selectedUser.points}</p>
                              </div>
                              <div>
                                <p className="text-sm text-muted-foreground">Nivel</p>
                                <p className="text-lg font-bold">{selectedUser.level}</p>
                              </div>
                            </div>
                          )}
                        </div>
                        <DialogFooter>
                          <Button variant="outline" onClick={() => setEditUserDialogOpen(false)}>
                            Cancelar
                          </Button>
                          <Button 
                            className="bg-gradient-to-r from-emerald-500 to-teal-600"
                            onClick={handleSaveUser}
                            disabled={savingUser}
                          >
                            {savingUser ? (
                              <>
                                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                                Guardando...
                              </>
                            ) : (
                              'Guardar Cambios'
                            )}
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>

                    {/* View User Dialog */}
                    <Dialog open={viewUserDialogOpen} onOpenChange={setViewUserDialogOpen}>
                      <DialogContent className="max-w-lg">
                        <DialogHeader>
                          <DialogTitle className="flex items-center gap-2">
                            <User className="w-5 h-5" />
                            Detalles del Usuario
                          </DialogTitle>
                        </DialogHeader>
                        {selectedUser && (
                          <div className="space-y-6 py-4">
                            {/* User Header */}
                            <div className="flex items-center gap-4">
                              <Avatar className="w-16 h-16">
                                <AvatarFallback className="text-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white">
                                  {getInitials(selectedUser.name)}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <h3 className="text-xl font-bold">{selectedUser.name}</h3>
                                <p className="text-muted-foreground">{selectedUser.email}</p>
                                <Badge className={getRoleColor(selectedUser.role)}>
                                  {getRoleLabel(selectedUser.role)}
                                </Badge>
                              </div>
                            </div>

                            {/* Stats Grid */}
                            <div className="grid grid-cols-3 gap-4">
                              <Card>
                                <CardContent className="pt-6 text-center">
                                  <Trophy className="w-6 h-6 mx-auto mb-2 text-yellow-500" />
                                  <p className="text-2xl font-bold">{selectedUser.points}</p>
                                  <p className="text-xs text-muted-foreground">Puntos</p>
                                </CardContent>
                              </Card>
                              <Card>
                                <CardContent className="pt-6 text-center">
                                  <Target className="w-6 h-6 mx-auto mb-2 text-blue-500" />
                                  <p className="text-2xl font-bold">{selectedUser.level}</p>
                                  <p className="text-xs text-muted-foreground">Nivel</p>
                                </CardContent>
                              </Card>
                              <Card>
                                <CardContent className="pt-6 text-center">
                                  <Calendar className="w-6 h-6 mx-auto mb-2 text-green-500" />
                                  <p className="text-2xl font-bold">5</p>
                                  <p className="text-xs text-muted-foreground">Actividades</p>
                                </CardContent>
                              </Card>
                            </div>

                            {/* Activity Summary */}
                            <div className="space-y-3">
                              <h4 className="font-semibold">Actividad Reciente</h4>
                              <div className="space-y-2">
                                {[
                                  { action: 'Asistencia registrada', activity: 'Taller de Design Thinking', time: 'Hoy, 10:30' },
                                  { action: 'Voto registrado', activity: 'Proyecto EcoTrack', time: 'Hoy, 09:15' },
                                  { action: 'Logro desbloqueado', activity: 'Participante Activo', time: 'Ayer' },
                                ].map((item, i) => (
                                  <div key={i} className="flex items-center gap-3 p-2 bg-gray-50 dark:bg-gray-800 rounded-lg">
                                    <Check className="w-4 h-4 text-green-500" />
                                    <div className="flex-1">
                                      <p className="text-sm font-medium">{item.action}</p>
                                      <p className="text-xs text-muted-foreground">{item.activity}</p>
                                    </div>
                                    <span className="text-xs text-muted-foreground">{item.time}</span>
                                  </div>
                                ))}
                              </div>
                            </div>

                            {/* Badges */}
                            <div className="space-y-3">
                              <h4 className="font-semibold">Insignias Obtenidas</h4>
                              <div className="flex flex-wrap gap-2">
                                {['Primera Asistencia', 'Votante Activo', 'Explorador', 'Scáner Pro'].map((badge, i) => (
                                  <Badge key={i} variant="secondary" className="gap-1">
                                    <Medal className="w-3 h-3" />
                                    {badge}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          </div>
                        )}
                        <DialogFooter>
                          <Button variant="outline" onClick={() => setViewUserDialogOpen(false)}>
                            Cerrar
                          </Button>
                          <Button 
                            className="bg-gradient-to-r from-emerald-500 to-teal-600"
                            onClick={() => {
                              setViewUserDialogOpen(false);
                              if (selectedUser) {
                                setEditUserForm({
                                  name: selectedUser.name,
                                  email: selectedUser.email,
                                  role: selectedUser.role,
                                  status: selectedUser.status,
                                });
                                setEditUserDialogOpen(true);
                              }
                            }}
                          >
                            <Edit className="w-4 h-4 mr-2" />
                            Editar Usuario
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                )}

                {/* QR Management */}
                {activeTab === 'qr' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h1 className="text-3xl font-bold">Gestión de Códigos QR</h1>
                        <p className="text-muted-foreground">Genera y administra códigos QR</p>
                      </div>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button className="gap-2 bg-gradient-to-r from-emerald-500 to-teal-600">
                            <Plus className="w-4 h-4" />
                            Generar QR
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Generar Código QR</DialogTitle>
                            <DialogDescription>Selecciona el tipo de QR a generar</DialogDescription>
                          </DialogHeader>
                          <div className="grid gap-4 py-4">
                            <div className="grid grid-cols-2 gap-4">
                              <Button variant="outline" className="h-24 flex-col gap-2">
                                <Building className="w-6 h-6" />
                                <span>Sala</span>
                              </Button>
                              <Button variant="outline" className="h-24 flex-col gap-2">
                                <Presentation className="w-6 h-6" />
                                <span>Actividad</span>
                              </Button>
                              <Button variant="outline" className="h-24 flex-col gap-2">
                                <Lightbulb className="w-6 h-6" />
                                <span>Proyecto</span>
                              </Button>
                              <Button variant="outline" className="h-24 flex-col gap-2">
                                <User className="w-6 h-6" />
                                <span>Usuario</span>
                              </Button>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>

                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                      {rooms.map((room) => (
                        <Card key={room.id}>
                          <CardHeader className="pb-3">
                            <CardTitle className="text-lg flex items-center gap-2">
                              <Building className="w-5 h-5" />
                              {room.name}
                            </CardTitle>
                          </CardHeader>
                          <CardContent className="flex flex-col items-center gap-4">
                            <div className="w-40 h-40 bg-white rounded-lg p-2 shadow-inner">
                              <div className="w-full h-full bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAiIGhlaWdodD0iMTAwIj48cmVjdCBmaWxsPSIjZmZmIiB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIvPjx0ZXh0IHg9IjUwIiB5PSI1MCIgZG9taW5hbnQtYmFzZWxpbmU9Im1pZGRsZSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9Im1vbm9zcGFjZSIgZm9udC1zaXplPSIxMCI+UVIgQ29kZTwvdGV4dD48L3N2Zz4=')] bg-contain bg-center bg-no-repeat" />
                            </div>
                            <div className="flex gap-2 w-full">
                              <Button variant="outline" size="sm" className="flex-1">
                                <Download className="w-4 h-4 mr-1" />
                                Descargar
                              </Button>
                              <Button variant="outline" size="sm" className="flex-1">
                                <Copy className="w-4 h-4 mr-1" />
                                Copiar
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}

                {/* Voting Management */}
                {activeTab === 'voting' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h1 className="text-3xl font-bold">Gestión de Votación</h1>
                        <p className="text-muted-foreground">Configura y monitorea la votación de proyectos</p>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" className="gap-2">
                          <RefreshCw className="w-4 h-4" />
                          Actualizar
                        </Button>
                        <Button className="gap-2 bg-gradient-to-r from-emerald-500 to-teal-600">
                          <Settings className="w-4 h-4" />
                          Configurar Votación
                        </Button>
                      </div>
                    </div>

                    {/* Voting Stats */}
                    <div className="grid gap-4 md:grid-cols-3">
                      <Card>
                        <CardContent className="pt-6">
                          <div className="flex items-center gap-4">
                            <div className="p-3 bg-purple-500/10 rounded-xl">
                              <Vote className="w-6 h-6 text-purple-500" />
                            </div>
                            <div>
                              <p className="text-sm text-muted-foreground">Total Votos</p>
                              <p className="text-2xl font-bold">{dashboardStats.totalVotes.toLocaleString()}</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6">
                          <div className="flex items-center gap-4">
                            <div className="p-3 bg-blue-500/10 rounded-xl">
                              <Users className="w-6 h-6 text-blue-500" />
                            </div>
                            <div>
                              <p className="text-sm text-muted-foreground">Participantes que Votaron</p>
                              <p className="text-2xl font-bold">847</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6">
                          <div className="flex items-center gap-4">
                            <div className="p-3 bg-green-500/10 rounded-xl">
                              <Activity className="w-6 h-6 text-green-500" />
                            </div>
                            <div>
                              <p className="text-sm text-muted-foreground">Votos última hora</p>
                              <p className="text-2xl font-bold">156</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    {/* Results */}
                    <Card>
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle>Resultados en Tiempo Real</CardTitle>
                          <div className="flex items-center gap-2">
                            <Badge className="bg-green-500 animate-pulse">EN VIVO</Badge>
                            <Button variant="outline" size="sm">
                              <Download className="w-4 h-4 mr-1" />
                              Exportar
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {projects.map((project, i) => (
                            <div key={project.id} className="flex items-center gap-4">
                              <div className={cn(
                                "w-8 h-8 rounded-full flex items-center justify-center font-bold text-white text-sm",
                                i === 0 ? "bg-amber-500" : i === 1 ? "bg-gray-400" : i === 2 ? "bg-amber-700" : "bg-gray-300 dark:bg-gray-600"
                              )}>
                                {i + 1}
                              </div>
                              <div className="flex-1">
                                <div className="flex items-center justify-between mb-1">
                                  <span className="font-medium">{project.name}</span>
                                  <div className="flex items-center gap-2 text-sm">
                                    <Star className="w-4 h-4 text-yellow-500" />
                                    <span>{project.averageScore?.toFixed(1)}</span>
                                    <span className="text-muted-foreground">({project.totalVotes} votos)</span>
                                  </div>
                                </div>
                                <Progress value={(project.totalVotes / projects[0].totalVotes) * 100} className="h-2" />
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}

                {/* Settings */}
                {activeTab === 'settings' && (
                  <div className="space-y-6">
                    <div>
                      <h1 className="text-3xl font-bold">Configuración</h1>
                      <p className="text-muted-foreground">Ajustes generales del sistema</p>
                    </div>

                    <div className="grid gap-6">
                      <Card>
                        <CardHeader>
                          <CardTitle>Configuración del Evento</CardTitle>
                          <CardDescription>Opciones generales del evento activo</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="flex items-center justify-between">
                            <div className="space-y-0.5">
                              <Label>Votación habilitada</Label>
                              <p className="text-sm text-muted-foreground">Permitir votación de proyectos</p>
                            </div>
                            <Switch defaultChecked />
                          </div>
                          <Separator />
                          <div className="flex items-center justify-between">
                            <div className="space-y-0.5">
                              <Label>Códigos QR activos</Label>
                              <p className="text-sm text-muted-foreground">Habilitar escaneo de QR</p>
                            </div>
                            <Switch defaultChecked />
                          </div>
                          <Separator />
                          <div className="flex items-center justify-between">
                            <div className="space-y-0.5">
                              <Label>Gamificación</Label>
                              <p className="text-sm text-muted-foreground">Sistema de puntos y logros</p>
                            </div>
                            <Switch defaultChecked />
                          </div>
                          <Separator />
                          <div className="flex items-center justify-between">
                            <div className="space-y-0.5">
                              <Label>Notificaciones push</Label>
                              <p className="text-sm text-muted-foreground">Enviar notificaciones a usuarios</p>
                            </div>
                            <Switch defaultChecked />
                          </div>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle>Configuración de Votación</CardTitle>
                          <CardDescription>Parámetros del sistema de votación</CardDescription>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="grid gap-2">
                            <Label>Tipo de votación</Label>
                            <Select defaultValue="stars">
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="like">Like (1 punto)</SelectItem>
                                <SelectItem value="stars">Estrellas (1-5)</SelectItem>
                                <SelectItem value="points">Puntos (1-10)</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="grid gap-2">
                            <Label>Máximo votos por usuario</Label>
                            <Input type="number" defaultValue={3} className="w-32" />
                          </div>
                          <div className="flex items-center gap-2">
                            <Switch id="showResults" />
                            <Label htmlFor="showResults">Mostrar resultados en tiempo real</Label>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                )}
              </motion.div>
            ) : (
              // USER VIEWS
              <motion.div
                key="user"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                {/* User Agenda */}
                {activeTab === 'agenda' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h1 className="text-3xl font-bold">Agenda del Evento</h1>
                        <p className="text-muted-foreground">Todas las actividades programadas</p>
                      </div>
                      <div className="flex gap-2">
                        <Select defaultValue="all">
                          <SelectTrigger className="w-[150px]">
                            <SelectValue placeholder="Filtrar por tipo" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">Todos</SelectItem>
                            <SelectItem value="KEYNOTE">Conferencias</SelectItem>
                            <SelectItem value="WORKSHOP">Talleres</SelectItem>
                            <SelectItem value="PANEL">Paneles</SelectItem>
                            <SelectItem value="NETWORKING">Networking</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Today's Schedule */}
                    <div className="space-y-4">
                      <h2 className="text-xl font-semibold flex items-center gap-2">
                        <Calendar className="w-5 h-5 text-emerald-500" />
                        Hoy - Viernes 15 de Marzo
                      </h2>
                      <div className="grid gap-4">
                        {activities.map((activity) => (
                          <Card key={activity.id} className="hover:shadow-lg transition-shadow overflow-hidden">
                            <div className="flex">
                              <div className={cn("w-2", getActivityTypeColor(activity.type))} />
                              <CardContent className="flex-1 pt-4 pb-4">
                                <div className="flex items-start justify-between gap-4">
                                  <div className="flex-1">
                                    <div className="flex items-center gap-2 mb-2">
                                      <Badge className={getStatusColor(activity.status)}>
                                        {activity.status === 'SCHEDULED' ? 'Próximo' : activity.status === 'IN_PROGRESS' ? 'En curso' : 'Finalizado'}
                                      </Badge>
                                      <Badge variant="outline">{getTypeLabel(activity.type)}</Badge>
                                      {activity.status === 'IN_PROGRESS' && (
                                        <Badge className="bg-red-500 animate-pulse">EN VIVO</Badge>
                                      )}
                                      {userReminders[activity.id]?.set && (
                                        <Badge className="bg-blue-500">Recordatorio activo</Badge>
                                      )}
                                      {userAttendance[activity.id] && (
                                        <Badge className="bg-green-500">Asistencia registrada</Badge>
                                      )}
                                    </div>
                                    <h3 className="text-lg font-bold mb-1">{activity.title}</h3>
                                    <p className="text-sm text-muted-foreground mb-3">{activity.description}</p>
                                    <div className="flex items-center gap-4 mt-3 text-sm">
                                      <span className="flex items-center gap-1 text-muted-foreground">
                                        <Clock className="w-4 h-4" />
                                        {formatTime(activity.startTime)} - {formatTime(activity.endTime)}
                                      </span>
                                      <span className="flex items-center gap-1 text-muted-foreground">
                                        <MapPin className="w-4 h-4" />
                                        {activity.room?.name}
                                      </span>
                                      {activity.speaker && (
                                        <span className="flex items-center gap-1 text-muted-foreground">
                                          <User className="w-4 h-4" />
                                          {activity.speaker.name}
                                        </span>
                                      )}
                                      <span className="flex items-center gap-1 text-muted-foreground">
                                        <Users className="w-4 h-4" />
                                        {activity.currentAttendance} asistentes
                                      </span>
                                    </div>
                                  </div>
                                  <div className="flex flex-col gap-2">
                                    <Button 
                                      variant={userReminders[activity.id]?.set ? "default" : "outline"}
                                      size="sm" 
                                      className="gap-1"
                                      onClick={() => handleSetReminder(activity)}
                                    >
                                      <Bell className="w-4 h-4" />
                                      {userReminders[activity.id]?.set ? 'Editado' : 'Recordatorio'}
                                    </Button>
                                    <Button 
                                      variant={userAttendance[activity.id] ? "default" : "outline"}
                                      size="sm" 
                                      className="gap-1"
                                      onClick={() => handleRegisterAttendance(activity)}
                                      disabled={userAttendance[activity.id]}
                                    >
                                      <QrCode className="w-4 h-4" />
                                      {userAttendance[activity.id] ? 'Registrado' : 'Registrar'}
                                    </Button>
                                  </div>
                                </div>
                              </CardContent>
                            </div>
                          </Card>
                        ))}
                      </div>
                    </div>

                    {/* Reminder Dialog */}
                    <Dialog open={reminderDialogOpen} onOpenChange={setReminderDialogOpen}>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle className="flex items-center gap-2">
                            <Bell className="w-5 h-5" />
                            Configurar Recordatorio
                          </DialogTitle>
                          <DialogDescription>
                            {selectedActivityForAction && (
                              <span>Recibirás una notificación antes de: <strong>{selectedActivityForAction.title}</strong></span>
                            )}
                          </DialogDescription>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                          <div className="grid gap-2">
                            <Label>¿Cuántos minutos antes quieres ser notificado?</Label>
                            <Select value={reminderMinutes} onValueChange={setReminderMinutes}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="5">5 minutos antes</SelectItem>
                                <SelectItem value="10">10 minutos antes</SelectItem>
                                <SelectItem value="15">15 minutos antes</SelectItem>
                                <SelectItem value="30">30 minutos antes</SelectItem>
                                <SelectItem value="60">1 hora antes</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <Alert>
                            <Sparkles className="w-4 h-4" />
                            <AlertTitle>Notificaciones</AlertTitle>
                            <AlertDescription className="flex items-center justify-between gap-2">
                              <span>Activa las notificaciones del navegador para recibir alertas</span>
                              <Button 
                                type="button"
                                variant="outline" 
                                size="sm" 
                                onClick={requestNotificationPermission}
                              >
                                Activar
                              </Button>
                            </AlertDescription>
                          </Alert>
                        </div>
                        <DialogFooter>
                          <Button variant="outline" onClick={() => setReminderDialogOpen(false)}>
                            Cancelar
                          </Button>
                          <Button 
                            className="bg-gradient-to-r from-emerald-500 to-teal-600"
                            onClick={handleConfirmReminder}
                            disabled={settingReminder}
                          >
                            {settingReminder ? (
                              <>
                                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                                Guardando...
                              </>
                            ) : (
                              'Guardar Recordatorio'
                            )}
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>

                    {/* Register Attendance Dialog */}
                    <Dialog open={registerDialogOpen} onOpenChange={setRegisterDialogOpen}>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle className="flex items-center gap-2">
                            <QrCode className="w-5 h-5" />
                            Registrar Asistencia
                          </DialogTitle>
                          <DialogDescription>
                            {selectedActivityForAction && (
                              <span>Confirma tu asistencia a: <strong>{selectedActivityForAction.title}</strong></span>
                            )}
                          </DialogDescription>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                          {selectedActivityForAction && (
                            <Card>
                              <CardContent className="pt-6">
                                <div className="space-y-3">
                                  <div className="flex items-center gap-2">
                                    <Badge className={getStatusColor(selectedActivityForAction.status)}>
                                      {selectedActivityForAction.status === 'SCHEDULED' ? 'Próximo' : 
                                       selectedActivityForAction.status === 'IN_PROGRESS' ? 'En curso' : 'Finalizado'}
                                    </Badge>
                                    <Badge variant="outline">{getTypeLabel(selectedActivityForAction.type)}</Badge>
                                  </div>
                                  <div className="flex items-center gap-4 text-sm">
                                    <span className="flex items-center gap-1">
                                      <Clock className="w-4 h-4" />
                                      {formatTime(selectedActivityForAction.startTime)} - {formatTime(selectedActivityForAction.endTime)}
                                    </span>
                                    <span className="flex items-center gap-1">
                                      <MapPin className="w-4 h-4" />
                                      {selectedActivityForAction.room?.name}
                                    </span>
                                  </div>
                                </div>
                              </CardContent>
                            </Card>
                          )}
                          <Alert className="bg-emerald-50 dark:bg-emerald-950 border-emerald-200 dark:border-emerald-800">
                            <Gift className="w-4 h-4 text-emerald-600" />
                            <AlertTitle>¡Gana puntos!</AlertTitle>
                            <AlertDescription>
                              Al registrar tu asistencia ganarás <strong>+10 puntos</strong> y podrás obtener certificados de participación.
                            </AlertDescription>
                          </Alert>
                        </div>
                        <DialogFooter>
                          <Button variant="outline" onClick={() => setRegisterDialogOpen(false)}>
                            Cancelar
                          </Button>
                          <Button 
                            className="bg-gradient-to-r from-emerald-500 to-teal-600"
                            onClick={handleConfirmAttendance}
                            disabled={registeringAttendance}
                          >
                            {registeringAttendance ? (
                              <>
                                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                                Registrando...
                              </>
                            ) : (
                              <>
                                <Check className="w-4 h-4 mr-2" />
                                Confirmar Asistencia
                              </>
                            )}
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                )}

                {/* Map View */}
                {activeTab === 'map' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h1 className="text-3xl font-bold">Mapa del Evento</h1>
                        <p className="text-muted-foreground">Ubica las salas y actividades</p>
                      </div>
                    </div>

                    {/* Interactive Map Placeholder */}
                    <Card className="overflow-hidden">
                      <div className="relative h-[500px] bg-gradient-to-br from-emerald-50 to-teal-100 dark:from-gray-800 dark:to-gray-900">
                        {/* Map Grid */}
                        <div 
                          className="absolute inset-0 grid grid-cols-4 grid-rows-4 gap-2 p-4 transition-transform duration-300 origin-center"
                          style={{ transform: `scale(${mapZoom})` }}
                        >
                          {rooms.map((room, i) => (
                            <motion.div
                              key={room.id}
                              initial={{ opacity: 0, scale: 0.8 }}
                              animate={{ opacity: 1, scale: 1 }}
                              transition={{ delay: i * 0.1 }}
                              onClick={() => handleRoomClick(room)}
                              className={cn(
                                "relative rounded-lg p-3 cursor-pointer hover:shadow-lg transition-all",
                                selectedRoom?.id === room.id && "ring-4 ring-white ring-opacity-80"
                              )}
                              style={{ backgroundColor: room.color || '#3B82F6' }}
                            >
                              <div className="absolute inset-0 bg-white/20 rounded-lg hover:bg-white/30 transition-colors" />
                              <div className="relative">
                                <Building className="w-6 h-6 text-white mb-2" />
                                <p className="text-white text-sm font-medium line-clamp-2">{room.name}</p>
                                <p className="text-white/80 text-xs mt-1">Cap: {room.capacity}</p>
                              </div>
                            </motion.div>
                          ))}
                        </div>

                        {/* My Location Indicator */}
                        {showMyLocation && myLocation && (
                          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-20">
                            <motion.div
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              className="relative"
                            >
                              <div className="w-4 h-4 bg-blue-500 rounded-full border-2 border-white shadow-lg" />
                              <div className="absolute inset-0 w-4 h-4 bg-blue-500 rounded-full animate-ping opacity-50" />
                            </motion.div>
                          </div>
                        )}

                        {/* Legend */}
                        <div className="absolute bottom-4 left-4 bg-white dark:bg-gray-800 rounded-lg p-3 shadow-lg z-10">
                          <p className="text-sm font-medium mb-2">Leyenda</p>
                          <div className="grid gap-1 text-xs">
                            {rooms.slice(0, 4).map((room, i) => (
                              <button 
                                key={i} 
                                className="flex items-center gap-2 hover:bg-gray-100 dark:hover:bg-gray-700 px-1 rounded text-left w-full"
                                onClick={() => handleRoomClick(room)}
                              >
                                <div className="w-3 h-3 rounded" style={{ backgroundColor: room.color || '#3B82F6' }} />
                                <span>{room.name}</span>
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* Zoom Controls */}
                        <div className="absolute top-4 right-4 flex flex-col gap-2 z-10">
                          <Button 
                            variant="secondary" 
                            size="icon" 
                            onClick={handleZoomIn}
                            disabled={mapZoom >= 2}
                            title="Acercar"
                          >
                            <Plus className="w-4 h-4" />
                          </Button>
                          <Button 
                            variant="secondary" 
                            size="icon" 
                            onClick={handleZoomOut}
                            disabled={mapZoom <= 0.5}
                            title="Alejar"
                          >
                            <Minus className="w-4 h-4" />
                          </Button>
                          <Button 
                            variant="secondary" 
                            size="icon" 
                            onClick={handleShowMyLocation}
                            className={cn(showMyLocation && "bg-blue-500 text-white hover:bg-blue-600")}
                            title="Mi ubicación"
                          >
                            <MapPin className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </Card>

                    {/* Room List */}
                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                      {rooms.map((room) => (
                        <Card 
                          key={room.id} 
                          className={cn(
                            "hover:shadow-lg transition-all cursor-pointer",
                            selectedRoom?.id === room.id && "ring-2 ring-emerald-500"
                          )}
                          onClick={() => handleRoomClick(room)}
                        >
                          <CardContent className="pt-6">
                            <div className="flex items-center gap-3">
                              <div className="w-12 h-12 rounded-lg flex items-center justify-center" style={{ backgroundColor: room.color || '#3B82F6' }}>
                                <Building className="w-6 h-6 text-white" />
                              </div>
                              <div className="flex-1">
                                <h3 className="font-semibold">{room.name}</h3>
                                <p className="text-sm text-muted-foreground">
                                  {room.building} - {room.floor} • Cap: {room.capacity}
                                </p>
                              </div>
                              <ChevronRight className="w-5 h-5 text-muted-foreground" />
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>

                    {/* Room Details Dialog */}
                    <Dialog open={roomDialogOpen} onOpenChange={setRoomDialogOpen}>
                      <DialogContent className="sm:max-w-md">
                        <DialogHeader>
                          <DialogTitle className="flex items-center gap-2">
                            <Building className="w-5 h-5" style={{ color: selectedRoom?.color || '#3B82F6' }} />
                            {selectedRoom?.name}
                          </DialogTitle>
                          <DialogDescription>
                            Información de la sala
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <Card>
                              <CardContent className="pt-4">
                                <div className="flex items-center gap-2">
                                  <Building className="w-4 h-4 text-muted-foreground" />
                                  <span className="text-sm text-muted-foreground">Edificio</span>
                                </div>
                                <p className="font-semibold mt-1">{selectedRoom?.building || 'No especificado'}</p>
                              </CardContent>
                            </Card>
                            <Card>
                              <CardContent className="pt-4">
                                <div className="flex items-center gap-2">
                                  <MapPin className="w-4 h-4 text-muted-foreground" />
                                  <span className="text-sm text-muted-foreground">Piso</span>
                                </div>
                                <p className="font-semibold mt-1">{selectedRoom?.floor || 'No especificado'}</p>
                              </CardContent>
                            </Card>
                          </div>
                          
                          <Card>
                            <CardContent className="pt-4">
                              <div className="flex items-center justify-between">
                                <div>
                                  <p className="text-sm text-muted-foreground">Capacidad máxima</p>
                                  <p className="text-2xl font-bold">{selectedRoom?.capacity} personas</p>
                                </div>
                                <Users className="w-10 h-10 text-emerald-500" />
                              </div>
                            </CardContent>
                          </Card>

                          {/* Activities in this room */}
                          <div>
                            <h4 className="text-sm font-medium mb-2">Actividades en esta sala</h4>
                            <ScrollArea className="max-h-40">
                              <div className="space-y-2">
                                {activities
                                  .filter(a => a.room?.id === selectedRoom?.id)
                                  .slice(0, 3)
                                  .map((activity) => (
                                    <div 
                                      key={activity.id}
                                      className="flex items-center gap-2 p-2 bg-gray-50 dark:bg-gray-800 rounded-lg"
                                    >
                                      <div className={cn("w-2 h-2 rounded-full", getActivityTypeColor(activity.type))} />
                                      <div className="flex-1 min-w-0">
                                        <p className="text-sm font-medium truncate">{activity.title}</p>
                                        <p className="text-xs text-muted-foreground">
                                          {formatTime(activity.startTime)} - {formatTime(activity.endTime)}
                                        </p>
                                      </div>
                                    </div>
                                  ))}
                                {activities.filter(a => a.room?.id === selectedRoom?.id).length === 0 && (
                                  <p className="text-sm text-muted-foreground text-center py-2">
                                    No hay actividades programadas
                                  </p>
                                )}
                              </div>
                            </ScrollArea>
                          </div>
                        </div>
                        <DialogFooter className="flex-col sm:flex-row gap-2">
                          <Button 
                            variant="outline" 
                            className="w-full sm:w-auto"
                            onClick={() => selectedRoom && openExternalMap(selectedRoom)}
                          >
                            <MapPin className="w-4 h-4 mr-2" />
                            Ver en Google Maps
                          </Button>
                          <Button 
                            className="w-full sm:w-auto bg-gradient-to-r from-emerald-500 to-teal-600"
                            onClick={() => selectedRoom && handleGetDirections(selectedRoom)}
                          >
                            <ChevronRight className="w-4 h-4 mr-2" />
                            Cómo llegar
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>

                    {/* Room Location Dialog */}
                    <Dialog open={roomLocationDialogOpen} onOpenChange={setRoomLocationDialogOpen}>
                      <DialogContent className="sm:max-w-lg">
                        <DialogHeader>
                          <DialogTitle className="flex items-center gap-2">
                            <MapPin className="w-5 h-5 text-emerald-500" />
                            Cómo llegar a {selectedRoom?.name}
                          </DialogTitle>
                          <DialogDescription>
                            Direcciones y ubicación de referencia
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          {/* Reference Map Image */}
                          <div className="relative h-48 bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-700 rounded-lg overflow-hidden">
                            <div className="absolute inset-0 flex items-center justify-center">
                              <div className="text-center">
                                <MapPin className="w-12 h-12 text-emerald-500 mx-auto mb-2" />
                                <p className="text-sm text-muted-foreground">
                                  {selectedRoom?.building} - {selectedRoom?.floor}
                                </p>
                              </div>
                            </div>
                            {/* Location marker */}
                            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                              <motion.div
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                className="relative"
                              >
                                <div className="w-8 h-8 rounded-full flex items-center justify-center text-white shadow-lg" 
                                  style={{ backgroundColor: selectedRoom?.color || '#3B82F6' }}>
                                  <Building className="w-4 h-4" />
                                </div>
                              </motion.div>
                            </div>
                          </div>

                          {/* Directions */}
                          <div className="space-y-3">
                            <h4 className="text-sm font-medium">Instrucciones para llegar:</h4>
                            <div className="space-y-2">
                              <div className="flex items-start gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                                <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center text-xs font-bold shrink-0">1</div>
                                <p className="text-sm">Dirígete al <strong>{selectedRoom?.building}</strong></p>
                              </div>
                              <div className="flex items-start gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                                <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center text-xs font-bold shrink-0">2</div>
                                <p className="text-sm">Ubica el acceso a <strong>{selectedRoom?.floor}</strong></p>
                              </div>
                              <div className="flex items-start gap-3 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                                <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center text-xs font-bold shrink-0">3</div>
                                <p className="text-sm">Busca la sala <strong>{selectedRoom?.name}</strong></p>
                              </div>
                            </div>
                          </div>

                          {/* Quick info */}
                          <Alert className="bg-emerald-50 dark:bg-emerald-950 border-emerald-200 dark:border-emerald-800">
                            <Building className="w-4 h-4 text-emerald-600" />
                            <AlertTitle>Información adicional</AlertTitle>
                            <AlertDescription>
                              Capacidad: {selectedRoom?.capacity} personas
                            </AlertDescription>
                          </Alert>
                        </div>
                        <DialogFooter className="flex-col sm:flex-row gap-2">
                          <Button 
                            variant="outline" 
                            className="w-full sm:w-auto"
                            onClick={() => setRoomLocationDialogOpen(false)}
                          >
                            Cerrar
                          </Button>
                          <Button 
                            className="w-full sm:w-auto bg-gradient-to-r from-emerald-500 to-teal-600"
                            onClick={() => selectedRoom && openExternalMap(selectedRoom)}
                          >
                            <MapPin className="w-4 h-4 mr-2" />
                            Abrir en Google Maps
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                )}

                {/* Projects View */}
                {activeTab === 'projects-view' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h1 className="text-3xl font-bold">Proyectos Participantes</h1>
                        <p className="text-muted-foreground">Descubre y vota por los mejores proyectos</p>
                      </div>
                      <div className="flex gap-2">
                        <Select defaultValue="all">
                          <SelectTrigger className="w-[150px]">
                            <SelectValue placeholder="Categoría" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">Todas</SelectItem>
                            <SelectItem value="Sostenibilidad">Sostenibilidad</SelectItem>
                            <SelectItem value="Salud">Salud</SelectItem>
                            <SelectItem value="Educación">Educación</SelectItem>
                            <SelectItem value="Smart Cities">Smart Cities</SelectItem>
                            <SelectItem value="Finanzas">Finanzas</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid gap-6 md:grid-cols-2">
                      {projects.map((project, i) => (
                        <Card key={project.id} className="hover:shadow-xl transition-all hover:-translate-y-1">
                          <CardHeader className="pb-3">
                            <div className="flex items-start justify-between">
                              <div className="flex items-center gap-3">
                                {project.rank && project.rank <= 3 && (
                                  <div className={cn(
                                    "w-10 h-10 rounded-full flex items-center justify-center text-white font-bold",
                                    project.rank === 1 ? "bg-amber-500" : project.rank === 2 ? "bg-gray-400" : "bg-amber-700"
                                  )}>
                                    {project.rank}
                                  </div>
                                )}
                                <div>
                                  <CardTitle>{project.name}</CardTitle>
                                  <CardDescription>{project.team}</CardDescription>
                                </div>
                              </div>
                              <Badge>{project.category}</Badge>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <p className="text-sm text-muted-foreground mb-4">{project.description}</p>
                            <div className="flex items-center justify-between mb-4">
                              <div className="flex items-center gap-2">
                                <div className="flex items-center gap-1">
                                  <Star className="w-5 h-5 text-yellow-500" />
                                  <span className="font-bold">{project.averageScore?.toFixed(1)}</span>
                                </div>
                                <span className="text-sm text-muted-foreground">({project.totalVotes} votos)</span>
                              </div>
                            </div>
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700">
                                  <Vote className="w-4 h-4 mr-2" />
                                  Votar por este proyecto
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Votar por {project.name}</DialogTitle>
                                  <DialogDescription>Califica este proyecto del 1 al 5</DialogDescription>
                                </DialogHeader>
                                <div className="flex justify-center gap-2 py-4">
                                  {[1, 2, 3, 4, 5].map((star) => (
                                    <Button key={star} variant="outline" size="icon" className="w-12 h-12">
                                      <Star className="w-6 h-6" />
                                    </Button>
                                  ))}
                                </div>
                                <DialogFooter>
                                  <Button className="bg-gradient-to-r from-emerald-500 to-teal-600">
                                    Confirmar Voto
                                  </Button>
                                </DialogFooter>
                              </DialogContent>
                            </Dialog>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}

                {/* QR Scanner */}
                {activeTab === 'scanner' && (
                  <QRScannerSection 
                    user={user}
                    onScanSuccess={async (result) => {
                      // Reload user data after successful scan
                      try {
                        const res = await fetch('/api/auth/me');
                        if (res.ok) {
                          const data = await res.json();
                          if (data.success) {
                            setUser(data.data);
                          }
                        }
                      } catch (e) {
                        console.error('Error refreshing user:', e);
                      }
                    }}
                  />
                )}

                {/* Ranking */}
                {activeTab === 'ranking' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h1 className="text-3xl font-bold">Ranking de Participantes</h1>
                        <p className="text-muted-foreground">Los participantes más activos del evento</p>
                      </div>
                    </div>

                    {/* Top 3 */}
                    <div className="grid gap-4 md:grid-cols-3">
                      {leaderboard.slice(0, 3).map((entry, i) => (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: i * 0.1 }}
                        >
                          <Card className={cn(
                            "relative overflow-hidden",
                            i === 0 && "ring-2 ring-amber-400"
                          )}>
                            <div className={cn(
                              "absolute top-0 left-0 right-0 h-2",
                              i === 0 ? "bg-amber-400" : i === 1 ? "bg-gray-400" : "bg-amber-700"
                            )} />
                            <CardContent className="pt-8 text-center">
                              <div className="relative inline-block">
                                <Avatar className="w-20 h-20 mx-auto mb-4">
                                  <AvatarFallback className="text-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white">
                                    {getInitials(entry.name)}
                                  </AvatarFallback>
                                </Avatar>
                                <div className={cn(
                                  "absolute -top-1 -right-1 w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm",
                                  i === 0 ? "bg-amber-400" : i === 1 ? "bg-gray-400" : "bg-amber-700"
                                )}>
                                  {entry.rank}
                                </div>
                              </div>
                              <h3 className="font-bold text-lg">{entry.name}</h3>
                              <p className="text-sm text-muted-foreground">Nivel {entry.level}</p>
                              <div className="mt-4 flex items-center justify-center gap-2">
                                <Trophy className="w-5 h-5 text-emerald-500" />
                                <span className="text-2xl font-bold text-emerald-500">{entry.points.toLocaleString()}</span>
                                <span className="text-muted-foreground">pts</span>
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                    </div>

                    {/* Full Leaderboard */}
                    <Card>
                      <CardHeader>
                        <CardTitle>Clasificación Completa</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          {leaderboard.map((entry, i) => (
                            <div
                              key={i}
                              className={cn(
                                "flex items-center gap-4 p-3 rounded-lg",
                                entry.name === user?.name && "bg-emerald-50 dark:bg-emerald-900/20 ring-1 ring-emerald-500"
                              )}
                            >
                              <div className={cn(
                                "w-10 h-10 rounded-full flex items-center justify-center font-bold text-white",
                                i === 0 ? "bg-amber-400" : i === 1 ? "bg-gray-400" : i === 2 ? "bg-amber-700" : "bg-gray-300 dark:bg-gray-600"
                              )}>
                                {entry.rank}
                              </div>
                              <Avatar>
                                <AvatarFallback>{getInitials(entry.name)}</AvatarFallback>
                              </Avatar>
                              <div className="flex-1">
                                <p className="font-medium">
                                  {entry.name}
                                  {entry.name === user?.name && <span className="ml-2 text-xs text-emerald-500">(Tú)</span>}
                                </p>
                                <p className="text-xs text-muted-foreground">Nivel {entry.level}</p>
                              </div>
                              <div className="text-right">
                                <p className="font-bold text-emerald-500">{entry.points.toLocaleString()}</p>
                                <p className="text-xs text-muted-foreground">puntos</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}

                {/* Achievements */}
                {activeTab === 'achievements' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h1 className="text-3xl font-bold">Logros y Certificados</h1>
                        <p className="text-muted-foreground">Tu progreso y reconocimientos en el evento</p>
                      </div>
                    </div>

                    {/* User Stats */}
                    <div className="grid gap-4 md:grid-cols-4">
                      <Card className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white">
                        <CardContent className="pt-6">
                          <div className="flex items-center gap-4">
                            <Zap className="w-8 h-8" />
                            <div>
                              <p className="text-sm opacity-90">Puntos Totales</p>
                              <p className="text-3xl font-bold">{achievementStats.points || user?.points || 0}</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6">
                          <div className="flex items-center gap-4">
                            <Target className="w-8 h-8 text-blue-500" />
                            <div>
                              <p className="text-sm text-muted-foreground">Nivel Actual</p>
                              <p className="text-3xl font-bold">{achievementStats.level || user?.level || 1}</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6">
                          <div className="flex items-center gap-4">
                            <Calendar className="w-8 h-8 text-purple-500" />
                            <div>
                              <p className="text-sm text-muted-foreground">Asistencias</p>
                              <p className="text-3xl font-bold">{achievementStats.attendanceCount || attendanceCount}</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardContent className="pt-6">
                          <div className="flex items-center gap-4">
                            <Award className="w-8 h-8 text-amber-500" />
                            <div>
                              <p className="text-sm text-muted-foreground">Medallas</p>
                              <p className="text-3xl font-bold">{earnedAchievements.length}</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    {/* Certificates Section */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <FileText className="w-5 h-5" />
                          Certificados de Participación
                        </CardTitle>
                        <CardDescription>
                          {canGenerateCertificate 
                            ? '¡Felicidades! Ya puedes generar tu certificado de participación'
                            : `Necesitas ${3 - attendanceCount} asistencias más para generar tu certificado`
                          }
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        {certificates.length > 0 ? (
                          <div className="space-y-4">
                            {certificates.map((cert) => (
                              <div key={cert.id} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                                <div className="flex items-center gap-4">
                                  <div className="w-12 h-12 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                                    <FileText className="w-6 h-6 text-emerald-500" />
                                  </div>
                                  <div>
                                    <h4 className="font-medium">{cert.title}</h4>
                                    <p className="text-sm text-muted-foreground">
                                      Emitido: {new Date(cert.issueDate).toLocaleDateString('es-ES')}
                                    </p>
                                    <p className="text-xs text-muted-foreground">
                                      Código: {cert.code}
                                    </p>
                                  </div>
                                </div>
                                <div className="flex gap-2">
                                  <Button variant="outline" size="sm">
                                    <Download className="w-4 h-4 mr-1" />
                                    Descargar
                                  </Button>
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="text-center py-6">
                            {canGenerateCertificate ? (
                              <div className="space-y-4">
                                <div className="w-16 h-16 mx-auto rounded-full bg-emerald-500/10 flex items-center justify-center">
                                  <Award className="w-8 h-8 text-emerald-500" />
                                </div>
                                <p className="text-muted-foreground">
                                  ¡Has completado {attendanceCount} asistencias! Ya puedes generar tu certificado.
                                </p>
                                <Button 
                                  className="bg-gradient-to-r from-emerald-500 to-teal-600"
                                  onClick={handleGenerateCertificate}
                                  disabled={generatingCertificate}
                                >
                                  {generatingCertificate ? 'Generando...' : 'Generar Certificado'}
                                </Button>
                              </div>
                            ) : (
                              <div className="space-y-4">
                                <div className="w-16 h-16 mx-auto rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
                                  <Award className="w-8 h-8 text-gray-400" />
                                </div>
                                <p className="text-muted-foreground">
                                  Completa al menos 3 asistencias para generar tu certificado
                                </p>
                                <Progress value={(attendanceCount / 3) * 100} className="h-2 max-w-xs mx-auto" />
                                <p className="text-sm text-muted-foreground">
                                  {attendanceCount} de 3 asistencias completas
                                </p>
                              </div>
                            )}
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    {/* Level Progress */}
                    <Card>
                      <CardHeader>
                        <CardTitle>Progreso al Siguiente Nivel</CardTitle>
                        <CardDescription>Nivel {user?.level} → Nivel {(user?.level || 0) + 1}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Progress value={((achievementStats.points || user?.points || 0) % 100)} className="h-3" />
                        <div className="flex justify-between mt-2 text-sm text-muted-foreground">
                          <span>{achievementStats.points || user?.points || 0} puntos</span>
                          <span>{((user?.level || 0) + 1) * 100} puntos necesarios</span>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Earned Achievements */}
                    {earnedAchievements.length > 0 && (
                      <div>
                        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                          <Trophy className="w-5 h-5 text-amber-500" />
                          Logros Desbloqueados ({earnedAchievements.length})
                        </h2>
                        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                          {earnedAchievements.map((achievement, i) => (
                            <motion.div
                              key={achievement.id}
                              initial={{ opacity: 0, scale: 0.9 }}
                              animate={{ opacity: 1, scale: 1 }}
                              transition={{ delay: i * 0.05 }}
                            >
                              <Card className="hover:shadow-lg transition-shadow border-emerald-200 dark:border-emerald-800">
                                <CardContent className="pt-6">
                                  <div className="flex items-center gap-4">
                                    <div className="w-14 h-14 rounded-xl flex items-center justify-center bg-gradient-to-br from-amber-400 to-amber-600">
                                      <span className="text-2xl">{achievement.icon || '🏆'}</span>
                                    </div>
                                    <div className="flex-1">
                                      <div className="flex items-center gap-2">
                                        <h3 className="font-semibold">{achievement.name}</h3>
                                        <Check className="w-4 h-4 text-emerald-500" />
                                      </div>
                                      <p className="text-sm text-muted-foreground">{achievement.description}</p>
                                      {achievement.earnedAt && (
                                        <p className="text-xs text-muted-foreground mt-1">
                                          Obtenido: {new Date(achievement.earnedAt).toLocaleDateString('es-ES')}
                                        </p>
                                      )}
                                    </div>
                                  </div>
                                </CardContent>
                              </Card>
                            </motion.div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Available Achievements */}
                    {availableAchievements.length > 0 && (
                      <div>
                        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                          <Target className="w-5 h-5 text-blue-500" />
                          Logros por Desbloquear ({availableAchievements.length})
                        </h2>
                        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                          {availableAchievements.map((achievement, i) => (
                            <motion.div
                              key={achievement.id}
                              initial={{ opacity: 0, scale: 0.9 }}
                              animate={{ opacity: 1, scale: 1 }}
                              transition={{ delay: i * 0.05 }}
                            >
                              <Card className="hover:shadow-lg transition-shadow opacity-60">
                                <CardContent className="pt-6">
                                  <div className="flex items-center gap-4">
                                    <div className="w-14 h-14 rounded-xl flex items-center justify-center bg-gray-200 dark:bg-gray-700">
                                      <span className="text-2xl grayscale">{achievement.icon || '🔒'}</span>
                                    </div>
                                    <div className="flex-1">
                                      <h3 className="font-semibold">{achievement.name}</h3>
                                      <p className="text-sm text-muted-foreground">{achievement.description}</p>
                                      {achievement.points > 0 && (
                                        <p className="text-xs text-emerald-500 mt-1">
                                          +{achievement.points} puntos
                                        </p>
                                      )}
                                    </div>
                                  </div>
                                </CardContent>
                              </Card>
                            </motion.div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>

      {/* Mobile Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 border-t bg-white dark:bg-gray-900 lg:hidden z-50">
        <div className="grid grid-cols-5 h-16">
          {currentView === 'admin' ? (
            <>
              {[
                { icon: LayoutDashboard, label: 'Dashboard', tab: 'dashboard' },
                { icon: Calendar, label: 'Eventos', tab: 'events' },
                { icon: Presentation, label: 'Actividades', tab: 'activities' },
                { icon: Lightbulb, label: 'Proyectos', tab: 'projects' },
                { icon: Settings, label: 'Más', tab: 'settings' },
              ].map((item) => (
                <Button
                  key={item.tab}
                  variant="ghost"
                  className={cn(
                    "flex flex-col items-center justify-center h-full rounded-none",
                    activeTab === item.tab && "text-emerald-500 bg-emerald-50 dark:bg-emerald-900/20"
                  )}
                  onClick={() => setActiveTab(item.tab)}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="text-xs mt-1">{item.label}</span>
                </Button>
              ))}
            </>
          ) : (
            <>
              {[
                { icon: Calendar, label: 'Agenda', tab: 'agenda' },
                { icon: MapPin, label: 'Mapa', tab: 'map' },
                { icon: Lightbulb, label: 'Proyectos', tab: 'projects-view' },
                { icon: QrCode, label: 'QR', tab: 'scanner' },
                { icon: Trophy, label: 'Ranking', tab: 'ranking' },
              ].map((item) => (
                <Button
                  key={item.tab}
                  variant="ghost"
                  className={cn(
                    "flex flex-col items-center justify-center h-full rounded-none",
                    activeTab === item.tab && "text-emerald-500 bg-emerald-50 dark:bg-emerald-900/20"
                  )}
                  onClick={() => setActiveTab(item.tab)}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="text-xs mt-1">{item.label}</span>
                </Button>
              ))}
            </>
          )}
        </div>
      </nav>

      {/* Add bottom padding for mobile nav */}
      <div className="h-16 lg:hidden" />
    </div>
  );
}
