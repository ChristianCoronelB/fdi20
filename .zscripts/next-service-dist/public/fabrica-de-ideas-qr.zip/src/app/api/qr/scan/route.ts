import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSession } from '@/lib/auth';

// Helper function to check and award achievements
async function checkAndAwardAchievements(userId: string) {
  const newAchievements = [];

  const [attendanceCount, voteCount, user] = await Promise.all([
    db.attendance.count({ where: { userId } }),
    db.vote.count({ where: { userId } }),
    db.user.findUnique({
      where: { id: userId },
      select: { points: true },
    }),
  ]);

  const points = user?.points || 0;

  const allAchievements = await db.achievement.findMany({
    where: { isActive: true },
  });

  const userAchievements = await db.userAchievement.findMany({
    where: { userId },
    select: { achievementId: true },
  });
  const earnedIds = new Set(userAchievements.map(ua => ua.achievementId));

  for (const achievement of allAchievements) {
    if (earnedIds.has(achievement.id)) continue;

    let earned = false;
    const requirement = achievement.requirement || '';

    if (requirement.includes('attendance')) {
      const match = requirement.match(/attendance:>=(\d+)/);
      if (match && attendanceCount >= parseInt(match[1])) {
        earned = true;
      }
    }

    if (requirement.includes('votes')) {
      const match = requirement.match(/votes:>=(\d+)/);
      if (match && voteCount >= parseInt(match[1])) {
        earned = true;
      }
    }

    if (requirement.includes('points')) {
      const match = requirement.match(/points:>=(\d+)/);
      if (match && points >= parseInt(match[1])) {
        earned = true;
      }
    }

    if (earned) {
      const newAchievement = await db.userAchievement.create({
        data: {
          userId,
          achievementId: achievement.id,
        },
        include: {
          achievement: true,
        },
      });
      newAchievements.push(newAchievement);

      if (achievement.points > 0) {
        await db.user.update({
          where: { id: userId },
          data: { points: { increment: achievement.points } },
        });
      }
    }
  }

  return newAchievements;
}

// POST: Process scanned QR code
export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json(
        { success: false, error: 'No autorizado' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { qrData } = body;

    if (!qrData) {
      return NextResponse.json(
        { success: false, error: 'Datos QR requeridos' },
        { status: 400 }
      );
    }

    // Parse QR data - format: "TYPE:ID:NAME:BUILDING:FLOOR" or JSON
    let qrType: string;
    let entityId: string;
    let entityData: Record<string, unknown> = {};

    // Try to parse as JSON first
    try {
      const parsed = JSON.parse(qrData);
      qrType = parsed.type || 'UNKNOWN';
      entityId = parsed.id || parsed.entityId;
      entityData = parsed;
    } catch {
      // Parse as simple format: "TYPE:ID:NAME:..."
      const parts = qrData.split(':');
      if (parts.length >= 2) {
        qrType = parts[0].toUpperCase();
        entityId = parts[1];
        entityData = {
          type: qrType,
          id: entityId,
          name: parts[2] || '',
          building: parts[3] || '',
          floor: parts[4] || '',
        };
      } else {
        return NextResponse.json(
          { success: false, error: 'Formato QR no válido' },
          { status: 400 }
        );
      }
    }

    const userId = session.userId;
    const pointsPerScan = 10;
    let result: {
      type: string;
      name: string;
      points: number;
      message: string;
      activity?: Record<string, unknown>;
      room?: Record<string, unknown>;
      project?: Record<string, unknown>;
    } = {
      type: qrType,
      name: '',
      points: 0,
      message: '',
    };

    switch (qrType) {
      case 'ACTIVITY':
      case 'ACTIVIDAD': {
        // Find the activity
        const activity = await db.activity.findUnique({
          where: { id: entityId },
          include: {
            room: {
              select: { id: true, name: true, building: true, floor: true },
            },
            speaker: {
              select: { id: true, name: true },
            },
            event: {
              select: { id: true, name: true },
            },
          },
        });

        if (!activity) {
          return NextResponse.json(
            { success: false, error: 'Actividad no encontrada' },
            { status: 404 }
          );
        }

        // Check if already attended
        const existingAttendance = await db.attendance.findUnique({
          where: {
            userId_activityId: {
              userId,
              activityId: entityId,
            },
          },
        });

        if (existingAttendance) {
          // If has check-in but no check-out, register check-out
          if (existingAttendance.checkInTime && !existingAttendance.checkOutTime) {
            const updated = await db.attendance.update({
              where: { id: existingAttendance.id },
              data: { checkOutTime: new Date() },
            });

            // Award bonus points for completing attendance
            const bonusPoints = 5;
            await db.user.update({
              where: { id: userId },
              data: { points: { increment: bonusPoints } },
            });

            result = {
              type: 'ACTIVITY',
              name: activity.title,
              points: bonusPoints,
              message: `Check-out registrado. ¡+${bonusPoints} puntos adicionales!`,
              activity: {
                id: activity.id,
                title: activity.title,
                type: activity.type,
                room: activity.room,
              },
            };
          } else {
            result = {
              type: 'ACTIVITY',
              name: activity.title,
              points: 0,
              message: 'Ya tienes asistencia registrada en esta actividad',
              activity: {
                id: activity.id,
                title: activity.title,
                type: activity.type,
                room: activity.room,
              },
            };
          }
        } else {
          // Create new attendance
          const attendance = await db.attendance.create({
            data: {
              userId,
              activityId: entityId,
              points: pointsPerScan,
              checkInTime: new Date(),
            },
          });

          // Update user points
          await db.user.update({
            where: { id: userId },
            data: { points: { increment: pointsPerScan } },
          });

          // Update activity attendance count
          await db.activity.update({
            where: { id: entityId },
            data: { currentAttendance: { increment: 1 } },
          });

          result = {
            type: 'ACTIVITY',
            name: activity.title,
            points: pointsPerScan,
            message: `¡Asistencia registrada! +${pointsPerScan} puntos`,
            activity: {
              id: activity.id,
              title: activity.title,
              type: activity.type,
              room: activity.room,
              speaker: activity.speaker,
            },
          };
        }

        // Check achievements
        const newAchievements = await checkAndAwardAchievements(userId);
        result.points += newAchievements.reduce((sum, a) => sum + a.achievement.points, 0);
        break;
      }

      case 'ROOM':
      case 'SALA': {
        const room = await db.room.findUnique({
          where: { id: entityId },
          include: {
            activities: {
              where: {
                startTime: { lte: new Date() },
                endTime: { gte: new Date() },
              },
              take: 1,
            },
          },
        });

        if (!room) {
          return NextResponse.json(
            { success: false, error: 'Sala no encontrada' },
            { status: 404 }
          );
        }

        // Find current activity in this room
        const currentActivity = room.activities[0];

        if (currentActivity) {
          // Register attendance for current activity
          const existing = await db.attendance.findUnique({
            where: {
              userId_activityId: {
                userId,
                activityId: currentActivity.id,
              },
            },
          });

          if (!existing) {
            await db.attendance.create({
              data: {
                userId,
                activityId: currentActivity.id,
                points: pointsPerScan,
                checkInTime: new Date(),
              },
            });

            await db.user.update({
              where: { id: userId },
              data: { points: { increment: pointsPerScan } },
            });

            await db.activity.update({
              where: { id: currentActivity.id },
              data: { currentAttendance: { increment: 1 } },
            });

            await checkAndAwardAchievements(userId);

            result = {
              type: 'ACTIVITY',
              name: currentActivity.title,
              points: pointsPerScan,
              message: `¡Asistencia registrada a ${currentActivity.title}! +${pointsPerScan} puntos`,
              room: {
                id: room.id,
                name: room.name,
                building: room.building,
                floor: room.floor,
              },
              activity: {
                id: currentActivity.id,
                title: currentActivity.title,
              },
            };
          } else {
            result = {
              type: 'ROOM',
              name: room.name,
              points: 0,
              message: 'Ya tienes asistencia en la actividad actual de esta sala',
              room: {
                id: room.id,
                name: room.name,
                building: room.building,
                floor: room.floor,
              },
            };
          }
        } else {
          result = {
            type: 'ROOM',
            name: room.name,
            points: 5,
            message: `Ubicación: ${room.name}. +5 puntos por explorar`,
            room: {
              id: room.id,
              name: room.name,
              building: room.building,
              floor: room.floor,
            },
          };

          // Award exploration points
          await db.user.update({
            where: { id: userId },
            data: { points: { increment: 5 } },
          });
        }
        break;
      }

      case 'PROJECT':
      case 'PROYECTO': {
        const project = await db.project.findUnique({
          where: { id: entityId },
          include: {
            event: {
              select: { id: true, name: true },
            },
          },
        });

        if (!project) {
          return NextResponse.json(
            { success: false, error: 'Proyecto no encontrado' },
            { status: 404 }
          );
        }

        result = {
          type: 'PROJECT',
          name: project.name,
          points: 5,
          message: `Proyecto: ${project.name}. +5 puntos por visitar`,
          project: {
            id: project.id,
            name: project.name,
            category: project.category,
            description: project.description,
            team: project.team,
          },
        };

        // Award visit points
        await db.user.update({
          where: { id: userId },
          data: { points: { increment: 5 } },
        });
        break;
      }

      case 'EVENT':
      case 'EVENTO': {
        const event = await db.event.findUnique({
          where: { id: entityId },
        });

        if (!event) {
          return NextResponse.json(
            { success: false, error: 'Evento no encontrado' },
            { status: 404 }
          );
        }

        result = {
          type: 'EVENT',
          name: event.name,
          points: 15,
          message: `¡Bienvenido a ${event.name}! +15 puntos`,
        };

        // Award welcome points
        await db.user.update({
          where: { id: userId },
          data: { points: { increment: 15 } },
        });
        break;
      }

      default:
        return NextResponse.json(
          { success: false, error: `Tipo de QR no reconocido: ${qrType}` },
          { status: 400 }
        );
    }

    // Get updated user info
    const updatedUser = await db.user.findUnique({
      where: { id: userId },
      select: { points: true, level: true },
    });

    return NextResponse.json({
      success: true,
      data: result,
      user: updatedUser,
    });
  } catch (error) {
    console.error('QR scan error:', error);
    return NextResponse.json(
      { success: false, error: 'Error al procesar el código QR' },
      { status: 500 }
    );
  }
}
