import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🔄 Creando usuario administrador...\n');
  
  // Generar hash de la contraseña
  const hashedPassword = await bcrypt.hash('admin123', 10);
  console.log('📝 Hash generado:', hashedPassword);
  
  // Crear o actualizar el usuario admin
  const admin = await prisma.user.upsert({
    where: { email: 'admin@fabricadeideas.com' },
    update: {
      password: hashedPassword,
      role: 'ADMIN',
      isActive: true,
    },
    create: {
      email: 'admin@fabricadeideas.com',
      password: hashedPassword,
      name: 'Administrador',
      role: 'ADMIN',
      points: 0,
      level: 1,
      isActive: true,
    },
  });

  console.log('\n✅ Usuario creado/actualizado correctamente:');
  console.log('   ID:', admin.id);
  console.log('   Email:', admin.email);
  console.log('   Nombre:', admin.name);
  console.log('   Rol:', admin.role);
  console.log('\n🔑 Credenciales de acceso:');
  console.log('   Email: admin@fabricadeideas.com');
  console.log('   Password: admin123');
  
  // Verificar que el hash funciona
  const isValid = await bcrypt.compare('admin123', admin.password);
  console.log('\n🔍 Verificación del hash:', isValid ? '✅ Correcto' : '❌ Error');
}

main()
  .catch((e) => {
    console.error('❌ Error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
