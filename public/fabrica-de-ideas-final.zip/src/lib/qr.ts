import QRCode from 'qrcode';
import { db } from './db';
import type { QRType } from '@prisma/client';

export async function generateQRCode(data: string): Promise<string> {
  return QRCode.toDataURL(data, {
    width: 400,
    margin: 2,
    color: {
      dark: '#1f2937',
      light: '#ffffff',
    },
  });
}

export async function generateUniqueCode(): Promise<string> {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = '';
  for (let i = 0; i < 8; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  
  // Ensure uniqueness
  const existing = await db.qRCode.findUnique({ where: { code } });
  if (existing) {
    return generateUniqueCode();
  }
  
  return code;
}

export async function createQRCode(params: {
  type: QRType;
  userId?: string;
  roomId?: string;
  activityId?: string;
  projectId?: string;
  eventId?: string;
  expiresAt?: Date;
}): Promise<{ id: string; code: string; qrImage: string }> {
  const code = await generateUniqueCode();
  
  const qrCode = await db.qRCode.create({
    data: {
      code,
      type: params.type,
      userId: params.userId,
      roomId: params.roomId,
      activityId: params.activityId,
      projectId: params.projectId,
      eventId: params.eventId,
      expiresAt: params.expiresAt,
    },
  });
  
  const qrImage = await generateQRCode(code);
  
  return { id: qrCode.id, code, qrImage };
}

export async function scanQRCode(code: string, userId: string): Promise<{
  success: boolean;
  type: QRType;
  data?: {
    room?: { id: string; name: string };
    activity?: { id: string; title: string };
    project?: { id: string; name: string };
    user?: { id: string; name: string };
  };
  message: string;
}> {
  const qrCode = await db.qRCode.findUnique({
    where: { code },
    include: {
      room: true,
      activity: true,
      project: true,
      user: true,
    },
  });
  
  if (!qrCode) {
    return { success: false, type: 'ROOM', message: 'Código QR no válido' };
  }
  
  if (!qrCode.isActive) {
    return { success: false, type: qrCode.type, message: 'Código QR desactivado' };
  }
  
  if (qrCode.expiresAt && qrCode.expiresAt < new Date()) {
    return { success: false, type: qrCode.type, message: 'Código QR expirado' };
  }
  
  // Increment scan count
  await db.qRCode.update({
    where: { id: qrCode.id },
    data: { scanCount: { increment: 1 } },
  });
  
  // Handle different QR types
  switch (qrCode.type) {
    case 'ACTIVITY':
      if (qrCode.activityId) {
        // Check if already attended
        const existing = await db.attendance.findUnique({
          where: {
            userId_activityId: {
              userId,
              activityId: qrCode.activityId,
            },
          },
        });
        
        if (!existing) {
          // Create attendance record
          await db.attendance.create({
            data: {
              userId,
              activityId: qrCode.activityId,
              points: 10, // Default points for attendance
            },
          });
          
          // Update user points
          await db.user.update({
            where: { id: userId },
            data: { points: { increment: 10 } },
          });
          
          // Update activity attendance count
          await db.activity.update({
            where: { id: qrCode.activityId },
            data: { currentAttendance: { increment: 1 } },
          });
        }
        
        return {
          success: true,
          type: qrCode.type,
          data: {
            activity: {
              id: qrCode.activity!.id,
              name: qrCode.activity!.title,
            },
          },
          message: existing ? 'Ya registraste asistencia a esta actividad' : 'Asistencia registrada correctamente',
        };
      }
      break;
      
    case 'PROJECT':
      return {
        success: true,
        type: qrCode.type,
        data: qrCode.project ? {
          project: { id: qrCode.project.id, name: qrCode.project.name },
        } : undefined,
        message: 'Proyecto encontrado',
      };
      
    case 'ROOM':
      return {
        success: true,
        type: qrCode.type,
        data: qrCode.room ? {
          room: { id: qrCode.room.id, name: qrCode.room.name },
        } : undefined,
        message: 'Sala encontrada',
      };
      
    case 'USER':
      return {
        success: true,
        type: qrCode.type,
        data: qrCode.user ? {
          user: { id: qrCode.user.id, name: qrCode.user.name },
        } : undefined,
        message: 'Usuario encontrado',
      };
  }
  
  return { success: false, type: qrCode.type, message: 'Tipo de QR no soportado' };
}
