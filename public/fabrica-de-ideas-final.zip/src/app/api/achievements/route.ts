import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { db } from '@/lib/db';

// GET /api/achievements - List all achievements and user's earned achievements
export async function GET(request: NextRequest) {
  try {
    const session = await getSession();
    
    if (!session) {
      return NextResponse.json(
        { success: false, error: 'No autenticado' },
        { status: 401 }
      );
    }
    
    const searchParams = request.nextUrl.searchParams;
    const userId = searchParams.get('userId') || session.userId;
    
    // Only admins can view other users' achievements
    if (userId !== session.userId && session.role !== 'ADMIN') {
      return NextResponse.json(
        { success: false, error: 'No autorizado' },
        { status: 403 }
      );
    }

    // Get all active achievements
    const allAchievements = await db.achievement.findMany({
      where: { isActive: true },
      orderBy: [{ category: 'asc' }, { points: 'asc' }],
    });

    // Get user's earned achievements
    const userAchievements = await db.userAchievement.findMany({
      where: { userId },
      include: {
        achievement: true,
      },
      orderBy: { earnedAt: 'desc' },
    });

    // Create a map of earned achievement IDs
    const earnedIds = new Set(userAchievements.map(ua => ua.achievementId));

    // Separate earned and available achievements
    const earned = userAchievements.map(ua => ({
      id: ua.achievement.id,
      name: ua.achievement.name,
      description: ua.achievement.description,
      icon: ua.achievement.icon,
      points: ua.achievement.points,
      category: ua.achievement.category,
      earnedAt: ua.earnedAt,
    }));

    const available = allAchievements
      .filter(a => !earnedIds.has(a.id))
      .map(a => ({
        id: a.id,
        name: a.name,
        description: a.description,
        icon: a.icon,
        points: a.points,
        category: a.category,
        requirement: a.requirement,
      }));

    // Get user stats for progress calculation
    const userStats = await getUserStats(userId);

    return NextResponse.json({
      success: true,
      data: {
        earned,
        available,
        stats: userStats,
      },
    });
  } catch (error) {
    console.error('Get achievements error:', error);
    return NextResponse.json(
      { success: false, error: 'Error al obtener logros' },
      { status: 500 }
    );
  }
}

// Helper function to get user stats
async function getUserStats(userId: string) {
  const [attendanceCount, voteCount, user] = await Promise.all([
    db.attendance.count({ where: { userId } }),
    db.vote.count({ where: { userId } }),
    db.user.findUnique({
      where: { id: userId },
      select: { points: true, level: true },
    }),
  ]);

  return {
    attendanceCount,
    voteCount,
    points: user?.points || 0,
    level: user?.level || 1,
  };
}

// POST /api/achievements - Check and award achievements for a user
export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    
    if (!session) {
      return NextResponse.json(
        { success: false, error: 'No autenticado' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { userId } = body;
    const targetUserId = userId || session.userId;

    // Only admins can check achievements for other users
    if (targetUserId !== session.userId && session.role !== 'ADMIN') {
      return NextResponse.json(
        { success: false, error: 'No autorizado' },
        { status: 403 }
      );
    }

    // Get user stats
    const stats = await getUserStats(targetUserId);

    // Get all achievements
    const allAchievements = await db.achievement.findMany({
      where: { isActive: true },
    });

    // Get user's earned achievements
    const userAchievements = await db.userAchievement.findMany({
      where: { userId: targetUserId },
      select: { achievementId: true },
    });
    const earnedIds = new Set(userAchievements.map(ua => ua.achievementId));

    // Check each achievement
    const newAchievements = [];

    for (const achievement of allAchievements) {
      if (earnedIds.has(achievement.id)) continue;

      let earned = false;
      const requirement = achievement.requirement || '';

      // Check attendance-based achievements
      if (requirement.includes('attendance')) {
        const match = requirement.match(/attendance:>=(\d+)/);
        if (match && stats.attendanceCount >= parseInt(match[1])) {
          earned = true;
        }
      }

      // Check vote-based achievements
      if (requirement.includes('votes')) {
        const match = requirement.match(/votes:>=(\d+)/);
        if (match && stats.voteCount >= parseInt(match[1])) {
          earned = true;
        }
      }

      // Check points-based achievements
      if (requirement.includes('points')) {
        const match = requirement.match(/points:>=(\d+)/);
        if (match && stats.points >= parseInt(match[1])) {
          earned = true;
        }
      }

      if (earned) {
        // Award the achievement
        const newAchievement = await db.userAchievement.create({
          data: {
            userId: targetUserId,
            achievementId: achievement.id,
          },
          include: {
            achievement: true,
          },
        });
        newAchievements.push(newAchievement);

        // Add points for earning the achievement
        if (achievement.points > 0) {
          await db.user.update({
            where: { id: targetUserId },
            data: { points: { increment: achievement.points } },
          });
        }
      }
    }

    return NextResponse.json({
      success: true,
      data: {
        newAchievements: newAchievements.map(na => ({
          id: na.achievement.id,
          name: na.achievement.name,
          description: na.achievement.description,
          icon: na.achievement.icon,
          points: na.achievement.points,
          earnedAt: na.earnedAt,
        })),
        totalAwarded: newAchievements.length,
      },
    });
  } catch (error) {
    console.error('Check achievements error:', error);
    return NextResponse.json(
      { success: false, error: 'Error al verificar logros' },
      { status: 500 }
    );
  }
}
