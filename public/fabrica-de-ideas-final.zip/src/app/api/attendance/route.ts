import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSession } from '@/lib/auth';

// Helper function to check and award achievements
async function checkAndAwardAchievements(userId: string) {
  const newAchievements = [];

  // Get user stats
  const [attendanceCount, voteCount, user] = await Promise.all([
    db.attendance.count({ where: { userId } }),
    db.vote.count({ where: { userId } }),
    db.user.findUnique({
      where: { id: userId },
      select: { points: true },
    }),
  ]);

  const points = user?.points || 0;

  // Get all achievements
  const allAchievements = await db.achievement.findMany({
    where: { isActive: true },
  });

  // Get user's earned achievements
  const userAchievements = await db.userAchievement.findMany({
    where: { userId },
    select: { achievementId: true },
  });
  const earnedIds = new Set(userAchievements.map(ua => ua.achievementId));

  // Check each achievement
  for (const achievement of allAchievements) {
    if (earnedIds.has(achievement.id)) continue;

    let earned = false;
    const requirement = achievement.requirement || '';

    // Check attendance-based achievements
    if (requirement.includes('attendance')) {
      const match = requirement.match(/attendance:>=(\d+)/);
      if (match && attendanceCount >= parseInt(match[1])) {
        earned = true;
      }
    }

    // Check vote-based achievements
    if (requirement.includes('votes')) {
      const match = requirement.match(/votes:>=(\d+)/);
      if (match && voteCount >= parseInt(match[1])) {
        earned = true;
      }
    }

    // Check points-based achievements
    if (requirement.includes('points')) {
      const match = requirement.match(/points:>=(\d+)/);
      if (match && points >= parseInt(match[1])) {
        earned = true;
      }
    }

    if (earned) {
      // Award the achievement
      const newAchievement = await db.userAchievement.create({
        data: {
          userId,
          achievementId: achievement.id,
        },
        include: {
          achievement: true,
        },
      });
      newAchievements.push(newAchievement);

      // Add points for earning the achievement
      if (achievement.points > 0) {
        await db.user.update({
          where: { id: userId },
          data: { points: { increment: achievement.points } },
        });
      }
    }
  }

  return newAchievements;
}

// GET: List attendance records (filter by userId, activityId, eventId)
export async function GET(request: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json(
        { success: false, error: 'No autorizado' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    const activityId = searchParams.get('activityId');
    const eventId = searchParams.get('eventId');
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const skip = (page - 1) * limit;

    const where: any = {};

    if (userId) {
      where.userId = userId;
    }

    if (activityId) {
      where.activityId = activityId;
    }

    if (eventId) {
      where.activity = {
        eventId,
      };
    }

    const [attendances, total] = await Promise.all([
      db.attendance.findMany({
        where,
        include: {
          user: {
            select: {
              id: true,
              name: true,
              email: true,
              avatar: true,
              role: true,
            },
          },
          activity: {
            select: {
              id: true,
              title: true,
              type: true,
              startTime: true,
              endTime: true,
              room: {
                select: {
                  id: true,
                  name: true,
                },
              },
            },
          },
        },
        orderBy: { checkInTime: 'desc' },
        skip,
        take: limit,
      }),
      db.attendance.count({ where }),
    ]);

    return NextResponse.json({
      success: true,
      data: attendances,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Get attendance error:', error);
    return NextResponse.json(
      { success: false, error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}

// POST: Create attendance record (authenticated users)
export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json(
        { success: false, error: 'No autorizado' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { userId, activityId, points = 10, notes, checkOutTime } = body;

    if (!activityId) {
      return NextResponse.json(
        { success: false, error: 'ID de actividad requerido' },
        { status: 400 }
      );
    }

    // Use the authenticated user's ID if not provided (admin only can set userId)
    const targetUserId = userId || session.userId;

    // Check if activity exists
    const activity = await db.activity.findUnique({
      where: { id: activityId },
    });

    if (!activity) {
      return NextResponse.json(
        { success: false, error: 'Actividad no encontrada' },
        { status: 404 }
      );
    }

    // Check if already attended
    const existing = await db.attendance.findUnique({
      where: {
        userId_activityId: {
          userId: targetUserId,
          activityId,
        },
      },
    });

    if (existing) {
      // If checkOutTime is provided, update the existing record
      if (checkOutTime && !existing.checkOutTime) {
        const updated = await db.attendance.update({
          where: { id: existing.id },
          data: { checkOutTime: new Date(checkOutTime) },
          include: {
            user: {
              select: { id: true, name: true, email: true },
            },
            activity: {
              select: { id: true, title: true },
            },
          },
        });

        // Check for achievements after checkout
        const newAchievements = await checkAndAwardAchievements(targetUserId);

        return NextResponse.json({
          success: true,
          data: updated,
          newAchievements: newAchievements.map(na => ({
            name: na.achievement.name,
            icon: na.achievement.icon,
            points: na.achievement.points,
          })),
        });
      }

      return NextResponse.json(
        { success: false, error: 'Ya existe un registro de asistencia' },
        { status: 400 }
      );
    }

    // Create attendance record with check-in time
    const attendance = await db.attendance.create({
      data: {
        userId: targetUserId,
        activityId,
        points,
        notes,
        checkOutTime: checkOutTime ? new Date(checkOutTime) : null,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        activity: {
          select: {
            id: true,
            title: true,
          },
        },
      },
    });

    // Update user points (+10 points per attendance)
    await db.user.update({
      where: { id: targetUserId },
      data: { points: { increment: points } },
    });

    // Update activity attendance count
    await db.activity.update({
      where: { id: activityId },
      data: { currentAttendance: { increment: 1 } },
    });

    // Check for achievements
    const newAchievements = await checkAndAwardAchievements(targetUserId);

    return NextResponse.json({
      success: true,
      data: attendance,
      pointsEarned: points,
      newAchievements: newAchievements.map(na => ({
        name: na.achievement.name,
        icon: na.achievement.icon,
        points: na.achievement.points,
      })),
    });
  } catch (error) {
    console.error('Create attendance error:', error);
    return NextResponse.json(
      { success: false, error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}

// PUT: Update attendance (for check-out)
export async function PUT(request: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json(
        { success: false, error: 'No autorizado' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { id, checkOutTime } = body;

    if (!id) {
      return NextResponse.json(
        { success: false, error: 'ID de asistencia requerido' },
        { status: 400 }
      );
    }

    const existing = await db.attendance.findUnique({
      where: { id },
    });

    if (!existing) {
      return NextResponse.json(
        { success: false, error: 'Asistencia no encontrada' },
        { status: 404 }
      );
    }

    // Only the user themselves or admin can update
    if (existing.userId !== session.userId && session.role !== 'ADMIN') {
      return NextResponse.json(
        { success: false, error: 'No autorizado' },
        { status: 403 }
      );
    }

    const attendance = await db.attendance.update({
      where: { id },
      data: {
        checkOutTime: checkOutTime ? new Date(checkOutTime) : new Date(),
      },
      include: {
        user: {
          select: { id: true, name: true, email: true },
        },
        activity: {
          select: { id: true, title: true },
        },
      },
    });

    // Check for achievements after checkout
    const newAchievements = await checkAndAwardAchievements(existing.userId);

    return NextResponse.json({
      success: true,
      data: attendance,
      newAchievements: newAchievements.map(na => ({
        name: na.achievement.name,
        icon: na.achievement.icon,
        points: na.achievement.points,
      })),
    });
  } catch (error) {
    console.error('Update attendance error:', error);
    return NextResponse.json(
      { success: false, error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
