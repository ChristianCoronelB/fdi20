import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSession } from '@/lib/auth';

// GET /api/votes - List votes (filter by projectId, userId)
export async function GET(request: NextRequest) {
  try {
    const session = await getSession();
    
    if (!session) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const projectId = searchParams.get('projectId');
    const userId = searchParams.get('userId');
    const limit = searchParams.get('limit');
    const offset = searchParams.get('offset');

    const where: Record<string, unknown> = {};
    
    // Non-admin users can only see their own votes when filtering by userId
    if (userId) {
      if (session.role !== 'ADMIN' && session.userId !== userId) {
        return NextResponse.json(
          { success: false, error: 'You can only view your own votes' },
          { status: 403 }
        );
      }
      where.userId = userId;
    }
    
    if (projectId) {
      where.projectId = projectId;
    }

    const votes = await db.vote.findMany({
      where,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
        project: {
          select: {
            id: true,
            name: true,
            category: true,
            status: true,
            event: {
              select: {
                id: true,
                name: true,
              },
            },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
      ...(limit && { take: parseInt(limit) }),
      ...(offset && { skip: parseInt(offset) }),
    });

    // Get total count for pagination
    const total = await db.vote.count({ where });

    return NextResponse.json({
      success: true,
      data: votes,
      meta: {
        total,
        limit: limit ? parseInt(limit) : null,
        offset: offset ? parseInt(offset) : null,
      },
    });
  } catch (error) {
    console.error('Error fetching votes:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch votes' },
      { status: 500 }
    );
  }
}

// POST /api/votes - Create vote (authenticated users, one vote per user per project)
export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    
    if (!session) {
      return NextResponse.json(
        { success: false, error: 'Authentication required' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { projectId, score, comment } = body;

    if (!projectId) {
      return NextResponse.json(
        { success: false, error: 'Project ID is required' },
        { status: 400 }
      );
    }

    // Verify project exists and is approved/finalist/winner
    const project = await db.project.findUnique({
      where: { id: projectId },
      include: {
        event: {
          select: {
            votingEnabled: true,
          },
        },
      },
    });

    if (!project) {
      return NextResponse.json(
        { success: false, error: 'Project not found' },
        { status: 404 }
      );
    }

    if (!project.isActive) {
      return NextResponse.json(
        { success: false, error: 'Project is not active' },
        { status: 400 }
      );
    }

    // Check if voting is enabled for this event
    if (!project.event.votingEnabled) {
      return NextResponse.json(
        { success: false, error: 'Voting is not enabled for this event' },
        { status: 400 }
      );
    }

    // Check if project is in a votable status
    const votableStatuses = ['APPROVED', 'FINALIST', 'WINNER'];
    if (!votableStatuses.includes(project.status)) {
      return NextResponse.json(
        { success: false, error: 'This project is not open for voting' },
        { status: 400 }
      );
    }

    // Check if user already voted for this project (one vote per user per project)
    const existingVote = await db.vote.findUnique({
      where: {
        userId_projectId: {
          userId: session.userId,
          projectId,
        },
      },
    });

    if (existingVote) {
      return NextResponse.json(
        { success: false, error: 'You have already voted for this project' },
        { status: 400 }
      );
    }

    // Validate score (1 for like, 1-5 for stars, 1-10 for points)
    const voteScore = score || 1;
    if (voteScore < 1 || voteScore > 10) {
      return NextResponse.json(
        { success: false, error: 'Score must be between 1 and 10' },
        { status: 400 }
      );
    }

    // Create vote and update project vote count
    const vote = await db.$transaction(async (tx) => {
      const newVote = await tx.vote.create({
        data: {
          userId: session.userId,
          projectId,
          score: voteScore,
          comment,
        },
        include: {
          user: {
            select: {
              id: true,
              name: true,
              avatar: true,
            },
          },
          project: {
            select: {
              id: true,
              name: true,
            },
          },
        },
      });

      // Update project total votes
      await tx.project.update({
        where: { id: projectId },
        data: {
          totalVotes: { increment: 1 },
        },
      });

      return newVote;
    });

    return NextResponse.json({
      success: true,
      data: vote,
    }, { status: 201 });
  } catch (error) {
    console.error('Error creating vote:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to create vote' },
      { status: 500 }
    );
  }
}
