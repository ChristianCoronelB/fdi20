import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSession, hasRole } from '@/lib/auth';
import { UserRole } from '@prisma/client';

// GET: List all events with pagination and filtering
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const isActive = searchParams.get('isActive');
    const search = searchParams.get('search');
    
    const skip = (page - 1) * limit;
    
    const where: Record<string, unknown> = {};
    
    if (isActive !== null && isActive !== undefined) {
      where.isActive = isActive === 'true';
    }
    
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { description: { contains: search } },
      ];
    }
    
    const [events, total] = await Promise.all([
      db.event.findMany({
        where,
        include: {
          creator: {
            select: {
              id: true,
              name: true,
              email: true,
              avatar: true,
            },
          },
          _count: {
            select: {
              rooms: true,
              activities: true,
              projects: true,
              speakers: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.event.count({ where }),
    ]);
    
    return NextResponse.json({
      success: true,
      data: {
        events,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    });
  } catch (error) {
    console.error('Error fetching events:', error);
    return NextResponse.json(
      { success: false, error: 'Error al obtener eventos' },
      { status: 500 }
    );
  }
}

// POST: Create new event (requires ADMIN/ORGANIZER role)
export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    
    if (!session) {
      return NextResponse.json(
        { success: false, error: 'No autenticado' },
        { status: 401 }
      );
    }
    
    if (!hasRole(session.role as UserRole, ['ADMIN', 'ORGANIZER'])) {
      return NextResponse.json(
        { success: false, error: 'No tienes permisos para crear eventos' },
        { status: 403 }
      );
    }
    
    const body = await request.json();
    const {
      name,
      slug,
      description,
      logo,
      image,
      startDate,
      endDate,
      location,
      address,
      latitude,
      longitude,
      website,
      isActive,
      votingEnabled,
      qrEnabled,
      mapsEnabled,
      gamificationEnabled,
    } = body;
    
    if (!name || !slug || !startDate || !endDate) {
      return NextResponse.json(
        { success: false, error: 'Nombre, slug, fecha de inicio y fecha de fin son requeridos' },
        { status: 400 }
      );
    }
    
    // Check if slug is unique
    const existingEvent = await db.event.findUnique({
      where: { slug },
    });
    
    if (existingEvent) {
      return NextResponse.json(
        { success: false, error: 'El slug ya está en uso' },
        { status: 400 }
      );
    }
    
    const event = await db.event.create({
      data: {
        name,
        slug,
        description,
        logo,
        image,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
        location,
        address,
        latitude,
        longitude,
        website,
        isActive: isActive ?? true,
        votingEnabled: votingEnabled ?? true,
        qrEnabled: qrEnabled ?? true,
        mapsEnabled: mapsEnabled ?? true,
        gamificationEnabled: gamificationEnabled ?? true,
        creatorId: session.userId,
      },
      include: {
        creator: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true,
          },
        },
      },
    });
    
    return NextResponse.json({
      success: true,
      data: event,
    }, { status: 201 });
  } catch (error) {
    console.error('Error creating event:', error);
    return NextResponse.json(
      { success: false, error: 'Error al crear evento' },
      { status: 500 }
    );
  }
}
