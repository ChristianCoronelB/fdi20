import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSession } from '@/lib/auth';
import { scanQRCode } from '@/lib/qr';

// POST: Scan and process QR code
export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json(
        { success: false, error: 'No autorizado' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { code } = body;

    if (!code) {
      return NextResponse.json(
        { success: false, error: 'Código QR requerido' },
        { status: 400 }
      );
    }

    // Process QR code scan
    const result = await scanQRCode(code, session.userId);

    // Get additional details based on type
    let additionalData = {};

    if (result.success && result.type === 'ACTIVITY' && result.data?.activity) {
      const activity = await db.activity.findUnique({
        where: { id: result.data.activity.id },
        include: {
          room: {
            select: {
              id: true,
              name: true,
              building: true,
            },
          },
          event: {
            select: {
              id: true,
              name: true,
            },
          },
          speaker: {
            select: {
              id: true,
              name: true,
              photo: true,
            },
          },
        },
      });

      additionalData = {
        activityDetails: activity,
      };
    }

    if (result.success && result.type === 'PROJECT' && result.data?.project) {
      const project = await db.project.findUnique({
        where: { id: result.data.project.id },
        include: {
          event: {
            select: {
              id: true,
              name: true,
            },
          },
        },
      });

      additionalData = {
        projectDetails: project,
      };
    }

    if (result.success && result.type === 'ROOM' && result.data?.room) {
      const room = await db.room.findUnique({
        where: { id: result.data.room.id },
        include: {
          event: {
            select: {
              id: true,
              name: true,
            },
          },
          _count: {
            select: {
              activities: true,
            },
          },
        },
      });

      additionalData = {
        roomDetails: room,
      };
    }

    if (result.success && result.type === 'USER' && result.data?.user) {
      const user = await db.user.findUnique({
        where: { id: result.data.user.id },
        select: {
          id: true,
          name: true,
          email: true,
          avatar: true,
          role: true,
          points: true,
          level: true,
          bio: true,
          company: true,
        },
      });

      additionalData = {
        userDetails: user,
      };
    }

    return NextResponse.json({
      success: result.success,
      data: {
        type: result.type,
        message: result.message,
        ...result.data,
        ...additionalData,
      },
    });
  } catch (error) {
    console.error('Scan QR code error:', error);
    return NextResponse.json(
      { success: false, error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
