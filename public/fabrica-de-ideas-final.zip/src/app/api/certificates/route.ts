import { NextRequest, NextResponse } from 'next/server';
import { getSession } from '@/lib/auth';
import { db } from '@/lib/db';

// GET /api/certificates - List user certificates
export async function GET(request: NextRequest) {
  try {
    const session = await getSession();
    
    if (!session) {
      return NextResponse.json(
        { success: false, error: 'No autenticado' },
        { status: 401 }
      );
    }
    
    const searchParams = request.nextUrl.searchParams;
    const userId = searchParams.get('userId') || session.userId;
    
    // Only admins can view other users' certificates
    if (userId !== session.userId && session.role !== 'ADMIN') {
      return NextResponse.json(
        { success: false, error: 'No autorizado' },
        { status: 403 }
      );
    }
    
    const certificates = await db.certificate.findMany({
      where: { userId },
      include: {
        event: {
          select: { 
            id: true,
            name: true, 
            startDate: true, 
            endDate: true,
            location: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });
    
    return NextResponse.json({
      success: true,
      data: certificates,
    });
  } catch (error) {
    console.error('Get certificates error:', error);
    return NextResponse.json(
      { success: false, error: 'Error al obtener certificados' },
      { status: 500 }
    );
  }
}

// POST /api/certificates - Generate certificate
export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    
    if (!session) {
      return NextResponse.json(
        { success: false, error: 'No autenticado' },
        { status: 401 }
      );
    }
    
    const body = await request.json();
    const { userId, eventId, type = 'attendance' } = body;
    
    // Only admins can generate certificates for other users
    const targetUserId = userId || session.userId;
    if (targetUserId !== session.userId && session.role !== 'ADMIN' && session.role !== 'ORGANIZER') {
      return NextResponse.json(
        { success: false, error: 'No autorizado para generar certificados' },
        { status: 403 }
      );
    }
    
    // Get user info
    const user = await db.user.findUnique({
      where: { id: targetUserId },
    });
    
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Usuario no encontrado' },
        { status: 404 }
      );
    }

    // Get user's complete attendances (with checkOutTime)
    const attendances = await db.attendance.findMany({
      where: { 
        userId: targetUserId,
        checkOutTime: { not: null },
      },
      include: {
        activity: {
          include: {
            event: {
              select: { id: true, name: true },
            },
            room: {
              select: { name: true },
            },
          },
        },
      },
    });

    // Check if user has at least 3 complete attendances
    if (attendances.length < 3) {
      return NextResponse.json(
        { success: false, error: `Necesitas al menos 3 asistencias completas para generar un certificado. Actualmente tienes ${attendances.length}.` },
        { status: 400 }
      );
    }

    // Get the event (use the event from first attendance or provided eventId)
    let targetEventId = eventId;
    if (!targetEventId && attendances.length > 0) {
      targetEventId = attendances[0].activity.eventId;
    }

    if (!targetEventId) {
      return NextResponse.json(
        { success: false, error: 'No se encontró un evento asociado a tus asistencias' },
        { status: 400 }
      );
    }

    const event = await db.event.findUnique({
      where: { id: targetEventId },
    });

    if (!event) {
      return NextResponse.json(
        { success: false, error: 'Evento no encontrado' },
        { status: 404 }
      );
    }

    // Check if certificate already exists for this event
    const existingCert = await db.certificate.findFirst({
      where: {
        userId: targetUserId,
        eventId: targetEventId,
        type: 'attendance',
      },
    });

    if (existingCert) {
      return NextResponse.json(
        { success: false, error: 'Ya tienes un certificado para este evento', data: existingCert },
        { status: 400 }
      );
    }

    // Get activities for the certificate
    const activities = attendances
      .filter(a => a.activity.eventId === targetEventId)
      .map(a => ({
        title: a.activity.title,
        type: a.activity.type,
        date: a.activity.startTime,
        room: a.activity.room?.name,
      }));

    // Generate unique code
    const code = `CERT-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
    
    // Create certificate with activities in description
    const certificate = await db.certificate.create({
      data: {
        userId: targetUserId,
        eventId: targetEventId,
        type: 'attendance',
        title: `Certificado de Participación - ${event.name}`,
        description: JSON.stringify({
          activities,
          totalAttendances: attendances.length,
          eventLocation: event.location,
        }),
        code,
        issueDate: new Date(),
      },
      include: {
        event: {
          select: { name: true, startDate: true, endDate: true },
        },
      },
    });
    
    return NextResponse.json({
      success: true,
      data: certificate,
      message: 'Certificado generado exitosamente',
    });
  } catch (error) {
    console.error('Create certificate error:', error);
    return NextResponse.json(
      { success: false, error: 'Error al generar certificado' },
      { status: 500 }
    );
  }
}
