import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Iniciando seed de la base de datos...\n');

  // Crear usuario admin
  const hashedPassword = await bcrypt.hash('admin123', 10);
  
  const admin = await prisma.user.upsert({
    where: { email: 'admin@fabricadeideas.com' },
    update: {},
    create: {
      email: 'admin@fabricadeideas.com',
      name: 'Administrador',
      password: hashedPassword,
      role: 'ADMIN',
      points: 2450,
      level: 25,
    },
  });

  console.log('✅ Usuario admin creado:', admin.email);
  console.log('📧 Email: admin@fabricadeideas.com');
  console.log('🔑 Password: admin123\n');

  // Crear achievements (logros)
  const achievements = await Promise.all([
    // Logros basados en asistencia
    prisma.achievement.upsert({
      where: { id: 'achievement-first-attendance' },
      update: {},
      create: {
        id: 'achievement-first-attendance',
        name: 'Primera Asistencia',
        description: 'Has registrado tu primera asistencia a una actividad',
        icon: '🎯',
        points: 10,
        category: 'asistencia',
        requirement: 'attendance:>=1',
      },
    }),
    prisma.achievement.upsert({
      where: { id: 'achievement-active-participant' },
      update: {},
      create: {
        id: 'achievement-active-participant',
        name: 'Participante Activo',
        description: 'Has asistido a 5 actividades del evento',
        icon: '⭐',
        points: 50,
        category: 'asistencia',
        requirement: 'attendance:>=5',
      },
    }),
    prisma.achievement.upsert({
      where: { id: 'achievement-veteran' },
      update: {},
      create: {
        id: 'achievement-veteran',
        name: 'Veterano',
        description: 'Has asistido a 10 actividades del evento',
        icon: '🏆',
        points: 100,
        category: 'asistencia',
        requirement: 'attendance:>=10',
      },
    }),

    // Logros basados en votos
    prisma.achievement.upsert({
      where: { id: 'achievement-voter' },
      update: {},
      create: {
        id: 'achievement-voter',
        name: 'Votante',
        description: 'Has realizado tu primer voto',
        icon: '🗳️',
        points: 10,
        category: 'votos',
        requirement: 'votes:>=1',
      },
    }),
    prisma.achievement.upsert({
      where: { id: 'achievement-influencer' },
      update: {},
      create: {
        id: 'achievement-influencer',
        name: 'Influencer',
        description: 'Has realizado 10 votos en proyectos',
        icon: '🌟',
        points: 100,
        category: 'votos',
        requirement: 'votes:>=10',
      },
    }),

    // Logros basados en puntos
    prisma.achievement.upsert({
      where: { id: 'achievement-bronze' },
      update: {},
      create: {
        id: 'achievement-bronze',
        name: 'Puntos Bronce',
        description: 'Has alcanzado 100 puntos',
        icon: '🥉',
        points: 25,
        category: 'puntos',
        requirement: 'points:>=100',
      },
    }),
    prisma.achievement.upsert({
      where: { id: 'achievement-silver' },
      update: {},
      create: {
        id: 'achievement-silver',
        name: 'Puntos Plata',
        description: 'Has alcanzado 500 puntos',
        icon: '🥈',
        points: 50,
        category: 'puntos',
        requirement: 'points:>=500',
      },
    }),
    prisma.achievement.upsert({
      where: { id: 'achievement-gold' },
      update: {},
      create: {
        id: 'achievement-gold',
        name: 'Puntos Oro',
        description: 'Has alcanzado 1000 puntos',
        icon: '🥇',
        points: 100,
        category: 'puntos',
        requirement: 'points:>=1000',
      },
    }),
  ]);

  console.log('✅ Achievements creados:', achievements.length, '\n');

  // Crear un evento de ejemplo
  const event = await prisma.event.upsert({
    where: { slug: 'fabrica-de-ideas-2024' },
    update: {},
    create: {
      name: 'Fábrica de Ideas 2024',
      slug: 'fabrica-de-ideas-2024',
      description: 'El evento de innovación más grande del año. Tres días de conferencias, talleres y competencias.',
      startDate: new Date('2024-03-15T09:00:00'),
      endDate: new Date('2024-03-17T18:00:00'),
      location: 'Centro de Convenciones',
      address: 'Av. Principal 123',
      isActive: true,
      creatorId: admin.id,
    },
  });

  console.log('✅ Evento creado:', event.name, '\n');

  // Crear salas para el evento
  const rooms = await Promise.all([
    prisma.room.upsert({
      where: { id: 'room-auditorio' },
      update: {},
      create: {
        id: 'room-auditorio',
        name: 'Auditorio Principal',
        capacity: 500,
        building: 'Edificio A',
        floor: 'Planta Baja',
        color: '#3B82F6',
        eventId: event.id,
      },
    }),
    prisma.room.upsert({
      where: { id: 'room-innovacion' },
      update: {},
      create: {
        id: 'room-innovacion',
        name: 'Sala Innovación',
        capacity: 150,
        building: 'Edificio B',
        floor: 'Piso 2',
        color: '#10B981',
        eventId: event.id,
      },
    }),
    prisma.room.upsert({
      where: { id: 'room-workshop1' },
      update: {},
      create: {
        id: 'room-workshop1',
        name: 'Workshop Lab 1',
        capacity: 50,
        building: 'Edificio C',
        floor: 'Piso 1',
        color: '#F59E0B',
        eventId: event.id,
      },
    }),
    prisma.room.upsert({
      where: { id: 'room-workshop2' },
      update: {},
      create: {
        id: 'room-workshop2',
        name: 'Workshop Lab 2',
        capacity: 50,
        building: 'Edificio C',
        floor: 'Piso 1',
        color: '#8B5CF6',
        eventId: event.id,
      },
    }),
    prisma.room.upsert({
      where: { id: 'room-expo' },
      update: {},
      create: {
        id: 'room-expo',
        name: 'Sala de Exposiciones',
        capacity: 200,
        building: 'Edificio A',
        floor: 'Piso 1',
        color: '#EF4444',
        eventId: event.id,
      },
    }),
  ]);

  console.log('✅ Salas creadas:', rooms.length, '\n');

  // Crear speakers
  const speakers = await Promise.all([
    prisma.speaker.upsert({
      where: { id: 'speaker-1' },
      update: {},
      create: {
        id: 'speaker-1',
        name: 'Dra. María López',
        title: 'Directora de Innovación',
        company: 'TechCorp',
        bio: 'Experta en transformación digital y metodologías ágiles.',
        eventId: event.id,
      },
    }),
    prisma.speaker.upsert({
      where: { id: 'speaker-2' },
      update: {},
      create: {
        id: 'speaker-2',
        name: 'Juan Martínez',
        title: 'UX Lead',
        company: 'DesignHub',
        bio: 'Especialista en diseño centrado en el usuario.',
        eventId: event.id,
      },
    }),
  ]);

  console.log('✅ Speakers creados:', speakers.length, '\n');

  // Crear actividades
  const activities = await Promise.all([
    prisma.activity.upsert({
      where: { id: 'activity-1' },
      update: {},
      create: {
        id: 'activity-1',
        title: 'Inauguración del Evento',
        description: 'Ceremonia de apertura con keynote principal sobre el futuro de la innovación.',
        type: 'KEYNOTE',
        status: 'SCHEDULED',
        startTime: new Date('2024-03-15T09:00:00'),
        endTime: new Date('2024-03-15T10:30:00'),
        eventId: event.id,
        roomId: rooms[0].id,
        speakerId: speakers[0].id,
      },
    }),
    prisma.activity.upsert({
      where: { id: 'activity-2' },
      update: {},
      create: {
        id: 'activity-2',
        title: 'Taller de Design Thinking',
        description: 'Aprende metodologías de diseño centrado en el usuario.',
        type: 'WORKSHOP',
        status: 'SCHEDULED',
        startTime: new Date('2024-03-15T11:00:00'),
        endTime: new Date('2024-03-15T13:00:00'),
        eventId: event.id,
        roomId: rooms[2].id,
        speakerId: speakers[1].id,
      },
    }),
    prisma.activity.upsert({
      where: { id: 'activity-3' },
      update: {},
      create: {
        id: 'activity-3',
        title: 'Panel: Startups que transforman',
        description: 'Fundadores comparten sus experiencias y lecciones aprendidas.',
        type: 'PANEL',
        status: 'SCHEDULED',
        startTime: new Date('2024-03-15T14:00:00'),
        endTime: new Date('2024-03-15T15:30:00'),
        eventId: event.id,
        roomId: rooms[0].id,
      },
    }),
    prisma.activity.upsert({
      where: { id: 'activity-4' },
      update: {},
      create: {
        id: 'activity-4',
        title: 'Networking Session',
        description: 'Conecta con otros participantes y crea alianzas.',
        type: 'NETWORKING',
        status: 'SCHEDULED',
        startTime: new Date('2024-03-15T16:00:00'),
        endTime: new Date('2024-03-15T17:30:00'),
        eventId: event.id,
        roomId: rooms[4].id,
      },
    }),
    prisma.activity.upsert({
      where: { id: 'activity-5' },
      update: {},
      create: {
        id: 'activity-5',
        title: 'Pitch Competition',
        description: 'Los mejores proyectos presentan sus propuestas.',
        type: 'PRESENTATION',
        status: 'SCHEDULED',
        startTime: new Date('2024-03-16T10:00:00'),
        endTime: new Date('2024-03-16T12:00:00'),
        eventId: event.id,
        roomId: rooms[0].id,
      },
    }),
  ]);

  console.log('✅ Actividades creadas:', activities.length, '\n');

  // Crear proyectos
  const projects = await Promise.all([
    prisma.project.upsert({
      where: { id: 'project-1' },
      update: {},
      create: {
        id: 'project-1',
        name: 'EcoTrack',
        team: JSON.stringify(['Ana García', 'Pedro López', 'Sofia Ruiz']),
        category: 'Sostenibilidad',
        description: 'App para monitorear y reducir tu huella de carbono personal.',
        status: 'APPROVED',
        totalVotes: 156,
        averageScore: 4.7,
        rank: 1,
        eventId: event.id,
      },
    }),
    prisma.project.upsert({
      where: { id: 'project-2' },
      update: {},
      create: {
        id: 'project-2',
        name: 'MediConnect',
        team: JSON.stringify(['Carlos Fernández', 'Laura Torres']),
        category: 'Salud',
        description: 'Plataforma de telemedicina con IA para diagnóstico preventivo.',
        status: 'APPROVED',
        totalVotes: 142,
        averageScore: 4.5,
        rank: 2,
        eventId: event.id,
      },
    }),
    prisma.project.upsert({
      where: { id: 'project-3' },
      update: {},
      create: {
        id: 'project-3',
        name: 'LearnPath',
        team: JSON.stringify(['Miguel Santos', 'Elena Vargas', 'Roberto Díaz']),
        category: 'Educación',
        description: 'Sistema de aprendizaje adaptativo basado en el estilo cognitivo del estudiante.',
        status: 'APPROVED',
        totalVotes: 128,
        averageScore: 4.4,
        rank: 3,
        eventId: event.id,
      },
    }),
    prisma.project.upsert({
      where: { id: 'project-4' },
      update: {},
      create: {
        id: 'project-4',
        name: 'SmartCity Hub',
        team: JSON.stringify(['Pablo Mora', 'Carmen Ruiz']),
        category: 'Smart Cities',
        description: 'Plataforma IoT para gestión urbana inteligente.',
        status: 'APPROVED',
        totalVotes: 98,
        averageScore: 4.2,
        rank: 4,
        eventId: event.id,
      },
    }),
    prisma.project.upsert({
      where: { id: 'project-5' },
      update: {},
      create: {
        id: 'project-5',
        name: 'FinBot',
        team: JSON.stringify(['Andrés Herrera', 'Lucía Méndez']),
        category: 'Finanzas',
        description: 'Asistente financiero personal impulsado por IA.',
        status: 'APPROVED',
        totalVotes: 87,
        averageScore: 4.0,
        rank: 5,
        eventId: event.id,
      },
    }),
  ]);

  console.log('✅ Proyectos creados:', projects.length, '\n');

  // Crear usuarios adicionales para el leaderboard
  const additionalUsers = await Promise.all([
    prisma.user.upsert({
      where: { email: 'ana.rodriguez@test.com' },
      update: {},
      create: {
        email: 'ana.rodriguez@test.com',
        name: 'Ana Rodríguez',
        password: hashedPassword,
        role: 'PARTICIPANT',
        points: 3250,
        level: 33,
      },
    }),
    prisma.user.upsert({
      where: { email: 'pedro.sanchez@test.com' },
      update: {},
      create: {
        email: 'pedro.sanchez@test.com',
        name: 'Pedro Sánchez',
        password: hashedPassword,
        role: 'PARTICIPANT',
        points: 2980,
        level: 30,
      },
    }),
    prisma.user.upsert({
      where: { email: 'maria.fernandez@test.com' },
      update: {},
      create: {
        email: 'maria.fernandez@test.com',
        name: 'María Fernández',
        password: hashedPassword,
        role: 'PARTICIPANT',
        points: 2100,
        level: 21,
      },
    }),
    prisma.user.upsert({
      where: { email: 'luis.torres@test.com' },
      update: {},
      create: {
        email: 'luis.torres@test.com',
        name: 'Luis Torres',
        password: hashedPassword,
        role: 'PARTICIPANT',
        points: 1890,
        level: 19,
      },
    }),
  ]);

  console.log('✅ Usuarios adicionales creados:', additionalUsers.length, '\n');

  // Crear algunas asistencias de ejemplo para el admin
  const sampleAttendances = await Promise.all([
    prisma.attendance.upsert({
      where: { userId_activityId: { userId: admin.id, activityId: 'activity-1' } },
      update: {},
      create: {
        userId: admin.id,
        activityId: 'activity-1',
        points: 10,
        checkOutTime: new Date('2024-03-15T10:30:00'),
      },
    }),
    prisma.attendance.upsert({
      where: { userId_activityId: { userId: admin.id, activityId: 'activity-2' } },
      update: {},
      create: {
        userId: admin.id,
        activityId: 'activity-2',
        points: 10,
        checkOutTime: new Date('2024-03-15T13:00:00'),
      },
    }),
    prisma.attendance.upsert({
      where: { userId_activityId: { userId: admin.id, activityId: 'activity-3' } },
      update: {},
      create: {
        userId: admin.id,
        activityId: 'activity-3',
        points: 10,
        checkOutTime: new Date('2024-03-15T15:30:00'),
      },
    }),
  ]);

  console.log('✅ Asistencias de ejemplo creadas:', sampleAttendances.length, '\n');

  // Otorgar logros al admin basados en sus asistencias
  const earnedAchievements = await Promise.all([
    prisma.userAchievement.upsert({
      where: { userId_achievementId: { userId: admin.id, achievementId: 'achievement-first-attendance' } },
      update: {},
      create: {
        userId: admin.id,
        achievementId: 'achievement-first-attendance',
      },
    }),
    prisma.userAchievement.upsert({
      where: { userId_achievementId: { userId: admin.id, achievementId: 'achievement-bronze' } },
      update: {},
      create: {
        userId: admin.id,
        achievementId: 'achievement-bronze',
      },
    }),
    prisma.userAchievement.upsert({
      where: { userId_achievementId: { userId: admin.id, achievementId: 'achievement-silver' } },
      update: {},
      create: {
        userId: admin.id,
        achievementId: 'achievement-silver',
      },
    }),
    prisma.userAchievement.upsert({
      where: { userId_achievementId: { userId: admin.id, achievementId: 'achievement-gold' } },
      update: {},
      create: {
        userId: admin.id,
        achievementId: 'achievement-gold',
      },
    }),
  ]);

  console.log('✅ Logros otorgados al admin:', earnedAchievements.length, '\n');

  console.log('🎉 ¡Base de datos lista! Ya puedes iniciar sesión.');
  console.log('📧 Credenciales: admin@fabricadeideas.com / admin123');
  console.log('\n📊 Resumen:');
  console.log(`   - ${achievements.length} logros disponibles`);
  console.log(`   - ${rooms.length} salas`);
  console.log(`   - ${speakers.length} speakers`);
  console.log(`   - ${activities.length} actividades`);
  console.log(`   - ${projects.length} proyectos`);
  console.log(`   - ${additionalUsers.length + 1} usuarios`);
}

main()
  .catch((e) => {
    console.error('❌ Error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
