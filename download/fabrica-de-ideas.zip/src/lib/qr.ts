import QRCode from 'qrcode';
import { db } from './db';
import type { QRType } from '@prisma/client';

export async function generateQRCode(data: string): Promise<string> {
  return QRCode.toDataURL(data, {
    width: 400,
    margin: 2,
    color: {
      dark: '#1f2937',
      light: '#ffffff',
    },
  });
}

export async function generateUniqueCode(): Promise<string> {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = '';
  for (let i = 0; i < 8; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  
  // Ensure uniqueness
  const existing = await db.qRCode.findUnique({ where: { code } });
  if (existing) {
    return generateUniqueCode();
  }
  
  return code;
}

export async function createQRCode(params: {
  type: QRType;
  userId?: string;
  roomId?: string;
  activityId?: string;
  projectId?: string;
  eventId?: string;
  expiresAt?: Date;
}): Promise<{ id: string; code: string; qrImage: string }> {
  const code = await generateUniqueCode();
  
  const qrCode = await db.qRCode.create({
    data: {
      code,
      type: params.type,
      userId: params.userId,
      roomId: params.roomId,
      activityId: params.activityId,
      projectId: params.projectId,
      eventId: params.eventId,
      expiresAt: params.expiresAt,
    },
  });
  
  const qrImage = await generateQRCode(code);
  
  return { id: qrCode.id, code, qrImage };
}

// Points configuration for QR scanning
const QR_POINTS = {
  ACTIVITY_CHECKIN: 10,
  ACTIVITY_CHECKOUT: 15,
  PROJECT_VIEW: 5,
  ROOM_CHECKIN: 5,
};

export async function scanQRCode(code: string, userId: string): Promise<{
  success: boolean;
  type: QRType;
  data?: {
    room?: { id: string; name: string };
    activity?: { id: string; title: string };
    project?: { id: string; name: string };
    user?: { id: string; name: string };
    pointsEarned?: number;
    attendanceComplete?: boolean;
  };
  message: string;
}> {
  // First, try to parse as structured QR format (ROOM:id:..., ACTIVITY:id:..., PROJECT:id:...)
  if (code.includes(':')) {
    const parts = code.split(':');
    const qrType = parts[0];

    if (qrType === 'ROOM' && parts[1]) {
      const roomId = parts[1];
      const roomName = parts[2] || 'Sala';

      // Get room from database
      const room = await db.$queryRaw`
        SELECT id, name, building, floor FROM rooms WHERE id = ${roomId}
      `;
      const roomData = (room as any[])[0];

      if (roomData) {
        // Award points for room check-in
        await db.$executeRaw`
          UPDATE users SET points = points + ${QR_POINTS.ROOM_CHECKIN} WHERE id = ${userId}
        `;

        return {
          success: true,
          type: 'ROOM',
          data: {
            room: { id: roomData.id, name: roomData.name },
            pointsEarned: QR_POINTS.ROOM_CHECKIN,
          },
          message: `Sala "${roomData.name}" encontrada. ¡+${QR_POINTS.ROOM_CHECKIN} puntos!`,
        };
      }
    }

    if (qrType === 'ACTIVITY' && parts[1]) {
      const activityId = parts[1];

      // Get activity from database
      const activity = await db.$queryRaw`
        SELECT id, title, type, status FROM activities WHERE id = ${activityId}
      `;
      const activityData = (activity as any[])[0];

      if (activityData) {
        const now = new Date();

        // Check if user is registered for this activity
        const registrationCheck = await db.$queryRaw`
          SELECT id FROM activity_registrations WHERE userId = ${userId} AND activityId = ${activityId}
        `;
        const isRegistered = (registrationCheck as any[]).length > 0;

        if (!isRegistered) {
          return {
            success: false,
            type: 'ACTIVITY',
            message: `No estás registrado en "${activityData.title}". Debes registrarte primero en la agenda para poder registrar tu asistencia.`,
          };
        }

        // Check existing attendance
        const existingAttendance = await db.$queryRaw`
          SELECT * FROM attendances WHERE userId = ${userId} AND activityId = ${activityId}
        `;
        const existing = (existingAttendance as any[])[0];

        let pointsEarned = 0;
        let message = '';
        let attendanceComplete = false;

        if (!existing) {
          // Create new attendance with check-in
          const attendanceId = `att_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
          await db.$executeRaw`
            INSERT INTO attendances (id, userId, activityId, checkInTime, points, createdAt)
            VALUES (${attendanceId}, ${userId}, ${activityId}, ${now}, ${QR_POINTS.ACTIVITY_CHECKIN}, ${now})
          `;
          pointsEarned = QR_POINTS.ACTIVITY_CHECKIN;
          message = `Check-in registrado en "${activityData.title}". ¡+${pointsEarned} puntos!`;

          // Update activity attendance count
          await db.$executeRaw`
            UPDATE activities SET currentAttendance = currentAttendance + 1 WHERE id = ${activityId}
          `;
        } else if (existing.checkInTime && !existing.checkOutTime) {
          // Do check-out with bonus
          const totalPointsForCheckout = QR_POINTS.ACTIVITY_CHECKOUT + 5;
          await db.$executeRaw`
            UPDATE attendances SET checkOutTime = ${now}, points = points + ${totalPointsForCheckout} WHERE id = ${existing.id}
          `;
          pointsEarned = totalPointsForCheckout;
          attendanceComplete = true;
          message = `Check-out registrado en "${activityData.title}". ¡+${pointsEarned} puntos! Asistencia completa.`;
        } else if (existing.checkInTime && existing.checkOutTime) {
          return {
            success: true,
            type: 'ACTIVITY',
            data: {
              activity: { id: activityData.id, title: activityData.title },
              attendanceComplete: true,
            },
            message: 'Ya completaste la asistencia a esta actividad',
          };
        }

        // Award points to user
        if (pointsEarned > 0) {
          await db.$executeRaw`
            UPDATE users SET points = points + ${pointsEarned} WHERE id = ${userId}
          `;
        }

        return {
          success: true,
          type: 'ACTIVITY',
          data: {
            activity: { id: activityData.id, title: activityData.title },
            pointsEarned,
            attendanceComplete,
          },
          message,
        };
      }
    }

    if (qrType === 'PROJECT' && parts[1]) {
      const projectId = parts[1];

      const project = await db.$queryRaw`
        SELECT id, name, team FROM projects WHERE id = ${projectId}
      `;
      const projectData = (project as any[])[0];

      if (projectData) {
        await db.$executeRaw`
          UPDATE users SET points = points + ${QR_POINTS.PROJECT_VIEW} WHERE id = ${userId}
        `;

        return {
          success: true,
          type: 'PROJECT',
          data: {
            project: { id: projectData.id, name: projectData.name },
            pointsEarned: QR_POINTS.PROJECT_VIEW,
          },
          message: `Proyecto "${projectData.name}" encontrado. ¡+${QR_POINTS.PROJECT_VIEW} puntos!`,
        };
      }
    }
  }

  // If not a structured format, look up in database
  const qrCode = await db.qRCode.findUnique({
    where: { code },
    include: {
      room: true,
      activity: true,
      project: true,
      user: true,
    },
  });

  if (!qrCode) {
    return { success: false, type: 'ROOM', message: 'Código QR no válido. El código no está registrado en el sistema.' };
  }
  
  if (!qrCode.isActive) {
    return { success: false, type: qrCode.type, message: 'Código QR desactivado' };
  }
  
  if (qrCode.expiresAt && qrCode.expiresAt < new Date()) {
    return { success: false, type: qrCode.type, message: 'Código QR expirado' };
  }
  
  // Increment scan count
  await db.qRCode.update({
    where: { id: qrCode.id },
    data: { scanCount: { increment: 1 } },
  });
  
  // Handle different QR types
  switch (qrCode.type) {
    case 'ACTIVITY':
      if (qrCode.activityId) {
        const now = new Date();

        // First, check if user is registered for this activity
        const registrationCheck = await db.$queryRaw`
          SELECT id FROM activity_registrations WHERE userId = ${userId} AND activityId = ${qrCode.activityId}
        `;
        const isRegistered = (registrationCheck as any[]).length > 0;

        if (!isRegistered) {
          return {
            success: false,
            type: qrCode.type,
            message: `No estás registrado en "${qrCode.activity!.title}". Debes registrarte primero en la agenda para poder registrar tu asistencia.`,
          };
        }

        // Check if already has attendance record
        const existingAttendance = await db.$queryRaw`
          SELECT * FROM attendances WHERE userId = ${userId} AND activityId = ${qrCode.activityId}
        `;
        const existing = (existingAttendance as any[])[0];

        let pointsEarned = 0;
        let message = '';
        let attendanceComplete = false;

        if (!existing) {
          // Create new attendance with check-in
          const attendanceId = `att_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
          await db.$executeRaw`
            INSERT INTO attendances (id, userId, activityId, checkInTime, points, createdAt)
            VALUES (${attendanceId}, ${userId}, ${qrCode.activityId}, ${now}, ${QR_POINTS.ACTIVITY_CHECKIN}, ${now})
          `;
          pointsEarned = QR_POINTS.ACTIVITY_CHECKIN;
          message = `Check-in registrado en "${qrCode.activity!.title}". ¡+${pointsEarned} puntos!`;

          // Update activity attendance count
          await db.$executeRaw`
            UPDATE activities SET currentAttendance = currentAttendance + 1 WHERE id = ${qrCode.activityId}
          `;
        } else if (existing.checkInTime && !existing.checkOutTime) {
          // Do check-out with bonus for complete attendance
          const totalPointsForCheckout = QR_POINTS.ACTIVITY_CHECKOUT + 5; // 15 + 5 bonus = 20 points
          await db.$executeRaw`
            UPDATE attendances SET checkOutTime = ${now}, points = points + ${totalPointsForCheckout} WHERE id = ${existing.id}
          `;
          pointsEarned = totalPointsForCheckout;
          attendanceComplete = true;
          message = `Check-out registrado en "${qrCode.activity!.title}". ¡+${pointsEarned} puntos! Asistencia completa.`;
        } else if (existing.checkInTime && existing.checkOutTime) {
          message = 'Ya completaste la asistencia a esta actividad';
          return {
            success: true,
            type: qrCode.type,
            data: {
              activity: {
                id: qrCode.activity!.id,
                title: qrCode.activity!.title,
              },
              attendanceComplete: true,
            },
            message,
          };
        }

        // Award points to user
        if (pointsEarned > 0) {
          await db.$executeRaw`
            UPDATE users SET points = points + ${pointsEarned} WHERE id = ${userId}
          `;
        }

        return {
          success: true,
          type: qrCode.type,
          data: {
            activity: {
              id: qrCode.activity!.id,
              title: qrCode.activity!.title,
            },
            pointsEarned,
            attendanceComplete,
          },
          message,
        };
      }
      break;
      
    case 'PROJECT':
      // Award points for viewing project
      await db.$executeRaw`
        UPDATE users SET points = points + ${QR_POINTS.PROJECT_VIEW} WHERE id = ${userId}
      `;
      
      return {
        success: true,
        type: qrCode.type,
        data: {
          project: qrCode.project ? { id: qrCode.project.id, title: qrCode.project.name } : undefined,
          pointsEarned: QR_POINTS.PROJECT_VIEW,
        },
        message: `Proyecto "${qrCode.project?.name}" encontrado. ¡+${QR_POINTS.PROJECT_VIEW} puntos!`,
      };
      
    case 'ROOM':
      // Award points for room check-in
      await db.$executeRaw`
        UPDATE users SET points = points + ${QR_POINTS.ROOM_CHECKIN} WHERE id = ${userId}
      `;
      
      return {
        success: true,
        type: qrCode.type,
        data: {
          room: qrCode.room ? { id: qrCode.room.id, name: qrCode.room.name } : undefined,
          pointsEarned: QR_POINTS.ROOM_CHECKIN,
        },
        message: `Sala "${qrCode.room?.name}" encontrada. ¡+${QR_POINTS.ROOM_CHECKIN} puntos!`,
      };
      
    case 'USER':
      return {
        success: true,
        type: qrCode.type,
        data: qrCode.user ? {
          user: { id: qrCode.user.id, name: qrCode.user.name },
        } : undefined,
        message: 'Usuario encontrado',
      };
  }
  
  return { success: false, type: qrCode.type, message: 'Tipo de QR no soportado' };
}
