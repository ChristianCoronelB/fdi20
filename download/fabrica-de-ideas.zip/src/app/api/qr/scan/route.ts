import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSession } from '@/lib/auth';
import { scanQRCode } from '@/lib/qr';

// POST: Scan and process QR code
export async function POST(request: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json(
        { success: false, error: 'No autorizado' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { code } = body;

    if (!code) {
      return NextResponse.json(
        { success: false, error: 'Código QR requerido' },
        { status: 400 }
      );
    }

    // Process QR code scan
    const result = await scanQRCode(code, session.userId);

    // Get updated user points
    const updatedUser = await db.$queryRaw`
      SELECT points, level FROM users WHERE id = ${session.userId}
    `;
    const userData = (updatedUser as any[])[0];

    // Get additional details based on type
    let additionalData: any = {
      totalPoints: userData?.points || 0,
      level: userData?.level || 1,
    };

    if (result.success && result.type === 'ACTIVITY' && result.data?.activity) {
      const activity = await db.$queryRaw`
        SELECT 
          a.id,
          a.title,
          a.type,
          a.status,
          a.startTime,
          a.endTime,
          r.id as room_id,
          r.name as room_name,
          r.building as room_building
        FROM activities a
        LEFT JOIN rooms r ON a.roomId = r.id
        WHERE a.id = ${result.data.activity.id}
      `;
      const activityData = (activity as any[])[0];

      // Count complete attendances for certificate eligibility
      const completeAttendances = await db.$queryRaw`
        SELECT COUNT(*) as count FROM attendances 
        WHERE userId = ${session.userId} AND checkInTime IS NOT NULL AND checkOutTime IS NOT NULL
      `;
      const completeCount = (completeAttendances as any[])[0]?.count || 0;

      additionalData = {
        ...additionalData,
        activityDetails: activityData ? {
          id: activityData.id,
          title: activityData.title,
          type: activityData.type,
          status: activityData.status,
          startTime: activityData.startTime,
          endTime: activityData.endTime,
          room: activityData.room_id ? {
            id: activityData.room_id,
            name: activityData.room_name,
            building: activityData.room_building,
          } : null,
        } : null,
        completeAttendances: Number(completeCount),
        canGenerateCertificate: Number(completeCount) >= 3,
      };
    }

    if (result.success && result.type === 'PROJECT' && result.data?.project) {
      const project = await db.$queryRaw`
        SELECT 
          p.id,
          p.name,
          p.team,
          p.category,
          p.description,
          p.totalVotes,
          p.averageScore
        FROM projects p
        WHERE p.id = ${result.data.project.id}
      `;
      const projectData = (project as any[])[0];

      additionalData = {
        ...additionalData,
        projectDetails: projectData,
      };
    }

    if (result.success && result.type === 'ROOM' && result.data?.room) {
      const room = await db.$queryRaw`
        SELECT 
          r.id,
          r.name,
          r.building,
          r.floor,
          r.capacity,
          COUNT(a.id) as activityCount
        FROM rooms r
        LEFT JOIN activities a ON a.roomId = r.id
        WHERE r.id = ${result.data.room.id}
        GROUP BY r.id
      `;
      const roomData = (room as any[])[0];

      additionalData = {
        ...additionalData,
        roomDetails: roomData,
      };
    }

    if (result.success && result.type === 'USER' && result.data?.user) {
      const user = await db.$queryRaw`
        SELECT 
          id,
          name,
          email,
          avatar,
          role,
          points,
          level
        FROM users
        WHERE id = ${result.data.user.id}
      `;
      const userData = (user as any[])[0];

      additionalData = {
        ...additionalData,
        userDetails: userData,
      };
    }

    return NextResponse.json({
      success: result.success,
      data: {
        type: result.type,
        message: result.message,
        ...result.data,
        ...additionalData,
      },
    });
  } catch (error) {
    console.error('Scan QR code error:', error);
    return NextResponse.json(
      { success: false, error: 'Error interno del servidor' },
      { status: 500 }
    );
  }
}
